document.addEventListener("DOMContentLoaded", function(){ window.addEventListener( 'load', function(){
	UAGBTableOfContents._run( {"mappingHeaders":[true,true,true,true,true,true],"scrollToTop":false,"makeCollapsible":false,"enableCollapsableList":false,"initialCollapse":false,"markerView":"disc","isFrontend":true,"initiallyCollapseList":false}, '.uagb-block-191ca22b' );
} );
 });