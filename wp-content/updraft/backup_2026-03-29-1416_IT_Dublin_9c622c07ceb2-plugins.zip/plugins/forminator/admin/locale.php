<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$forminator_admin_locale = array(
"Inline Message" => array( null, __("Inline Message", "forminator"), ), // src/utils.js:140
"Redirect user to a URL" => array( null, __("Redirect user to a URL", "forminator"), ), // src/utils.js:141
"Hide form" => array( null, __("Hide form", "forminator"), ), // src/utils.js:142
"None" => array( null, __("None", "forminator"), ), // src/utils.js:571
"null" => array( null, __("null", "forminator"), ), // src/utils.js:625
"Day" => array( null, __("Day", "forminator"), ), // src/utils.js:755
"Month" => array( null, __("Month", "forminator"), ), // src/utils.js:762
"Year" => array( null, __("Year", "forminator"), ), // src/utils.js:769
"Hour" => array( null, __("Hour", "forminator"), ), // src/utils.js:1120
"Minute" => array( null, __("Minute", "forminator"), ), // src/utils.js:1127
"is" => array( null, __("is", "forminator"), ), // src/utils.js:1207
"is not" => array( null, __("is not", "forminator"), ), // src/utils.js:1209
"day is" => array( null, __("day is", "forminator"), ), // src/utils.js:1211
"day is not" => array( null, __("day is not", "forminator"), ), // src/utils.js:1213
"month is not" => array( null, __("month is not", "forminator"), ), // src/utils.js:1215
"month is" => array( null, __("month is", "forminator"), ), // src/utils.js:1217
"is before" => array( null, __("is before", "forminator"), ), // src/utils.js:1219
"is after" => array( null, __("is after", "forminator"), ), // src/utils.js:1221
"is before %s or more days from current date" => array( null, __("is before %s or more days from current date", "forminator"), ), // src/utils.js:1223
"is before less than %s days from current date" => array( null, __("is before less than %s days from current date", "forminator"), ), // src/utils.js:1225
"is after %s or more days from current date" => array( null, __("is after %s or more days from current date", "forminator"), ), // src/utils.js:1227
"is after less than %s days from current date" => array( null, __("is after less than %s days from current date", "forminator"), ), // src/utils.js:1229
"is greater than" => array( null, __("is greater than", "forminator"), ), // src/utils.js:1231
"is less than" => array( null, __("is less than", "forminator"), ), // src/utils.js:1233
"contains" => array( null, __("contains", "forminator"), ), // src/utils.js:1235
"does not contain" => array( null, __("does not contain", "forminator"), ), // src/utils.js:1237
"starts with" => array( null, __("starts with", "forminator"), ), // src/utils.js:1239
"ends with" => array( null, __("ends with", "forminator"), ), // src/utils.js:1241
"is correct" => array( null, __("is correct", "forminator"), ), // src/utils.js:1243
"is incorrect" => array( null, __("is incorrect", "forminator"), ), // src/utils.js:1245
"is final result" => array( null, __("is final result", "forminator"), ), // src/utils.js:1248
"is not final result" => array( null, __("is not final result", "forminator"), ), // src/utils.js:1250
"Please fix the error(s) in the SETTINGS tab." => array( null, __("Please fix the error(s) in the SETTINGS tab.", "forminator"), ), // src/utils.js:1554
"Stripe Subscription Add-on is required." => array( null, __("Stripe Subscription Add-on is required.", "forminator"), ), // src/utils.js:1569
"Billing frequency should be greater than or equal to 1" => array( null, __("Billing frequency should be greater than or equal to 1", "forminator"), ), // src/utils.js:1604
"Use form settings (Above inputs)" => array( null, __("Use form settings (Above inputs)", "forminator"), ), // src/utils.js:1701
"Use form settings (Below inputs)" => array( null, __("Use form settings (Below inputs)", "forminator"), ), // src/utils.js:1701
"Hosting by the Same People Behind Forminator!" => array( null, __("Hosting by the Same People Behind Forminator!", "forminator"), ), // src/shared/hosting-banner.js:32
"Only admin users can see this message" => array( null, __("Only admin users can see this message", "forminator"), ), // src/shared/hosting-banner.js:35
"Claim Your 50% Off Hosting Now!" => array( null, __("Claim Your 50% Off Hosting Now!", "forminator"), ), // src/shared/hosting-banner.js:36
"Unleash the Full Power of Your Site with WPMU DEV Hosting! Lightning-Fast Speed, Robust Security, 24/7 Expert Support, and Effortless Ease of Use. Take Your Sites to the Next Level Today {{b}}with 50% off the First Month!{{/b}}" => array( null, __("Unleash the Full Power of Your Site with WPMU DEV Hosting! Lightning-Fast Speed, Robust Security, 24/7 Expert Support, and Effortless Ease of Use. Take Your Sites to the Next Level Today {{b}}with 50% off the First Month!{{/b}}", "forminator"), ), // src/shared/hosting-banner.js:42
"Don't Miss Out On Subscription / Recurring Payment Support" => array( null, __("Don't Miss Out On Subscription / Recurring Payment Support", "forminator"), ), // src/shared/discount.js:29
"Don't worry, only admin users can see this message" => array( null, __("Don't worry, only admin users can see this message", "forminator"), ), // src/shared/discount.js:30
"Get 80% OFF Forminator Pro" => array( null, __("Get 80% OFF Forminator Pro", "forminator"), ), // src/shared/discount.js:35
"Pay only" => array( null, __("Pay only", "forminator"), ), // src/shared/discount.js:39
"year" => array( null, __("year", "forminator"), ), // src/shared/discount.js:40
"Start collecting subscription payments in Forminator Pro with the new Stripe Subscription add-on! Upgrade now and get 80% OFF all annual plans." => array( null, __("Start collecting subscription payments in Forminator Pro with the new Stripe Subscription add-on! Upgrade now and get 80% OFF all annual plans.", "forminator"), ), // src/shared/discount.js:43
"You have unsaved changes, are you sure want to leave this page" => array( null, __("You have unsaved changes, are you sure want to leave this page", "forminator"), ), // src/settings-page/appearance-presets.js:54
"Something went wrong. Please try again." => array( null, __("Something went wrong. Please try again.", "forminator"), ), // src/settings-page/appearance-presets.js:101
"Loading Preset data..." => array( null, __("Loading Preset data...", "forminator"), ), // src/settings-page/appearance-presets.js:118
"New appearance preset created successfully." => array( null, __("New appearance preset created successfully.", "forminator"), ), // src/settings-page/appearance-presets.js:178
"Unsaved Changes" => array( null, __("Unsaved Changes", "forminator"), ), // src/settings-page/appearance-presets.js:193
"Add permissions" => array( null, __("Add permissions", "forminator"), ), // src/settings-page/global/footer.js:43
"Permissions" => array( null, __("Permissions", "forminator"), ), // src/settings-page/components/permissions.js:20
"By default, all administrators have complete access to Forminator. You can provide and manage access to other user roles or to individual user(s) below." => array( null, __("By default, all administrators have complete access to Forminator. You can provide and manage access to other user roles or to individual user(s) below.", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:32
"User Role/User" => array( null, __("User Role/User", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:42
"Modules" => array( null, __("Modules", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:43
"Templates" => array( null, __("Templates", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:44
"Submissions" => array( null, __("Submissions", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:45
"Add-ons" => array( null, __("Add-ons", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:46
"Integrations" => array( null, __("Integrations", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:47
"Reports" => array( null, __("Reports", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:48
"Settings" => array( null, __("Settings", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:49
"Actions" => array( null, __("Actions", "forminator"), ), // src/settings-page/components/permissions/permissions-table.js:50
"Administrator" => array( null, __("Administrator", "forminator"), ), // src/settings-page/components/permissions/permission-item.js:121
"All" => array( null, __("All", "forminator"), ), // src/settings-page/components/permissions/permission-item.js:122
" except " => array( null, __(" except ", "forminator"), ), // src/settings-page/components/permissions/permission-item.js:132
"more" => array( null, __("more", "forminator"), ), // src/settings-page/components/permissions/permission-item.js:143
" users" => array( null, __(" users", "forminator"), ), // src/settings-page/components/permissions/permission-item.js:145
"Permission options" => array( null, __("Permission options", "forminator"), ), // src/settings-page/components/permissions/permission-item.js:203
"Edit" => array( null, __("Edit", "forminator"), ), // src/settings-page/components/permissions/permission-item.js:212
"Delete" => array( null, __("Delete", "forminator"), ), // src/settings-page/components/permissions/permission-item.js:221
"Can" => array( null, __("Can", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:19
"Can't" => array( null, __("Can't", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:22
"create, edit, and delete modules (Forms, Polls, and Quizzes)." => array( null, __("create, edit, and delete modules (Forms, Polls, and Quizzes).", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:31
"create, edit, and delete templates." => array( null, __("create, edit, and delete templates.", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:35
"view and delete submissions." => array( null, __("view and delete submissions.", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:39
"configure add-ons." => array( null, __("configure add-ons.", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:43
"configure integrations." => array( null, __("configure integrations.", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:47
"configure reports." => array( null, __("configure reports.", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:51
"configure all settings." => array( null, __("configure all settings.", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:56
"configure settings." => array( null, __("configure settings.", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:58
"configure settings except permissions." => array( null, __("configure settings except permissions.", "forminator"), ), // src/settings-page/components/permissions/permission-icon.js:60
"Click to search a user…" => array( null, __("Click to search a user…", "forminator"), ), // src/settings-page/components/modals/permissions.js:128
"Searching" => array( null, __("Searching", "forminator"), ), // src/settings-page/components/modals/permissions.js:131
"User not found" => array( null, __("User not found", "forminator"), ), // src/settings-page/components/modals/permissions.js:134
"New permission added successfully!" => array( null, __("New permission added successfully!", "forminator"), ), // src/settings-page/components/modals/permissions.js:268
"Permission updated successfully!" => array( null, __("Permission updated successfully!", "forminator"), ), // src/settings-page/components/modals/permissions.js:269
"no user selected" => array( null, __("no user selected", "forminator"), ), // src/settings-page/components/modals/permissions.js:303
"no role selected" => array( null, __("no role selected", "forminator"), ), // src/settings-page/components/modals/permissions.js:311
"no permissions checked" => array( null, __("no permissions checked", "forminator"), ), // src/settings-page/components/modals/permissions.js:330
"Add Permissions" => array( null, __("Add Permissions", "forminator"), ), // src/settings-page/components/modals/permissions.js:361
"Update Permissions" => array( null, __("Update Permissions", "forminator"), ), // src/settings-page/components/modals/permissions.js:370
"User Role" => array( null, __("User Role", "forminator"), ), // src/settings-page/components/modals/permissions.js:373
"You are editing permissions for the {{b}}%(role)s{{/b}} user role." => array( null, __("You are editing permissions for the {{b}}%(role)s{{/b}} user role.", "forminator"), ), // src/settings-page/components/modals/permissions.js:375
"Specific User" => array( null, __("Specific User", "forminator"), ), // src/settings-page/components/modals/permissions.js:391
"You are editing permissions for {{b}}%(userName)s{{/b}}" => array( null, __("You are editing permissions for {{b}}%(userName)s{{/b}}", "forminator"), ), // src/settings-page/components/modals/permissions.js:393
" others." => array( null, __(" others.", "forminator"), ), // src/settings-page/components/modals/permissions.js:412
" other." => array( null, __(" other.", "forminator"), ), // src/settings-page/components/modals/permissions.js:414
"Customize %s Permissions" => array( null, __("Customize %s Permissions", "forminator"), ), // src/settings-page/components/modals/permissions.js:425
"User Role/Users" => array( null, __("User Role/Users", "forminator"), ), // src/settings-page/components/modals/permissions.js:452
"Choose which user role or individual user(s) should have access to the Forminator features selected in the Permissions section below." => array( null, __("Choose which user role or individual user(s) should have access to the Forminator features selected in the Permissions section below.", "forminator"), ), // src/settings-page/components/modals/permissions.js:455
"Choose user role" => array( null, __("Choose user role", "forminator"), ), // src/settings-page/components/modals/permissions.js:478
"Exclude users" => array( null, __("Exclude users", "forminator"), ), // src/settings-page/components/modals/permissions.js:494
"Use this option to exclude specific users with the selected role from accessing Forminator." => array( null, __("Use this option to exclude specific users with the selected role from accessing Forminator.", "forminator"), ), // src/settings-page/components/modals/permissions.js:498
"Choose users" => array( null, __("Choose users", "forminator"), ), // src/settings-page/components/modals/permissions.js:517
"Choose what permissions the selected user role or users will have." => array( null, __("Choose what permissions the selected user role or users will have.", "forminator"), ), // src/settings-page/components/modals/permissions.js:588
"Create, edit, and delete modules (Forms, Polls, Quizzes)." => array( null, __("Create, edit, and delete modules (Forms, Polls, Quizzes).", "forminator"), ), // src/settings-page/components/modals/permissions.js:603
"View templates page and manage cloud templates." => array( null, __("View templates page and manage cloud templates.", "forminator"), ), // src/settings-page/components/modals/permissions.js:617
"Access, export, and delete submissions." => array( null, __("Access, export, and delete submissions.", "forminator"), ), // src/settings-page/components/modals/permissions.js:631
"View, install/uninstall, and configure Add-ons." => array( null, __("View, install/uninstall, and configure Add-ons.", "forminator"), ), // src/settings-page/components/modals/permissions.js:647
"Access and configure global integrations." => array( null, __("Access and configure global integrations.", "forminator"), ), // src/settings-page/components/modals/permissions.js:663
"View reports and schedule email notifications for modules." => array( null, __("View reports and schedule email notifications for modules.", "forminator"), ), // src/settings-page/components/modals/permissions.js:678
"Access and configure plugin settings." => array( null, __("Access and configure plugin settings.", "forminator"), ), // src/settings-page/components/modals/permissions.js:694
"Cancel" => array( null, __("Cancel", "forminator"), ), // src/settings-page/components/modals/permissions.js:709
"Permission successfully deleted." => array( null, __("Permission successfully deleted.", "forminator"), ), // src/settings-page/components/modals/permission-delete.js:66
"Are you sure you wish to delete the permissions rule for the {{b}}%(role)s{{/b}} user role?" => array( null, __("Are you sure you wish to delete the permissions rule for the {{b}}%(role)s{{/b}} user role?", "forminator"), ), // src/settings-page/components/modals/permission-delete.js:86
"Are you sure you wish to delete the permissions for {{b}}%(firstName)s{{/b}} " => array( null, __("Are you sure you wish to delete the permissions for {{b}}%(firstName)s{{/b}} ", "forminator"), ), // src/settings-page/components/modals/permission-delete.js:98
"and %(extra)s other user(s)?" => array( null, __("and %(extra)s other user(s)?", "forminator"), ), // src/settings-page/components/modals/permission-delete.js:111
"Delete Permissions" => array( null, __("Delete Permissions", "forminator"), ), // src/settings-page/components/modals/permission-delete.js:138
"Required Fields" => array( null, __("Required Fields", "forminator"), ), // src/settings/inputs/wp-editor.js:234
"Optional Fields" => array( null, __("Optional Fields", "forminator"), ), // src/settings/inputs/wp-editor.js:246
"Misc Data" => array( null, __("Misc Data", "forminator"), ), // src/settings/inputs/wp-editor.js:262
"Payment Data" => array( null, __("Payment Data", "forminator"), ), // src/settings/inputs/wp-editor.js:311
"Form Name" => array( null, __("Form Name", "forminator"), ), // src/settings/inputs/wp-editor.js:352
"All Form Fields" => array( null, __("All Form Fields", "forminator"), ), // src/settings/inputs/wp-editor.js:362
"All Non Empty Fields" => array( null, __("All Non Empty Fields", "forminator"), ), // src/settings/inputs/wp-editor.js:372
"This field is required!" => array( null, __("This field is required!", "forminator"), ), // src/settings/inputs/wp-editor.js:420
"Add form data" => array( null, __("Add form data", "forminator"), ), // src/settings/inputs/wp-editor.js:433
"Insert form fields" => array( null, __("Insert form fields", "forminator"), ), // src/settings/inputs/wp-editor.js:437
"Select image" => array( null, __("Select image", "forminator"), ), // src/settings/inputs/uploads.js:37
"Select|verb" => array( null, _x("Select", "verb", "forminator"), ), // src/settings/inputs/uploads.js:39
"Upload image" => array( null, __("Upload image", "forminator"), ), // src/settings/inputs/uploads.js:139
"Upload file" => array( null, __("Upload file", "forminator"), ), // src/settings/inputs/uploads.js:140
"Remove uploaded image" => array( null, __("Remove uploaded image", "forminator"), ), // src/settings/inputs/uploads.js:161
"Remove uploaded file" => array( null, __("Remove uploaded file", "forminator"), ), // src/settings/inputs/uploads.js:162
"{{span}}0{{/span}} / {{limit/}} characters" => array( null, __("{{span}}0{{/span}} / {{limit/}} characters", "forminator"), ), // src/settings/inputs/textarea.js:82
"+ Insert form fields" => array( null, __("+ Insert form fields", "forminator"), ), // src/settings/inputs/sui-variables.js:76
"Insert form data" => array( null, __("Insert form data", "forminator"), ), // src/settings/inputs/sui-variables.js:148
"No available options" => array( null, __("No available options", "forminator"), ), // src/settings/inputs/sui-variables.js:150
"+ Predefined options" => array( null, __("+ Predefined options", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:105
"My Label; my-value; 0; https://mysite.com/my-image-url.jpg" => array( null, __("My Label; my-value; 0; https://mysite.com/my-image-url.jpg", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:119
"My Label; my-value; 0" => array( null, __("My Label; my-value; 0", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:120
"New option" => array( null, __("New option", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:138
"New option with image" => array( null, __("New option with image", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:143
"Under 1 year
1-17
18-24
25-34
35-44
45-54
55-64
65 and Above" => array( null, __("Under 1 year
1-17
18-24
25-34
35-44
45-54
55-64
65 and Above", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:149
"Age" => array( null, __("Age", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:154
"Male
Female
Non-binary
Other" => array( null, __("Male
Female
Non-binary
Other", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:157
"Gender" => array( null, __("Gender", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:158
"Primary School
High School
Some College
Associate's Degree
Bachelor's Degree
Master's degree
Professional degree
Doctoral degree
Other" => array( null, __("Primary School
High School
Some College
Associate's Degree
Bachelor's Degree
Master's degree
Professional degree
Doctoral degree
Other", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:163
"Educational Attainment" => array( null, __("Educational Attainment", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:168
"Full-time employed
Part-time employed
Self-employed
Contract Worker
Homemaker
Retired
Student
Unemployed" => array( null, __("Full-time employed
Part-time employed
Self-employed
Contract Worker
Homemaker
Retired
Student
Unemployed", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:173
"Employment Status" => array( null, __("Employment Status", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:178
"Architecture and Engineering
Arts, Design, Entertainment, Sports, and Media
Building and Grounds Cleaning and Maintenance
Business and Financial Operations
Community and Social Services
Computer and Mathematical
Construction and Extraction
Educational Instruction and Library
Farming, Fishing, and Forestry
Food Preparation and Serving Related
Healthcare Practitioners and Technical
Healthcare Support
Installation, Maintenance, and Repair
Legal
Life, Physical, and Social Science
Management
Office and Administrative Support
Personal Care and Services
Production/Manufacturing
Protective Service
Sales and Related
Transportation and Material Moving" => array( null, __("Architecture and Engineering
Arts, Design, Entertainment, Sports, and Media
Building and Grounds Cleaning and Maintenance
Business and Financial Operations
Community and Social Services
Computer and Mathematical
Construction and Extraction
Educational Instruction and Library
Farming, Fishing, and Forestry
Food Preparation and Serving Related
Healthcare Practitioners and Technical
Healthcare Support
Installation, Maintenance, and Repair
Legal
Life, Physical, and Social Science
Management
Office and Administrative Support
Personal Care and Services
Production/Manufacturing
Protective Service
Sales and Related
Transportation and Material Moving", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:183
"Occupation" => array( null, __("Occupation", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:199
"Single
Married
Divorced
Separated
Widowed" => array( null, __("Single
Married
Divorced
Separated
Widowed", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:203
"Marital Status" => array( null, __("Marital Status", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:205
"Africa
Antarctica
Asia
Australia
Europe
North America
South America" => array( null, __("Africa
Antarctica
Asia
Australia
Europe
North America
South America", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:210
"Continents" => array( null, __("Continents", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:213
"Afghanistan
Åland Islands
Albania
Algeria
American Samoa
Andorra
Angola
Anguilla
Antarctica
Antigua and Barbuda
Argentina
Armenia
Aruba
Australia
Austria
Azerbaijan
Bahamas
Bahrain
Bangladesh
Barbados
Belarus
Belgium
Belize
Benin
Bermuda
Bhutan
Bolivia
Bonaire, Sint Eustatius and Saba
Bosnia and Herzegovina
Botswana
Bouvet Island
Brazil
British Indian Ocean Territory
Brunei Darussalam
Bulgaria
Burkina Faso
Burundi
Cabo Verde
Cambodia
Cameroon
Canada
Cayman Islands
Central African Republic
Chad
Chile
China
Christmas Island
Cocos Islands
Colombia
Comoros
Congo, Democratic Republic of the
Congo, Republic of the
Cook Islands
Costa Rica
Côte d'Ivoire
Croatia
Cuba
Curaçao
Cyprus
Czech Republic
Denmark
Djibouti
Dominica
Dominican Republic
Ecuador
Egypt
El Salvador
Equatorial Guinea
Eritrea
Estonia
Eswatini
Ethiopia
Falkland Islands
Faroe Islands
Fiji
Finland
France
French Guiana
French Polynesia
French Southern Territories
Gabon
Gambia
Georgia
Germany
Ghana
Gibraltar
Greece
Greenland
Grenada
Guadeloupe
Guam
Guatemala
Guernsey
Guinea
Guinea-Bissau
Guyana
Haiti
Heard and McDonald Islands
Holy See
Honduras
Hong Kong
Hungary
Iceland
India
Indonesia
Iran
Iraq
Ireland
Isle of Man
Israel
Italy
Jamaica
Japan
Jersey
Jordan
Kazakhstan
Kenya
Kiribati
Kuwait
Kyrgyzstan
Lao People's Democratic Republic
Latvia
Lebanon
Lesotho
Liberia
Libya
Liechtenstein
Lithuania
Luxembourg
Macau
Madagascar
Malawi
Malaysia
Maldives
Mali
Malta
Marshall Islands
Martinique
Mauritania
Mauritius
Mayotte
Mexico
Micronesia
Moldova
Monaco
Mongolia
Montenegro
Montserrat
Morocco
Mozambique
Myanmar
Namibia
Nauru
Nepal
Netherlands
New Caledonia
New Zealand
Nicaragua
Niger
Nigeria
Niue
Norfolk Island
North Korea
North Macedonia
Northern Mariana Islands
Norway
Oman
Pakistan
Palau
Palestine, State of
Panama
Papua New Guinea
Paraguay
Peru
Philippines
Pitcairn
Poland
Portugal
Puerto Rico
Qatar
Réunion
Romania
Russia
Rwanda
Saint Barthélemy
Saint Helena, Ascension and Tristan da Cunha
Saint Kitts and Nevis
Saint Lucia
Saint Martin
Saint Pierre and Miquelon
Saint Vincent and the Grenadines
Samoa
San Marino
Sao Tome and Principe
Saudi Arabia
Senegal
Serbia
Seychelles
Sierra Leone
Singapore
Sint Maarten
Slovakia
Slovenia
Solomon Islands
Somalia
South Africa
South Georgia and the South Sandwich Islands
South Korea
South Sudan
Spain
Sri Lanka
Sudan
Suriname
Svalbard and Jan Mayen Islands
Sweden
Switzerland
Syria
Taiwan
Tajikistan
Tanzania
Thailand
Timor-Leste
Togo
Tokelau
Tonga
Trinidad and Tobago
Tunisia
Turkey
Turkmenistan
Turks and Caicos Islands
Tuvalu
Uganda
Ukraine
United Arab Emirates
United Kingdom
United States
Uruguay
US Minor Outlying Islands
Uzbekistan
Vanuatu
Venezuela
Vietnam
Virgin Islands, British
Virgin Islands, U.S.
Wallis and Futuna
Western Sahara
Yemen
Zambia
Zimbabwe" => array( null, __("Afghanistan
Åland Islands
Albania
Algeria
American Samoa
Andorra
Angola
Anguilla
Antarctica
Antigua and Barbuda
Argentina
Armenia
Aruba
Australia
Austria
Azerbaijan
Bahamas
Bahrain
Bangladesh
Barbados
Belarus
Belgium
Belize
Benin
Bermuda
Bhutan
Bolivia
Bonaire, Sint Eustatius and Saba
Bosnia and Herzegovina
Botswana
Bouvet Island
Brazil
British Indian Ocean Territory
Brunei Darussalam
Bulgaria
Burkina Faso
Burundi
Cabo Verde
Cambodia
Cameroon
Canada
Cayman Islands
Central African Republic
Chad
Chile
China
Christmas Island
Cocos Islands
Colombia
Comoros
Congo, Democratic Republic of the
Congo, Republic of the
Cook Islands
Costa Rica
Côte d'Ivoire
Croatia
Cuba
Curaçao
Cyprus
Czech Republic
Denmark
Djibouti
Dominica
Dominican Republic
Ecuador
Egypt
El Salvador
Equatorial Guinea
Eritrea
Estonia
Eswatini
Ethiopia
Falkland Islands
Faroe Islands
Fiji
Finland
France
French Guiana
French Polynesia
French Southern Territories
Gabon
Gambia
Georgia
Germany
Ghana
Gibraltar
Greece
Greenland
Grenada
Guadeloupe
Guam
Guatemala
Guernsey
Guinea
Guinea-Bissau
Guyana
Haiti
Heard and McDonald Islands
Holy See
Honduras
Hong Kong
Hungary
Iceland
India
Indonesia
Iran
Iraq
Ireland
Isle of Man
Israel
Italy
Jamaica
Japan
Jersey
Jordan
Kazakhstan
Kenya
Kiribati
Kuwait
Kyrgyzstan
Lao People's Democratic Republic
Latvia
Lebanon
Lesotho
Liberia
Libya
Liechtenstein
Lithuania
Luxembourg
Macau
Madagascar
Malawi
Malaysia
Maldives
Mali
Malta
Marshall Islands
Martinique
Mauritania
Mauritius
Mayotte
Mexico
Micronesia
Moldova
Monaco
Mongolia
Montenegro
Montserrat
Morocco
Mozambique
Myanmar
Namibia
Nauru
Nepal
Netherlands
New Caledonia
New Zealand
Nicaragua
Niger
Nigeria
Niue
Norfolk Island
North Korea
North Macedonia
Northern Mariana Islands
Norway
Oman
Pakistan
Palau
Palestine, State of
Panama
Papua New Guinea
Paraguay
Peru
Philippines
Pitcairn
Poland
Portugal
Puerto Rico
Qatar
Réunion
Romania
Russia
Rwanda
Saint Barthélemy
Saint Helena, Ascension and Tristan da Cunha
Saint Kitts and Nevis
Saint Lucia
Saint Martin
Saint Pierre and Miquelon
Saint Vincent and the Grenadines
Samoa
San Marino
Sao Tome and Principe
Saudi Arabia
Senegal
Serbia
Seychelles
Sierra Leone
Singapore
Sint Maarten
Slovakia
Slovenia
Solomon Islands
Somalia
South Africa
South Georgia and the South Sandwich Islands
South Korea
South Sudan
Spain
Sri Lanka
Sudan
Suriname
Svalbard and Jan Mayen Islands
Sweden
Switzerland
Syria
Taiwan
Tajikistan
Tanzania
Thailand
Timor-Leste
Togo
Tokelau
Tonga
Trinidad and Tobago
Tunisia
Turkey
Turkmenistan
Turks and Caicos Islands
Tuvalu
Uganda
Ukraine
United Arab Emirates
United Kingdom
United States
Uruguay
US Minor Outlying Islands
Uzbekistan
Vanuatu
Venezuela
Vietnam
Virgin Islands, British
Virgin Islands, U.S.
Wallis and Futuna
Western Sahara
Yemen
Zambia
Zimbabwe", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:218
"Countries" => array( null, __("Countries", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:280
"Alabama
Alaska
Arizona
Arkansas
California
Colorado
Connecticut
Delaware
District of Columbia
Florida
Georgia
Hawaii
Idaho
Illinois
Indiana
Iowa
Kansas
Kentucky
Louisiana
Maine
Maryland
Massachusetts
Michigan
Minnesota
Mississippi
Missouri
Montana
Nebraska
Nevada
New Hampshire
New Jersey
New Mexico
New York
North Carolina
North Dakota
Ohio
Oklahoma
Oregon
Pennsylvania
Rhode Island
South Carolina
South Dakota
Tennessee
Texas
Utah
Vermont
Virginia
Washington
West Virginia
Wisconsin
Wyoming" => array( null, __("Alabama
Alaska
Arizona
Arkansas
California
Colorado
Connecticut
Delaware
District of Columbia
Florida
Georgia
Hawaii
Idaho
Illinois
Indiana
Iowa
Kansas
Kentucky
Louisiana
Maine
Maryland
Massachusetts
Michigan
Minnesota
Mississippi
Missouri
Montana
Nebraska
Nevada
New Hampshire
New Jersey
New Mexico
New York
North Carolina
North Dakota
Ohio
Oklahoma
Oregon
Pennsylvania
Rhode Island
South Carolina
South Dakota
Tennessee
Texas
Utah
Vermont
Virginia
Washington
West Virginia
Wisconsin
Wyoming", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:284
"American States" => array( null, __("American States", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:285
"Alberta
British Columbia
Manitoba
New Brunswick
Newfoundland and Labrador
Northwest Territories
Nova Scotia
Nunavut
Ontario
Prince Edward Island
Quebec
Saskatchewan
Yukon" => array( null, __("Alberta
British Columbia
Manitoba
New Brunswick
Newfoundland and Labrador
Northwest Territories
Nova Scotia
Nunavut
Ontario
Prince Edward Island
Quebec
Saskatchewan
Yukon", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:289
"Canadian Provinces" => array( null, __("Canadian Provinces", "forminator"), ), // src/settings/inputs/sui-variables-bulk-editor.js:290
"Click here to add a date…" => array( null, __("Click here to add a date…", "forminator"), ), // src/settings/inputs/sui-tags-datepicker.js:25
"Click here to add a date range..." => array( null, __("Click here to add a date range...", "forminator"), ), // src/settings/inputs/sui-tags-date-range.js:25
"Please enter valid number." => array( null, __("Please enter valid number.", "forminator"), ), // src/settings/inputs/input.js:52
"Use the following formats to style your text: *bold*, _italic_, ~strikethrough~, `monospace`" => array( null, __("Use the following formats to style your text: *bold*, _italic_, ~strikethrough~, `monospace`", "forminator"), ), // src/settings/inputs/input.js:105
"Text styles" => array( null, __("Text styles", "forminator"), ), // src/settings/inputs/input.js:108
"Date" => array( null, __("Date", "forminator"), ), // src/settings/inputs/date-time-picker.js:151
"10 January 2020" => array( null, __("10 January 2020", "forminator"), ), // src/settings/inputs/date-time-picker.js:154
"AM/PM" => array( null, __("AM/PM", "forminator"), ), // src/settings/inputs/date-time-picker.js:198
"Remove this date range" => array( null, __("Remove this date range", "forminator"), ), // src/settings/inputs/date-range-picker.js:83
"Add selected date" => array( null, __("Add selected date", "forminator"), ), // src/settings/inputs/date-range-picker.js:94
"%s is disabled for calculations. Please insert a valid field from the merged tags option." => array( null, __("%s is disabled for calculations. Please insert a valid field from the merged tags option.", "forminator"), ), // src/settings/inputs/calculation.js:176
"%s does not exist in your form. Please insert a valid field from the merged tags option." => array( null, __("%s does not exist in your form. Please insert a valid field from the merged tags option.", "forminator"), ), // src/settings/inputs/calculation.js:197
"Calculation formula is required!" => array( null, __("Calculation formula is required!", "forminator"), ), // src/settings/inputs/calculation.js:218
"Infinity calculation result." => array( null, __("Infinity calculation result.", "forminator"), ), // src/settings/inputs/calculation.js:232
" (all)" => array( null, __(" (all)", "forminator"), ), // src/settings/inputs/calculation.js:287
"Calculation Formula" => array( null, __("Calculation Formula", "forminator"), ), // src/settings/inputs/calculation.js:328
"Add Form Fields" => array( null, __("Add Form Fields", "forminator"), ), // src/settings/inputs/calculation.js:341
"Open list of fields" => array( null, __("Open list of fields", "forminator"), ), // src/settings/inputs/calculation.js:345
"Sum" => array( null, __("Sum", "forminator"), ), // src/settings/inputs/calculation.js:359
"Minus" => array( null, __("Minus", "forminator"), ), // src/settings/inputs/calculation.js:369
"Multiply" => array( null, __("Multiply", "forminator"), ), // src/settings/inputs/calculation.js:379
"Divide" => array( null, __("Divide", "forminator"), ), // src/settings/inputs/calculation.js:389
"Exponentiate" => array( null, __("Exponentiate", "forminator"), ), // src/settings/inputs/calculation.js:399
"Modulus" => array( null, __("Modulus", "forminator"), ), // src/settings/inputs/calculation.js:409
"Open parenthesis" => array( null, __("Open parenthesis", "forminator"), ), // src/settings/inputs/calculation.js:419
"Close parenthesis" => array( null, __("Close parenthesis", "forminator"), ), // src/settings/inputs/calculation.js:429
"Comma" => array( null, __("Comma", "forminator"), ), // src/settings/inputs/calculation.js:439
"PI constant" => array( null, __("PI constant", "forminator"), ), // src/settings/inputs/calculation.js:449
"Add Function" => array( null, __("Add Function", "forminator"), ), // src/settings/inputs/calculation.js:456
"Open function list" => array( null, __("Open function list", "forminator"), ), // src/settings/inputs/calculation.js:460
"You can preview your form and check if the formula is generating expected results." => array( null, __("You can preview your form and check if the formula is generating expected results.", "forminator"), ), // src/settings/inputs/calculation.js:491
"Formula Preview" => array( null, __("Formula Preview", "forminator"), ), // src/settings/inputs/calculation.js:499
"Basic selectors" => array( null, __("Basic selectors", "forminator"), ), // src/settings/inputs/ace-editor.js:84
"Form" => array( null, __("Form", "forminator"), ), // src/settings/inputs/ace-editor.js:89
"Section Title" => array( null, __("Section Title", "forminator"), ), // src/settings/inputs/ace-editor.js:96
"Section Subtitle" => array( null, __("Section Subtitle", "forminator"), ), // src/settings/inputs/ace-editor.js:103
"Field Label" => array( null, __("Field Label", "forminator"), ), // src/settings/inputs/ace-editor.js:110
"Field Description" => array( null, __("Field Description", "forminator"), ), // src/settings/inputs/ace-editor.js:117
"Input" => array( null, __("Input", "forminator"), ), // src/settings/inputs/ace-editor.js:124
"Textarea" => array( null, __("Textarea", "forminator"), ), // src/settings/inputs/ace-editor.js:131
"Poll" => array( null, __("Poll", "forminator"), ), // src/settings/inputs/ace-editor.js:144
"Question" => array( null, __("Question", "forminator"), ), // src/settings/inputs/ace-editor.js:149
"Answer Input" => array( null, __("Answer Input", "forminator"), ), // src/settings/inputs/ace-editor.js:154
"Answer Label" => array( null, __("Answer Label", "forminator"), ), // src/settings/inputs/ace-editor.js:159
"Submit Button" => array( null, __("Submit Button", "forminator"), ), // src/settings/inputs/ace-editor.js:164
"View Results Link" => array( null, __("View Results Link", "forminator"), ), // src/settings/inputs/ace-editor.js:172
"Quiz" => array( null, __("Quiz", "forminator"), ), // src/settings/inputs/ace-editor.js:185
"Title" => array( null, __("Title", "forminator"), ), // src/settings/inputs/ace-editor.js:190
"Description" => array( null, __("Description", "forminator"), ), // src/settings/inputs/ace-editor.js:195
"Answer Container" => array( null, __("Answer Container", "forminator"), ), // src/settings/inputs/ace-editor.js:205
"Answer Text" => array( null, __("Answer Text", "forminator"), ), // src/settings/inputs/ace-editor.js:212
"PDF selectors" => array( null, __("PDF selectors", "forminator"), ), // src/settings/inputs/ace-editor.js:220
"Body" => array( null, __("Body", "forminator"), ), // src/settings/inputs/ace-editor.js:225
"PDF Header" => array( null, __("PDF Header", "forminator"), ), // src/settings/inputs/ace-editor.js:232
"Logo" => array( null, __("Logo", "forminator"), ), // src/settings/inputs/ace-editor.js:239
"Field Value" => array( null, __("Field Value", "forminator"), ), // src/settings/inputs/ace-editor.js:260
"Group Field Items" => array( null, __("Group Field Items", "forminator"), ), // src/settings/inputs/ace-editor.js:267
"Footer" => array( null, __("Footer", "forminator"), ), // src/settings/inputs/ace-editor.js:274
"Pagination" => array( null, __("Pagination", "forminator"), ), // src/settings/inputs/ace-editor.js:281
"Learn more about using custom CSS in your PDF file {{link}}here{{/link}}." => array( null, __("Learn more about using custom CSS in your PDF file {{link}}here{{/link}}.", "forminator"), ), // src/settings/inputs/ace-editor.js:302
"Open item" => array( null, __("Open item", "forminator"), ), // src/settings/inputs/accordion-toggle.js:95
"Close item" => array( null, __("Close item", "forminator"), ), // src/settings/inputs/accordion-toggle.js:95
"Personalities" => array( null, __("Personalities", "forminator"), ), // src/quiz/personality/components/personalities.js:27
"Let's add the different personalities. Each of the following personality is a possible outcome of your quiz. In case of a tie, the personality is chosen as per their order below." => array( null, __("Let's add the different personalities. Each of the following personality is a possible outcome of your quiz. In case of a tie, the personality is chosen as per their order below.", "forminator"), ), // src/quiz/personality/components/personalities.js:33
"Reorder the personalities to set the priority order." => array( null, __("Reorder the personalities to set the priority order.", "forminator"), ), // src/quiz/personality/components/personalities.js:50
"Customize Quiz" => array( null, __("Customize Quiz", "forminator"), ), // src/quiz/personality/components/navigation.js:11
"Intro" => array( null, __("Intro", "forminator"), ), // src/quiz/personality/components/menu.js:37
"Questions" => array( null, __("Questions", "forminator"), ), // src/quiz/personality/components/menu.js:63
"Leads" => array( null, __("Leads", "forminator"), ), // src/quiz/personality/components/menu.js:77
"Appearance" => array( null, __("Appearance", "forminator"), ), // src/quiz/personality/components/menu.js:91
"Behavior" => array( null, __("Behavior", "forminator"), ), // src/quiz/personality/components/menu.js:104
"Email Notifications" => array( null, __("Email Notifications", "forminator"), ), // src/quiz/personality/components/menu.js:117
"Open field settings" => array( null, __("Open field settings", "forminator"), ), // src/quiz/personality/components/personalities/personality.js:133
"Duplicate" => array( null, __("Duplicate", "forminator"), ), // src/quiz/personality/components/personalities/personality.js:146
"Add Personality" => array( null, __("Add Personality", "forminator"), ), // src/quiz/personality/components/personalities/personalities.js:104
"Define the different personalities possible as the outcome of your quiz here." => array( null, __("Define the different personalities possible as the outcome of your quiz here.", "forminator"), ), // src/quiz/personality/components/personalities/personalities.js:111
"Fonts" => array( null, __("Fonts", "forminator"), ), // src/quiz/personality/components/appearance/fonts.js:16
"By default this quiz will inherit the fonts your theme uses. You can override these fonts with custom ones from {{link}}Bunny Fonts{{/link}}." => array( null, __("By default this quiz will inherit the fonts your theme uses. You can override these fonts with custom ones from {{link}}Bunny Fonts{{/link}}.", "forminator"), ), // src/quiz/personality/components/appearance/fonts.js:18
"Use Theme Fonts" => array( null, __("Use Theme Fonts", "forminator"), ), // src/quiz/personality/components/appearance/fonts.js:39
"Custom" => array( null, __("Custom", "forminator"), ), // src/quiz/personality/components/appearance/fonts.js:47
"Colors" => array( null, __("Colors", "forminator"), ), // src/quiz/personality/components/appearance/colors.js:16
"Adjust the default color combinations to match your theme styling." => array( null, __("Adjust the default color combinations to match your theme styling.", "forminator"), ), // src/quiz/personality/components/appearance/colors.js:18
"Default" => array( null, __("Default", "forminator"), ), // src/quiz/personality/components/appearance/colors.js:32
"Icon size" => array( null, __("Icon size", "forminator"), ), // src/quiz/personality/components/appearance/fonts/social-icons.js:19
"Choose one of the pre-defined sizes we have for social share icons." => array( null, __("Choose one of the pre-defined sizes we have for social share icons.", "forminator"), ), // src/quiz/personality/components/appearance/fonts/social-icons.js:21
"Regular" => array( null, __("Regular", "forminator"), ), // src/quiz/personality/components/appearance/fonts/social-icons.js:25
"Medium" => array( null, __("Medium", "forminator"), ), // src/quiz/personality/components/appearance/fonts/social-icons.js:26
"Large" => array( null, __("Large", "forminator"), ), // src/quiz/personality/components/appearance/fonts/social-icons.js:27
"Quiz Name" => array( null, __("Quiz Name", "forminator"), ), // src/quiz/personality/components/appearance/fonts/quiz-result.js:25
"Retake" => array( null, __("Retake", "forminator"), ), // src/quiz/personality/components/appearance/fonts/quiz-result.js:39
"Content" => array( null, __("Content", "forminator"), ), // src/quiz/personality/components/appearance/fonts/quiz-result.js:65
"Element" => array( null, __("Element", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:31
"Quiz Title" => array( null, __("Quiz Title", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:36
"Quiz Description" => array( null, __("Quiz Description", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:43
"Page Indicator" => array( null, __("Page Indicator", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:51
"Question Description" => array( null, __("Question Description", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:66
"Answer" => array( null, __("Answer", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:73
"Start Quiz Button" => array( null, __("Start Quiz Button", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:81
"Quiz Navigation Buttons" => array( null, __("Quiz Navigation Buttons", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:90
"Quiz Result" => array( null, __("Quiz Result", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:105
"Social Share Title" => array( null, __("Social Share Title", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:112
"Social Share Icons" => array( null, __("Social Share Icons", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:119
"Skip Form Button" => array( null, __("Skip Form Button", "forminator"), ), // src/quiz/personality/components/appearance/fonts/fonts-table.js:127
"Title color" => array( null, __("Title color", "forminator"), ), // src/quiz/personality/components/appearance/colors/social-share.js:19
"Facebook" => array( null, __("Facebook", "forminator"), ), // src/quiz/personality/components/appearance/colors/social-share.js:26
"X" => array( null, __("X", "forminator"), ), // src/quiz/personality/components/appearance/colors/social-share.js:33
"LinkedIn" => array( null, __("LinkedIn", "forminator"), ), // src/quiz/personality/components/appearance/colors/social-share.js:40
"Main" => array( null, __("Main", "forminator"), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:25
"Container border" => array( null, __("Container border", "forminator"), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:34
"Container background" => array( null, __("Container background", "forminator"), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:43
"Header" => array( null, __("Header", "forminator"), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:54
"Background color" => array( null, __("Background color", "forminator"), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:67
"Description color" => array( null, __("Description color", "forminator"), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:91
"Content background" => array( null, __("Content background", "forminator"), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:99
"Basic" => array( null, __("Basic", "forminator"), ), // src/quiz/personality/components/appearance/colors/colors-table.js:30
"Answer - Container" => array( null, __("Answer - Container", "forminator"), ), // src/quiz/personality/components/appearance/colors/colors-table.js:37
"Answer - Checkbox" => array( null, __("Answer - Checkbox", "forminator"), ), // src/quiz/personality/components/appearance/colors/colors-table.js:44
"Answer - Text" => array( null, __("Answer - Text", "forminator"), ), // src/quiz/personality/components/appearance/colors/colors-table.js:51
"Quiz Navigation Button" => array( null, __("Quiz Navigation Button", "forminator"), ), // src/quiz/personality/components/appearance/colors/colors-table.js:68
"Back to Answers Button" => array( null, __("Back to Answers Button", "forminator"), ), // src/quiz/personality/components/appearance/colors/colors-table.js:77
"Retake Button" => array( null, __("Retake Button", "forminator"), ), // src/quiz/personality/components/appearance/colors/colors-table.js:99
"Social Share" => array( null, __("Social Share", "forminator"), ), // src/quiz/personality/components/appearance/colors/colors-table.js:106
"Label color" => array( null, __("Label color", "forminator"), ), // src/quiz/personality/components/appearance/colors/button-submit.js:36
"Hover" => array( null, __("Hover", "forminator"), ), // src/quiz/personality/components/appearance/colors/button-submit.js:45
"Active" => array( null, __("Active", "forminator"), ), // src/quiz/personality/components/appearance/colors/button-submit.js:65
"Main Container" => array( null, __("Main Container", "forminator"), ), // src/quiz/personality/components/appearance/colors/basic.js:20
"Page Indicator color" => array( null, __("Page Indicator color", "forminator"), ), // src/quiz/personality/components/appearance/colors/basic.js:51
"Question color" => array( null, __("Question color", "forminator"), ), // src/quiz/personality/components/appearance/colors/basic.js:59
"Question description color" => array( null, __("Question description color", "forminator"), ), // src/quiz/personality/components/appearance/colors/basic.js:66
"Quiz result color" => array( null, __("Quiz result color", "forminator"), ), // src/quiz/personality/components/appearance/colors/basic.js:93
"Skip form button" => array( null, __("Skip form button", "forminator"), ), // src/quiz/personality/components/appearance/colors/basic.js:100
"Focus" => array( null, __("Focus", "forminator"), ), // src/quiz/personality/components/appearance/colors/basic.js:120
"Answer text color" => array( null, __("Answer text color", "forminator"), ), // src/quiz/personality/components/appearance/colors/answer-text.js:29
"Border color" => array( null, __("Border color", "forminator"), ), // src/quiz/personality/components/appearance/colors/answer-container.js:33
"Checked" => array( null, __("Checked", "forminator"), ), // src/quiz/personality/components/appearance/colors/answer-checkbox.js:49
"Icon color" => array( null, __("Icon color", "forminator"), ), // src/quiz/personality/components/appearance/colors/answer-checkbox.js:71
"Answer Result Message" => array( null, __("Answer Result Message", "forminator"), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:99
"Answer result message" => array( null, __("Answer result message", "forminator"), ), // src/quiz/knowledge/components/appearance/colors/answer-text.js:35
"Right" => array( null, __("Right", "forminator"), ), // src/quiz/knowledge/components/appearance/colors/answer-text.js:55
"Wrong" => array( null, __("Wrong", "forminator"), ), // src/quiz/knowledge/components/appearance/colors/answer-text.js:67
"Evaluation loader icon" => array( null, __("Evaluation loader icon", "forminator"), ), // src/quiz/knowledge/components/appearance/colors/answer-checkbox.js:72
"This picker works only when \"Evaluation Loader\" is set to \"Show Loader\"." => array( null, __("This picker works only when \"Evaluation Loader\" is set to \"Show Loader\".", "forminator"), ), // src/quiz/knowledge/components/appearance/colors/answer-checkbox.js:74
"You can send customized email notifications to your site admins and participant on successful quiz submission. Use advanced features such as email routing, and conditions to have granular control over them." => array( null, __("You can send customized email notifications to your site admins and participant on successful quiz submission. Use advanced features such as email routing, and conditions to have granular control over them.", "forminator"), ), // src/quiz/global/components/notifications.js:32
"Something went wrong while reverting your quiz. Please try again." => array( null, __("Something went wrong while reverting your quiz. Please try again.", "forminator"), ), // src/quiz/global/components/meta.js:139
"Something went wrong while saving your quiz. Please try again." => array( null, __("Something went wrong while saving your quiz. Please try again.", "forminator"), ), // src/quiz/global/components/meta.js:235
"Capture Leads" => array( null, __("Capture Leads", "forminator"), ), // src/quiz/global/components/leads.js:38
"Collect participants' details (e.g. name, email, etc.) by integrating a lead generation form in your quiz." => array( null, __("Collect participants' details (e.g. name, email, etc.) by integrating a lead generation form in your quiz.", "forminator"), ), // src/quiz/global/components/leads.js:40
"Lead generation form" => array( null, __("Lead generation form", "forminator"), ), // src/quiz/global/components/leads.js:50
"Customize the default lead generation form using the edit button below. Note that this lead generation form has limited settings only, and the rest of them are either automatically set by this quiz or they are shared between this quiz and the lead generation form (such as Email Notifications, Integrations, etc.)." => array( null, __("Customize the default lead generation form using the edit button below. Note that this lead generation form has limited settings only, and the rest of them are either automatically set by this quiz or they are shared between this quiz and the lead generation form (such as Email Notifications, Integrations, etc.).", "forminator"), ), // src/quiz/global/components/leads.js:58
"%s - Leads form" => array( null, __("%s - Leads form", "forminator"), ), // src/quiz/global/components/leads.js:75
"Edit Form" => array( null, __("Edit Form", "forminator"), ), // src/quiz/global/components/leads.js:81
"Form Placement" => array( null, __("Form Placement", "forminator"), ), // src/quiz/global/components/leads.js:109
"Where do you want to embed the lead generation form in your quiz?" => array( null, __("Where do you want to embed the lead generation form in your quiz?", "forminator"), ), // src/quiz/global/components/leads.js:111
"Beginning of quiz" => array( null, __("Beginning of quiz", "forminator"), ), // src/quiz/global/components/leads.js:117
"Before showing results" => array( null, __("Before showing results", "forminator"), ), // src/quiz/global/components/leads.js:121
"Skip Form" => array( null, __("Skip Form", "forminator"), ), // src/quiz/global/components/leads.js:131
"Enable this option if you want to allow your participants to skip the form." => array( null, __("Enable this option if you want to allow your participants to skip the form.", "forminator"), ), // src/quiz/global/components/leads.js:133
"Enable" => array( null, __("Enable", "forminator"), ), // src/quiz/global/components/leads.js:141
"Link text" => array( null, __("Link text", "forminator"), ), // src/quiz/global/components/leads.js:144
"Skip and continue" => array( null, __("Skip and continue", "forminator"), ), // src/quiz/global/components/leads.js:145
"Disable" => array( null, __("Disable", "forminator"), ), // src/quiz/global/components/leads.js:151
"Quiz created successfully." => array( null, __("Quiz created successfully.", "forminator"), ), // src/quiz/global/components/intro.js:29
"Start by adding a title for your quiz to let your visitors know what this quiz is all about." => array( null, __("Start by adding a title for your quiz to let your visitors know what this quiz is all about.", "forminator"), ), // src/quiz/global/components/intro.js:46
"Which superhero are you?" => array( null, __("Which superhero are you?", "forminator"), ), // src/quiz/global/components/intro.js:60
"Choose a title to grab the attention of your visitors." => array( null, __("Choose a title to grab the attention of your visitors.", "forminator"), ), // src/quiz/global/components/intro.js:61
"Feature Image" => array( null, __("Feature Image", "forminator"), ), // src/quiz/global/components/intro.js:73
"Upload a nice feature image for your quiz." => array( null, __("Upload a nice feature image for your quiz.", "forminator"), ), // src/quiz/global/components/intro.js:77
"Upload Feature Image" => array( null, __("Upload Feature Image", "forminator"), ), // src/quiz/global/components/intro.js:89
"Provide your visitors with more information about your quiz." => array( null, __("Provide your visitors with more information about your quiz.", "forminator"), ), // src/quiz/global/components/intro.js:106
"Fetching integration list…" => array( null, __("Fetching integration list…", "forminator"), ), // src/quiz/global/components/integrations.js:110
"You need to save this quiz before using integrations." => array( null, __("You need to save this quiz before using integrations.", "forminator"), ), // src/quiz/global/components/integrations.js:121
"TRY AGAIN" => array( null, __("TRY AGAIN", "forminator"), ), // src/quiz/global/components/integrations.js:124
"forever" => array( null, __("forever", "forminator"), ), // src/quiz/global/components/settings/privacy.js:22
"Privacy" => array( null, __("Privacy", "forminator"), ), // src/quiz/global/components/settings/privacy.js:35
"Choose how you want to handle this quiz's data storage. By default we'll use the configuration you've set in your " => array( null, __("Choose how you want to handle this quiz's data storage. By default we'll use the configuration you've set in your ", "forminator"), ), // src/quiz/global/components/settings/privacy.js:38
"global privacy settings." => array( null, __("global privacy settings.", "forminator"), ), // src/quiz/global/components/settings/privacy.js:43
"How long do you want to retain this quiz's submissions for?" => array( null, __("How long do you want to retain this quiz's submissions for?", "forminator"), ), // src/quiz/global/components/settings/privacy.js:58
"Use default" => array( null, __("Use default", "forminator"), ), // src/quiz/global/components/settings/privacy.js:67
"Your default setting value is to keep the submissions %s." => array( null, __("Your default setting value is to keep the submissions %s.", "forminator"), ), // src/quiz/global/components/settings/privacy.js:74
"day(s)" => array( null, __("day(s)", "forminator"), ), // src/quiz/global/components/settings/privacy.js:107
"week(s)" => array( null, __("week(s)", "forminator"), ), // src/quiz/global/components/settings/privacy.js:108
"month(s)" => array( null, __("month(s)", "forminator"), ), // src/quiz/global/components/settings/privacy.js:109
"year(s)" => array( null, __("year(s)", "forminator"), ), // src/quiz/global/components/settings/privacy.js:110
"Set the value to \"0\" or leave it blank to store submissions forever." => array( null, __("Set the value to \"0\" or leave it blank to store submissions forever.", "forminator"), ), // src/quiz/global/components/settings/privacy.js:116
"Custom font family" => array( null, __("Custom font family", "forminator"), ), // src/quiz/global/components/settings/fonts.js:59
"E.g., Arial, sans-serif" => array( null, __("E.g., Arial, sans-serif", "forminator"), ), // src/quiz/global/components/settings/fonts.js:60
"Font Family" => array( null, __("Font Family", "forminator"), ), // src/quiz/global/components/settings/fonts.js:75
"Roboto" => array( null, __("Roboto", "forminator"), ), // src/quiz/global/components/settings/fonts.js:76
"inherit" => array( null, __("inherit", "forminator"), ), // src/quiz/global/components/settings/fonts.js:94
"Custom user font" => array( null, __("Custom user font", "forminator"), ), // src/quiz/global/components/settings/fonts.js:100
"Font Size" => array( null, __("Font Size", "forminator"), ), // src/quiz/global/components/settings/fonts.js:114
"e.g., 0.75em" => array( null, __("e.g., 0.75em", "forminator"), ), // src/quiz/global/components/settings/fonts.js:115
"Font Weight" => array( null, __("Font Weight", "forminator"), ), // src/quiz/global/components/settings/fonts.js:123
"Select font weight" => array( null, __("Select font weight", "forminator"), ), // src/quiz/global/components/settings/fonts.js:124
"Data Storage" => array( null, __("Data Storage", "forminator"), ), // src/quiz/global/components/settings/data-storage.js:15
"By default we'll store all submissions in your database." => array( null, __("By default we'll store all submissions in your database.", "forminator"), ), // src/quiz/global/components/settings/data-storage.js:17
"Store Submissions in Database" => array( null, __("Store Submissions in Database", "forminator"), ), // src/quiz/global/components/settings/data-storage.js:25
"Disable this feature to prevent submissions from being stored in your database. Note that any submissions previously stored in the database will be retained and automatically deleted according to the retention schedule configured in the Privacy settings below." => array( null, __("Disable this feature to prevent submissions from being stored in your database. Note that any submissions previously stored in the database will be retained and automatically deleted according to the retention schedule configured in the Privacy settings below.", "forminator"), ), // src/quiz/global/components/settings/data-storage.js:27
"Add Email Notification" => array( null, __("Add Email Notification", "forminator"), ), // src/quiz/global/components/notifications/notifications.js:57
"Do not Send Email" => array( null, __("Do not Send Email", "forminator"), ), // src/quiz/global/components/notifications/notification.js:123
"Send Email" => array( null, __("Send Email", "forminator"), ), // src/quiz/global/components/notifications/notification.js:123
"more condition(s)" => array( null, __("more condition(s)", "forminator"), ), // src/quiz/global/components/notifications/notification.js:178
"if" => array( null, __("if", "forminator"), ), // src/quiz/global/components/notifications/notification.js:185
"Email routing is enabled" => array( null, __("Email routing is enabled", "forminator"), ), // src/quiz/global/components/notifications/notification.js:198
"more recipient(s)" => array( null, __("more recipient(s)", "forminator"), ), // src/quiz/global/components/notifications/notification.js:206
"Add Rule" => array( null, __("Add Rule", "forminator"), ), // src/quiz/global/components/notifications/email-routing.js:173
"You haven't defined any email routing rules yet. Click on the \"+ Add Rule\" button to add the recipients along with the routing rules." => array( null, __("You haven't defined any email routing rules yet. Click on the \"+ Add Rule\" button to add the recipients along with the routing rules.", "forminator"), ), // src/quiz/global/components/notifications/email-routing.js:179
"Final Score" => array( null, __("Final Score", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:98
"Send to {{strong}}\"%(label)s\"{{/strong}} if {{strong}}%(field)s{{/strong}} %(rule)s {{strong}}%(value)s{{/strong}}" => array( null, __("Send to {{strong}}\"%(label)s\"{{/strong}} if {{strong}}%(field)s{{/strong}} %(rule)s {{strong}}%(value)s{{/strong}}", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:161
"E.g. sales@website.com" => array( null, __("E.g. sales@website.com", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:197
"Recipients" => array( null, __("Recipients", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:198
"Separate multiple emails with a comma" => array( null, __("Separate multiple emails with a comma", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:202
"Routing Condition" => array( null, __("Routing Condition", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:226
"Form Data" => array( null, __("Form Data", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:229
"Quiz Data" => array( null, __("Quiz Data", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:238
"Select rule" => array( null, __("Select rule", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:264
"Is correct" => array( null, __("Is correct", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:269
"Is incorrect" => array( null, __("Is incorrect", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:272
"Contains" => array( null, __("Contains", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:280
"Does not contain" => array( null, __("Does not contain", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:283
"greater than" => array( null, __("greater than", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:286
"less than" => array( null, __("less than", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:289
"Is null" => array( null, __("Is null", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:299
"Is not null" => array( null, __("Is not null", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:302
"Is" => array( null, __("Is", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:312
"Is not" => array( null, __("Is not", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:315
"Is greater than" => array( null, __("Is greater than", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:324
"Is less than" => array( null, __("Is less than", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:327
"Starts with" => array( null, __("Starts with", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:345
"Ends with" => array( null, __("Ends with", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:348
"Day is" => array( null, __("Day is", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:360
"Day is not" => array( null, __("Day is not", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:363
"Month is" => array( null, __("Month is", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:376
"Month is not" => array( null, __("Month is not", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:379
"Select option" => array( null, __("Select option", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:405
"Value" => array( null, __("Value", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:426
"Select month" => array( null, __("Select month", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:444
"Select day" => array( null, __("Select day", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:468
"Done" => array( null, __("Done", "forminator"), ), // src/quiz/global/components/notifications/email-routing-rule.js:496
"Send" => array( null, __("Send", "forminator"), ), // src/quiz/global/components/notifications/conditions.js:182
"Don't Send" => array( null, __("Don't Send", "forminator"), ), // src/quiz/global/components/notifications/conditions.js:183
"this email if" => array( null, __("this email if", "forminator"), ), // src/quiz/global/components/notifications/conditions.js:186
"Any" => array( null, __("Any", "forminator"), ), // src/quiz/global/components/notifications/conditions.js:199
"of the following rules match:" => array( null, __("of the following rules match:", "forminator"), ), // src/quiz/global/components/notifications/conditions.js:202
"Conditions" => array( null, __("Conditions", "forminator"), ), // src/quiz/global/components/notifications/conditions.js:215
"Add Conditions" => array( null, __("Add Conditions", "forminator"), ), // src/quiz/global/components/notifications/conditions.js:224
"By default, this email is always sent on form submission. You can add conditions to send this email conditionally based on user input." => array( null, __("By default, this email is always sent on form submission. You can add conditions to send this email conditionally based on user input.", "forminator"), ), // src/quiz/global/components/notifications/conditions.js:230
"Field" => array( null, __("Field", "forminator"), ), // src/quiz/global/components/notifications/conditions-rule.js:183
"Personality Result" => array( null, __("Personality Result", "forminator"), ), // src/quiz/global/components/notifications/conditions-rule.js:207
"Condition (required)" => array( null, __("Condition (required)", "forminator"), ), // src/quiz/global/components/notifications/conditions-rule.js:228
"Is final result" => array( null, __("Is final result", "forminator"), ), // src/quiz/global/components/notifications/conditions-rule.js:247
"Is not final result" => array( null, __("Is not final result", "forminator"), ), // src/quiz/global/components/notifications/conditions-rule.js:250
"No Result Found" => array( null, __("No Result Found", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:37
"Recipient(s)" => array( null, __("Recipient(s)", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:40
"Admin Email" => array( null, __("Admin Email", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:243
"Optionally, you can send a notification email to nominated email accounts when quiz submissions come in." => array( null, __("Optionally, you can send a notification email to nominated email accounts when quiz submissions come in.", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:247
"Send an email to admin users" => array( null, __("Send an email to admin users", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:256
"From Name" => array( null, __("From Name", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:266
"From Address" => array( null, __("From Address", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:282
"Add as many emails as you like" => array( null, __("Add as many emails as you like", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:299
"Reply To Address" => array( null, __("Reply To Address", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:305
"CC Addresses" => array( null, __("CC Addresses", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:319
"BCC Addresses" => array( null, __("BCC Addresses", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:334
"Enter subject" => array( null, __("Enter subject", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:349
"Subject" => array( null, __("Subject", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:350
"Quiz Answer" => array( null, __("Quiz Answer", "forminator"), ), // src/quiz/global/components/notifications/admin-email.js:362
"close this dialog window" => array( null, __("close this dialog window", "forminator"), ), // src/quiz/global/components/modals/submit.js:44
"Button Text" => array( null, __("Button Text", "forminator"), ), // src/quiz/global/components/modals/submit.js:57
"Enter text" => array( null, __("Enter text", "forminator"), ), // src/quiz/global/components/modals/submit.js:58
"Button Processing Text" => array( null, __("Button Processing Text", "forminator"), ), // src/quiz/global/components/modals/submit.js:67
"Sending…" => array( null, __("Sending…", "forminator"), ), // src/quiz/global/components/modals/submit.js:68
"This text will appear as button text while the quiz is being submitted." => array( null, __("This text will appear as button text while the quiz is being submitted.", "forminator"), ), // src/quiz/global/components/modals/submit.js:70
"Custom CSS Classes" => array( null, __("Custom CSS Classes", "forminator"), ), // src/quiz/global/components/modals/submit.js:80
"E.g. form-submit-btn" => array( null, __("E.g. form-submit-btn", "forminator"), ), // src/quiz/global/components/modals/submit.js:81
"These will be output as you see them here. To add multiple classes, separate them with a space. For example, \"form-submit-btn button\" will add two classes \"form-submit-btn\" and \"button\"." => array( null, __("These will be output as you see them here. To add multiple classes, separate them with a space. For example, \"form-submit-btn button\" will add two classes \"form-submit-btn\" and \"button\".", "forminator"), ), // src/quiz/global/components/modals/submit.js:83
"Apply" => array( null, __("Apply", "forminator"), ), // src/quiz/global/components/modals/submit.js:101
"Shortcode has been copied successfully." => array( null, __("Shortcode has been copied successfully.", "forminator"), ), // src/quiz/global/components/modals/shortcode.js:23
"Close this dialog window" => array( null, __("Close this dialog window", "forminator"), ), // src/quiz/global/components/modals/shortcode.js:36
"Ready to go!" => array( null, __("Ready to go!", "forminator"), ), // src/quiz/global/components/modals/shortcode.js:44
"Your quiz is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!" => array( null, __("Your quiz is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!", "forminator"), ), // src/quiz/global/components/modals/shortcode.js:49
"Shortcode" => array( null, __("Shortcode", "forminator"), ), // src/quiz/global/components/modals/shortcode.js:63
"Copy Shortcode" => array( null, __("Copy Shortcode", "forminator"), ), // src/quiz/global/components/modals/shortcode.js:78
"Options cannot be empty. You either need to enter answer text or upload an image for the empty options." => array( null, __("Options cannot be empty. You either need to enter answer text or upload an image for the empty options.", "forminator"), ), // src/quiz/global/components/modals/question.js:92
"You need to select at least one correct answer before you can add this question." => array( null, __("You need to select at least one correct answer before you can add this question.", "forminator"), ), // src/quiz/global/components/modals/question.js:108
"You need to select an associated personality for every option." => array( null, __("You need to select an associated personality for every option.", "forminator"), ), // src/quiz/global/components/modals/question.js:125
"Add Question" => array( null, __("Add Question", "forminator"), ), // src/quiz/global/components/modals/question.js:137
"Edit Question" => array( null, __("Edit Question", "forminator"), ), // src/quiz/global/components/modals/question.js:138
"E.g. Why did the chicken cross the road?" => array( null, __("E.g. Why did the chicken cross the road?", "forminator"), ), // src/quiz/global/components/modals/question.js:189
"Image" => array( null, __("Image", "forminator"), ), // src/quiz/global/components/modals/question.js:201
"Description (Optional)" => array( null, __("Description (Optional)", "forminator"), ), // src/quiz/global/components/modals/question.js:215
"Answers" => array( null, __("Answers", "forminator"), ), // src/quiz/global/components/modals/question.js:221
"Users can select one answer with the {{b}}Real Time{{/b}} display method. To allow multiple answers, you can switch to the {{b}}On Submission{{/b}} display method in {{a}}Behaviour → Display Method{{/a}}." => array( null, __("Users can select one answer with the {{b}}Real Time{{/b}} display method. To allow multiple answers, you can switch to the {{b}}On Submission{{/b}} display method in {{a}}Behaviour → Display Method{{/a}}.", "forminator"), ), // src/quiz/global/components/modals/question.js:228
"Note that user's selection will be considered as correct when any of the correct answers is selected." => array( null, __("Note that user's selection will be considered as correct when any of the correct answers is selected.", "forminator"), ), // src/quiz/global/components/modals/question.js:254
"Note: For questions with multiple correct answers, user's selection will be considered as correct only when all correct answers are selected." => array( null, __("Note: For questions with multiple correct answers, user's selection will be considered as correct only when all correct answers are selected.", "forminator"), ), // src/quiz/global/components/modals/question.js:270
"Add answers to your question and choose an associated personality. Multiple answers can be associated with a single personality as well." => array( null, __("Add answers to your question and choose an associated personality. Multiple answers can be associated with a single personality as well.", "forminator"), ), // src/quiz/global/components/modals/question.js:282
"Please, validate your fields!" => array( null, __("Please, validate your fields!", "forminator"), ), // src/quiz/global/components/modals/question.js:333
"Publishing quiz…" => array( null, __("Publishing quiz…", "forminator"), ), // src/quiz/global/components/modals/publish.js:30
"Great work! Please hold tight a few moments while we publish your quiz to the world." => array( null, __("Great work! Please hold tight a few moments while we publish your quiz to the world.", "forminator"), ), // src/quiz/global/components/modals/publish.js:35
"Preview" => array( null, __("Preview", "forminator"), ), // src/quiz/global/components/modals/preview.js:80
"Loading preview…" => array( null, __("Loading preview…", "forminator"), ), // src/quiz/global/components/modals/preview.js:96
"Edit Personality" => array( null, __("Edit Personality", "forminator"), ), // src/quiz/global/components/modals/personality.js:66
"E.g. Iron Man" => array( null, __("E.g. Iron Man", "forminator"), ), // src/quiz/global/components/modals/personality.js:96
"Please validate your fields!" => array( null, __("Please validate your fields!", "forminator"), ), // src/quiz/global/components/modals/personality.js:163
"Please enter recipients" => array( null, __("Please enter recipients", "forminator"), ), // src/quiz/global/components/modals/notification.js:250
"Please select rule" => array( null, __("Please select rule", "forminator"), ), // src/quiz/global/components/modals/notification.js:263
"Please add email routing" => array( null, __("Please add email routing", "forminator"), ), // src/quiz/global/components/modals/notification.js:268
"Please fix the error(s) in the EMAIL tab." => array( null, __("Please fix the error(s) in the EMAIL tab.", "forminator"), ), // src/quiz/global/components/modals/notification.js:278
"Email" => array( null, __("Email", "forminator"), ), // src/quiz/global/components/modals/notification.js:323
"Advanced" => array( null, __("Advanced", "forminator"), ), // src/quiz/global/components/modals/notification.js:343
"Label" => array( null, __("Label", "forminator"), ), // src/quiz/global/components/modals/notification.js:383
"The label is to help you identify this email and won't appear anywhere in the email." => array( null, __("The label is to help you identify this email and won't appear anywhere in the email.", "forminator"), ), // src/quiz/global/components/modals/notification.js:386
"E.g. Sales Team Notification" => array( null, __("E.g. Sales Team Notification", "forminator"), ), // src/quiz/global/components/modals/notification.js:391
"E.g. New Form Submission" => array( null, __("E.g. New Form Submission", "forminator"), ), // src/quiz/global/components/modals/notification.js:413
"Email subject can't be empty" => array( null, __("Email subject can't be empty", "forminator"), ), // src/quiz/global/components/modals/notification.js:421
"Quiz data" => array( null, __("Quiz data", "forminator"), ), // src/quiz/global/components/modals/notification.js:430
"Lead data" => array( null, __("Lead data", "forminator"), ), // src/quiz/global/components/modals/notification.js:454
"Misc data" => array( null, __("Misc data", "forminator"), ), // src/quiz/global/components/modals/notification.js:486
"Email body can't be empty" => array( null, __("Email body can't be empty", "forminator"), ), // src/quiz/global/components/modals/notification.js:563
"Attachments" => array( null, __("Attachments", "forminator"), ), // src/quiz/global/components/modals/notification.js:585
"Choose whether you want to attach the files uploaded via the File Upload fields to this email." => array( null, __("Choose whether you want to attach the files uploaded via the File Upload fields to this email.", "forminator"), ), // src/quiz/global/components/modals/notification.js:588
"Uploaded files" => array( null, __("Uploaded files", "forminator"), ), // src/quiz/global/components/modals/notification.js:604
"The default behavior is to send the email to the same recipients. If you want to send this email to different recipients conditionally, you can enable the email routing and change the recipients of this email based on the user input." => array( null, __("The default behavior is to send the email to the same recipients. If you want to send this email to different recipients conditionally, you can enable the email routing and change the recipients of this email based on the user input.", "forminator"), ), // src/quiz/global/components/modals/notification.js:627
"Email Routing" => array( null, __("Email Routing", "forminator"), ), // src/quiz/global/components/modals/notification.js:709
"Enter from name here" => array( null, __("Enter from name here", "forminator"), ), // src/quiz/global/components/modals/notification.js:743
"Enter from email here" => array( null, __("Enter from email here", "forminator"), ), // src/quiz/global/components/modals/notification.js:833
"From Email" => array( null, __("From Email", "forminator"), ), // src/quiz/global/components/modals/notification.js:836
"Enter reply-to email here" => array( null, __("Enter reply-to email here", "forminator"), ), // src/quiz/global/components/modals/notification.js:878
"Reply-to Email" => array( null, __("Reply-to Email", "forminator"), ), // src/quiz/global/components/modals/notification.js:881
"Enter CC email here" => array( null, __("Enter CC email here", "forminator"), ), // src/quiz/global/components/modals/notification.js:923
"CC Emails" => array( null, __("CC Emails", "forminator"), ), // src/quiz/global/components/modals/notification.js:926
"Enter BCC email here" => array( null, __("Enter BCC email here", "forminator"), ), // src/quiz/global/components/modals/notification.js:968
"BCC Emails" => array( null, __("BCC Emails", "forminator"), ), // src/quiz/global/components/modals/notification.js:971
"Add" => array( null, __("Add", "forminator"), ), // src/quiz/global/components/modals/notification.js:1037
"Delete Question" => array( null, __("Delete Question", "forminator"), ), // src/quiz/global/components/modals/delete.js:29
"Deleting this question will remove its value from the existing submissions as well." => array( null, __("Deleting this question will remove its value from the existing submissions as well.", "forminator"), ), // src/quiz/global/components/modals/delete.js:43
"Delete personality %s" => array( null, __("Delete personality %s", "forminator"), ), // src/quiz/global/components/modals/delete-personality.js:50
"Are you sure you wish to delete this personality?" => array( null, __("Are you sure you wish to delete this personality?", "forminator"), ), // src/quiz/global/components/modals/delete-personality.js:71
"%s can't be deleted" => array( null, __("%s can't be deleted", "forminator"), ), // src/quiz/global/components/modals/delete-personality.js:122
"Please remove the reference of this Personality from the questions in your quiz and then delete this." => array( null, __("Please remove the reference of this Personality from the questions in your quiz and then delete this.", "forminator"), ), // src/quiz/global/components/modals/delete-personality.js:144
"Got It" => array( null, __("Got It", "forminator"), ), // src/quiz/global/components/modals/delete-personality.js:158
"Delete Notification" => array( null, __("Delete Notification", "forminator"), ), // src/quiz/global/components/modals/delete-notification.js:39
"Are you sure you wish to delete this Notification?" => array( null, __("Are you sure you wish to delete this Notification?", "forminator"), ), // src/quiz/global/components/modals/delete-notification.js:44
"Name your form" => array( null, __("Name your form", "forminator"), ), // src/quiz/global/components/header/title.js:38
"Give your quiz a name" => array( null, __("Give your quiz a name", "forminator"), ), // src/quiz/global/components/header/title.js:43
"Please, enter a valid name." => array( null, __("Please, enter a valid name.", "forminator"), ), // src/quiz/global/components/header/title.js:65
"Submit" => array( null, __("Submit", "forminator"), ), // src/quiz/global/components/builder/submit.js:36
"A quiz without questions is not going to be very useful… Add your questions above!" => array( null, __("A quiz without questions is not going to be very useful… Add your questions above!", "forminator"), ), // src/quiz/global/components/builder/questions.js:109
"Add Answer" => array( null, __("Add Answer", "forminator"), ), // src/quiz/global/components/builder/answers.js:164
"Correct Answer" => array( null, __("Correct Answer", "forminator"), ), // src/quiz/global/components/builder/answer.js:106
"Select Personality" => array( null, __("Select Personality", "forminator"), ), // src/quiz/global/components/builder/answer.js:117
"Delete answer" => array( null, __("Delete answer", "forminator"), ), // src/quiz/global/components/builder/answer.js:139
"Social Sharing" => array( null, __("Social Sharing", "forminator"), ), // src/quiz/global/components/behaviour/share.js:16
"Choose whether you want to allow the quiz participants to share their results on social media." => array( null, __("Choose whether you want to allow the quiz participants to share their results on social media.", "forminator"), ), // src/quiz/global/components/behaviour/share.js:18
"Results" => array( null, __("Results", "forminator"), ), // src/quiz/global/components/behaviour/results.js:20
"Choose how do you want to show quiz results to the participants." => array( null, __("Choose how do you want to show quiz results to the participants.", "forminator"), ), // src/quiz/global/components/behaviour/results.js:23
"Display Method" => array( null, __("Display Method", "forminator"), ), // src/quiz/global/components/behaviour/results.js:34
"Choose whether to display the correct answer as the user answers each question or after the quiz is submitted." => array( null, __("Choose whether to display the correct answer as the user answers each question or after the quiz is submitted.", "forminator"), ), // src/quiz/global/components/behaviour/results.js:36
"Real Time" => array( null, __("Real Time", "forminator"), ), // src/quiz/global/components/behaviour/results.js:45
"On Submission" => array( null, __("On Submission", "forminator"), ), // src/quiz/global/components/behaviour/results.js:50
"Rendering" => array( null, __("Rendering", "forminator"), ), // src/quiz/global/components/behaviour/render.js:12
"Choose how you want your quiz to be rendered for users." => array( null, __("Choose how you want your quiz to be rendered for users.", "forminator"), ), // src/quiz/global/components/behaviour/render.js:15
"Load quiz using AJAX" => array( null, __("Load quiz using AJAX", "forminator"), ), // src/quiz/global/components/behaviour/render.js:23
"Enabling this feature will load the quiz via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your quiz." => array( null, __("Enabling this feature will load the quiz via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your quiz.", "forminator"), ), // src/quiz/global/components/behaviour/render.js:25
"Prevent page caching on quiz pages" => array( null, __("Prevent page caching on quiz pages", "forminator"), ), // src/quiz/global/components/behaviour/render.js:35
"Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic quizzes. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this quiz on it from being cached." => array( null, __("Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic quizzes. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this quiz on it from being cached.", "forminator"), ), // src/quiz/global/components/behaviour/render.js:37
"Choose how questions will be presented in the quiz." => array( null, __("Choose how questions will be presented in the quiz.", "forminator"), ), // src/quiz/global/components/behaviour/questions.js:19
"Question Presentation" => array( null, __("Question Presentation", "forminator"), ), // src/quiz/global/components/behaviour/questions.js:30
"Use this option to set how questions in this quiz will be presented. Paginated questions will display a number of questions to users at a time." => array( null, __("Use this option to set how questions in this quiz will be presented. Paginated questions will display a number of questions to users at a time.", "forminator"), ), // src/quiz/global/components/behaviour/questions.js:32
"No Pagination" => array( null, __("No Pagination", "forminator"), ), // src/quiz/global/components/behaviour/questions.js:40
"Paginated Quiz" => array( null, __("Paginated Quiz", "forminator"), ), // src/quiz/global/components/behaviour/questions.js:46
"Messages" => array( null, __("Messages", "forminator"), ), // src/quiz/global/components/behaviour/messages.js:13
"Choose the copy of the messages for the correct and wrong answers and also for the final score count." => array( null, __("Choose the copy of the messages for the correct and wrong answers and also for the final score count.", "forminator"), ), // src/quiz/global/components/behaviour/messages.js:16
"Correct Answer Message" => array( null, __("Correct Answer Message", "forminator"), ), // src/quiz/global/components/behaviour/messages.js:23
"Use {{strong}}%UserAnswer%{{/strong}} and {{strong}}%CorrectAnswer%{{/strong}} to display the answer chosen by the user and the correct answer for each question respectively." => array( null, __("Use {{strong}}%UserAnswer%{{/strong}} and {{strong}}%CorrectAnswer%{{/strong}} to display the answer chosen by the user and the correct answer for each question respectively.", "forminator"), ), // src/quiz/global/components/behaviour/messages.js:26
"Incorrect Answer Message" => array( null, __("Incorrect Answer Message", "forminator"), ), // src/quiz/global/components/behaviour/messages.js:41
"Final Count Message" => array( null, __("Final Count Message", "forminator"), ), // src/quiz/global/components/behaviour/messages.js:58
"Final count message will appear after the quiz is complete. Use {{strong}}%YourNum%{{/strong}} to display number of correct answers and {{strong}}%Total%{{/strong}} for total number of questions." => array( null, __("Final count message will appear after the quiz is complete. Use {{strong}}%YourNum%{{/strong}} to display number of correct answers and {{strong}}%Total%{{/strong}} for total number of questions.", "forminator"), ), // src/quiz/global/components/behaviour/messages.js:61
"Lifespan" => array( null, __("Lifespan", "forminator"), ), // src/quiz/global/components/behaviour/lifespan.js:18
"By default this quiz will always be available for submissions. However you can lock down if need be." => array( null, __("By default this quiz will always be available for submissions. However you can lock down if need be.", "forminator"), ), // src/quiz/global/components/behaviour/lifespan.js:22
"Expiry" => array( null, __("Expiry", "forminator"), ), // src/quiz/global/components/behaviour/lifespan.js:32
"20 April 2018" => array( null, __("20 April 2018", "forminator"), ), // src/quiz/global/components/behaviour/lifespan.js:50
"Expiration Message" => array( null, __("Expiration Message", "forminator"), ), // src/quiz/global/components/behaviour/lifespan.js:54
"Whoops! This quiz has expired." => array( null, __("Whoops! This quiz has expired.", "forminator"), ), // src/quiz/global/components/behaviour/lifespan.js:55
"Add some custom message for users to see when your quiz stops appearing or leave empty to show nothing (just an empty space)." => array( null, __("Add some custom message for users to see when your quiz stops appearing or leave empty to show nothing (just an empty space).", "forminator"), ), // src/quiz/global/components/behaviour/lifespan.js:58
"Social Sharing Platforms" => array( null, __("Social Sharing Platforms", "forminator"), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:23
"Facebook no longer supports passing the Social Share Message that you enter below. Your users will need to enter their own messages in the share box." => array( null, __("Facebook no longer supports passing the Social Share Message that you enter below. Your users will need to enter their own messages in the share box.", "forminator"), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:31
"I got {quiz_result} on {quiz_name} quiz!" => array( null, __("I got {quiz_result} on {quiz_name} quiz!", "forminator"), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:56
"Social Share Message" => array( null, __("Social Share Message", "forminator"), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:57
"Page/Post Title" => array( null, __("Page/Post Title", "forminator"), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:69
"Page/Post URL" => array( null, __("Page/Post URL", "forminator"), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:72
"Site URL" => array( null, __("Site URL", "forminator"), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:75
"Want to enhance how the result will look when shared on Social Media? {{link}}SmartCrawl{{/link}} OpenGraph and X Card support lets you choose how your content looks when it's shared on social media." => array( null, __("Want to enhance how the result will look when shared on Social Media? {{link}}SmartCrawl{{/link}} OpenGraph and X Card support lets you choose how your content looks when it's shared on social media.", "forminator"), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:89
"Note: You can change the color of the loader in the Appearance tab." => array( null, __("Note: You can change the color of the loader in the Appearance tab.", "forminator"), ), // src/quiz/global/components/behaviour/results/show-loader.js:16
"Option Selected" => array( null, __("Option Selected", "forminator"), ), // src/quiz/global/components/behaviour/results/show-loader.js:24
"Note: Participants can only choose one answer with \"Real Time\" method." => array( null, __("Note: Participants can only choose one answer with \"Real Time\" method.", "forminator"), ), // src/quiz/global/components/behaviour/results/evaluation-loader.js:26
"Evaluation Loader" => array( null, __("Evaluation Loader", "forminator"), ), // src/quiz/global/components/behaviour/results/evaluation-loader.js:37
"Choose whether you want to show a loader while evaluating the selected answer in real-time. We recommend using this on long quizzes since evaluating an answer might take a bit longer." => array( null, __("Choose whether you want to show a loader while evaluating the selected answer in real-time. We recommend using this on long quizzes since evaluating an answer might take a bit longer.", "forminator"), ), // src/quiz/global/components/behaviour/results/evaluation-loader.js:40
"Show Loader" => array( null, __("Show Loader", "forminator"), ), // src/quiz/global/components/behaviour/results/evaluation-loader.js:48
"Number of questions per page" => array( null, __("Number of questions per page", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:23
"Enter the number of questions to be displayed per page." => array( null, __("Enter the number of questions to be displayed per page.", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:27
"Start quiz button text" => array( null, __("Start quiz button text", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:38
"Enter your start quiz button text. This button will not be shown If the lead generation is enabled and set to show before the quiz." => array( null, __("Enter your start quiz button text. This button will not be shown If the lead generation is enabled and set to show before the quiz.", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:41
"Start Quiz" => array( null, __("Start Quiz", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:46
"Previous button text" => array( null, __("Previous button text", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:58
"Previous" => array( null, __("Previous", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:59
"Next button text" => array( null, __("Next button text", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:67
"Next" => array( null, __("Next", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:68
"By default, quiz navigation button texts are set to “Next”, and “Previous”, you can use the fields above to set a custom texts for these buttons." => array( null, __("By default, quiz navigation button texts are set to “Next”, and “Previous”, you can use the fields above to set a custom texts for these buttons.", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:74
"Show page indicator" => array( null, __("Show page indicator", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:85
"Display current, and total page indicator" => array( null, __("Display current, and total page indicator", "forminator"), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:95
"Quiz Container" => array( null, __("Quiz Container", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:22
"Customize the quiz container as per your liking." => array( null, __("Customize the quiz container as per your liking.", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:24
"Padding" => array( null, __("Padding", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:32
"By default the quiz will fill the available space where you insert it. You can add some padding here to better suit your theme." => array( null, __("By default the quiz will fill the available space where you insert it. You can add some padding here to better suit your theme.", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:34
"Border" => array( null, __("Border", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:57
"Add an optional border around the quiz." => array( null, __("Add an optional border around the quiz.", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:59
"Spacing" => array( null, __("Spacing", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:80
"Choose how much spacing you want between each quiz question." => array( null, __("Choose how much spacing you want between each quiz question.", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:82
"Comfortable" => array( null, __("Comfortable", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:87
"Compact" => array( null, __("Compact", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:91
"Maximum Width" => array( null, __("Maximum Width", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:107
"Choose the maximum container width for your quiz. Full Width means quiz container will fill the 100% available space where you insert it, and the Custom option lets you define a maximum container width." => array( null, __("Choose the maximum container width for your quiz. Full Width means quiz container will fill the 100% available space where you insert it, and the Custom option lets you define a maximum container width.", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:109
"Full Width" => array( null, __("Full Width", "forminator"), ), // src/quiz/global/components/appearance/quiz-container.js:117
"Layout" => array( null, __("Layout", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:20
"Customize your quiz layout by adjusting the answers layout and overall quiz alignment." => array( null, __("Customize your quiz layout by adjusting the answers layout and overall quiz alignment.", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:22
"Radio/Checkbox Image Size" => array( null, __("Radio/Checkbox Image Size", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:31
"Set radio/checkbox image size." => array( null, __("Set radio/checkbox image size.", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:33
"Automatic" => array( null, __("Automatic", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:38
"Choose whether the quiz answers should appear in a list or a grid." => array( null, __("Choose whether the quiz answers should appear in a list or a grid.", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:54
"List" => array( null, __("List", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:65
"Grid" => array( null, __("Grid", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:73
"Choose the number of columns to fit in one row. Note that grid layout changes to list on smaller screens so this won't affect the smaller screens." => array( null, __("Choose the number of columns to fit in one row. Note that grid layout changes to list on smaller screens so this won't affect the smaller screens.", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:81
"Columns per row" => array( null, __("Columns per row", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:91
"Quiz Alignment" => array( null, __("Quiz Alignment", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:110
"Choose the overall alignment of your quiz. This setting affects everything, including title, description, questions and answers, buttons, and social share message." => array( null, __("Choose the overall alignment of your quiz. This setting affects everything, including title, description, questions and answers, buttons, and social share message.", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:112
"Left" => array( null, __("Left", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:119
"Center" => array( null, __("Center", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:123
"Question Item Ordering" => array( null, __("Question Item Ordering", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:134
"Choose the order of items (Questions, Images, and Descriptions) from {{strong}}Top{{/strong}} to {{strong}}Bottom{{/strong}} in this quiz." => array( null, __("Choose the order of items (Questions, Images, and Descriptions) from {{strong}}Top{{/strong}} to {{strong}}Bottom{{/strong}} in this quiz.", "forminator"), ), // src/quiz/global/components/appearance/options-layout.js:141
"Design Style" => array( null, __("Design Style", "forminator"), ), // src/quiz/global/components/appearance/design-style.js:19
"Choose a pre-made style for your quiz and further customize it's appearance below." => array( null, __("Choose a pre-made style for your quiz and further customize it's appearance below.", "forminator"), ), // src/quiz/global/components/appearance/design-style.js:21
"Flat" => array( null, __("Flat", "forminator"), ), // src/quiz/global/components/appearance/design-style.js:44
"Bold" => array( null, __("Bold", "forminator"), ), // src/quiz/global/components/appearance/design-style.js:51
"Material" => array( null, __("Material", "forminator"), ), // src/quiz/global/components/appearance/design-style.js:58
"Custom CSS" => array( null, __("Custom CSS", "forminator"), ), // src/quiz/global/components/appearance/custom-css.js:28
"For more advanced customization options use custom CSS." => array( null, __("For more advanced customization options use custom CSS.", "forminator"), ), // src/quiz/global/components/appearance/custom-css.js:40
"Enable custom CSS" => array( null, __("Enable custom CSS", "forminator"), ), // src/quiz/global/components/appearance/custom-css.js:45
"in pixels" => array( null, __("in pixels", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/spacing.js:21
"Maximum width" => array( null, __("Maximum width", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/size.js:20
"Top" => array( null, __("Top", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/padding.js:27
"Bottom" => array( null, __("Bottom", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/padding.js:40
"Set your custom padding in pixels." => array( null, __("Set your custom padding in pixels.", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/padding.js:74
"Radius" => array( null, __("Radius", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/border.js:28
"in px" => array( null, __("in px", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/border.js:29
"Thickness" => array( null, __("Thickness", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/border.js:42
"Style" => array( null, __("Style", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/border.js:54
"Solid" => array( null, __("Solid", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/border.js:56
"Dashed" => array( null, __("Dashed", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/border.js:57
"Dotted" => array( null, __("Dotted", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/border.js:58
"Note: Set the color of the border in the Colors settings area above." => array( null, __("Note: Set the color of the border in the Colors settings area above.", "forminator"), ), // src/quiz/global/components/appearance/quiz-container/border.js:67
"Note: If value is empty or zero, image will fallback to default size." => array( null, __("Note: If value is empty or zero, image will fallback to default size.", "forminator"), ), // src/quiz/global/components/appearance/layout/field-image-size.js:34
"Width" => array( null, __("Width", "forminator"), ), // src/quiz/global/components/appearance/layout/field-image-size.js:47
"Height" => array( null, __("Height", "forminator"), ), // src/quiz/global/components/appearance/layout/field-image-size.js:57
"Set your custom dimensions in pixels." => array( null, __("Set your custom dimensions in pixels.", "forminator"), ), // src/quiz/global/components/appearance/layout/field-image-size.js:67
"You have opted for no stylesheet to be enqueued. The quiz will inherit styles from your theme's CSS." => array( null, __("You have opted for no stylesheet to be enqueued. The quiz will inherit styles from your theme's CSS.", "forminator"), ), // src/quiz/global/components/appearance/design-style/none.js:18
"Question text?" => array( null, __("Question text?", "forminator"), ), // src/quiz/global/components/appearance/design-style/material.js:15
"Option Unselected" => array( null, __("Option Unselected", "forminator"), ), // src/quiz/global/components/appearance/design-style/material.js:21
"Disabled" => array( null, __("Disabled", "forminator"), ), // src/quiz/global/components/appearance/colors/navigation-button.js:85
"Customize Poll" => array( null, __("Customize Poll", "forminator"), ), // src/poll/components/navigation.js:11
"Something went wrong while reverting your poll. Please try again." => array( null, __("Something went wrong while reverting your poll. Please try again.", "forminator"), ), // src/poll/components/meta.js:153
"Poll answers can not be empty." => array( null, __("Poll answers can not be empty.", "forminator"), ), // src/poll/components/meta.js:190
"Please enter valid voting limit." => array( null, __("Please enter valid voting limit.", "forminator"), ), // src/poll/components/meta.js:203
"Something went wrong while saving your form. Please try again." => array( null, __("Something went wrong while saving your form. Please try again.", "forminator"), ), // src/poll/components/meta.js:266
"You need to save this poll before using integrations." => array( null, __("You need to save this poll before using integrations.", "forminator"), ), // src/poll/components/integrations.js:121
"Try Again" => array( null, __("Try Again", "forminator"), ), // src/poll/components/integrations.js:123
"Poll created successfully." => array( null, __("Poll created successfully.", "forminator"), ), // src/poll/components/builder.js:23
"Details" => array( null, __("Details", "forminator"), ), // src/poll/components/builder.js:28
"Choose how you want to handle this poll's data storage. By default we'll use the configuration you've set in your " => array( null, __("Choose how you want to handle this poll's data storage. By default we'll use the configuration you've set in your ", "forminator"), ), // src/poll/components/settings/privacy.js:50
"How long do you want to retain this poll's submissions for?" => array( null, __("How long do you want to retain this poll's submissions for?", "forminator"), ), // src/poll/components/settings/privacy.js:75
"IP Retention" => array( null, __("IP Retention", "forminator"), ), // src/poll/components/settings/privacy.js:163
"Choose how long to retain IP address before a submission is anonymized. Keep in mind that the IP address is being used in checking multiple votes from same user." => array( null, __("Choose how long to retain IP address before a submission is anonymized. Keep in mind that the IP address is being used in checking multiple votes from same user.", "forminator"), ), // src/poll/components/settings/privacy.js:167
"Your default setting keep the IPs %s." => array( null, __("Your default setting keep the IPs %s.", "forminator"), ), // src/poll/components/settings/privacy.js:188
"Set the value to \"0\" or leave it blank to store IPs forever." => array( null, __("Set the value to \"0\" or leave it blank to store IPs forever.", "forminator"), ), // src/poll/components/settings/privacy.js:237
"Optionally, you can send a notification email to nominated email accounts when poll submissions come in." => array( null, __("Optionally, you can send a notification email to nominated email accounts when poll submissions come in.", "forminator"), ), // src/poll/components/notifications/admin-email.js:295
"Poll Name" => array( null, __("Poll Name", "forminator"), ), // src/poll/components/notifications/admin-email.js:404
"Poll Answer" => array( null, __("Poll Answer", "forminator"), ), // src/poll/components/notifications/admin-email.js:405
"Poll Result" => array( null, __("Poll Result", "forminator"), ), // src/poll/components/notifications/admin-email.js:406
"Notifications" => array( null, __("Notifications", "forminator"), ), // src/poll/components/navigation/menu.js:76
"Your poll is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!" => array( null, __("Your poll is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!", "forminator"), ), // src/poll/components/modals/shortcode.js:51
"Publishing poll…" => array( null, __("Publishing poll…", "forminator"), ), // src/poll/components/modals/publish.js:30
"Great work! Please hold tight a few moments while we publish your form to the world." => array( null, __("Great work! Please hold tight a few moments while we publish your form to the world.", "forminator"), ), // src/poll/components/modals/publish.js:35
"Delete Answer" => array( null, __("Delete Answer", "forminator"), ), // src/poll/components/modals/delete.js:45
"Deleting this answer will remove its value from the existing submissions as well." => array( null, __("Deleting this answer will remove its value from the existing submissions as well.", "forminator"), ), // src/poll/components/modals/delete.js:50
"Name your poll" => array( null, __("Name your poll", "forminator"), ), // src/poll/components/header/title.js:38
"Give your poll a name" => array( null, __("Give your poll a name", "forminator"), ), // src/poll/components/header/title.js:43
"Start by adding the question you will be asking poll visitors to vote on." => array( null, __("Start by adding the question you will be asking poll visitors to vote on.", "forminator"), ), // src/poll/components/builder/details.js:28
"What is your main question?" => array( null, __("What is your main question?", "forminator"), ), // src/poll/components/builder/details.js:39
"Feature Image (optional)" => array( null, __("Feature Image (optional)", "forminator"), ), // src/poll/components/builder/details.js:48
"This image will appear under your main question and can be used to create polls based on an image." => array( null, __("This image will appear under your main question and can be used to create polls based on an image.", "forminator"), ), // src/poll/components/builder/details.js:52
"Description (optional)" => array( null, __("Description (optional)", "forminator"), ), // src/poll/components/builder/details.js:59
"Enter an optional description" => array( null, __("Enter an optional description", "forminator"), ), // src/poll/components/builder/details.js:61
"This will appear below the main question and can be used to further explain the main question." => array( null, __("This will appear below the main question and can be used to further explain the main question.", "forminator"), ), // src/poll/components/builder/details.js:64
"Now add answers to your question that your users will use to vote with. Add as many as you like, just be careful to make sure each one is unique!" => array( null, __("Now add answers to your question that your users will use to vote with. Add as many as you like, just be careful to make sure each one is unique!", "forminator"), ), // src/poll/components/builder/details.js:84
"Enable Images" => array( null, __("Enable Images", "forminator"), ), // src/poll/components/builder/details.js:94
"Button" => array( null, __("Button", "forminator"), ), // src/poll/components/builder/details.js:111
"Customize the button label used to submit the user's answer." => array( null, __("Customize the button label used to submit the user's answer.", "forminator"), ), // src/poll/components/builder/details.js:115
"E.g. Vote" => array( null, __("E.g. Vote", "forminator"), ), // src/poll/components/builder/details.js:127
"A poll without answers isn’t going to be very useful… Add your answers above!" => array( null, __("A poll without answers isn’t going to be very useful… Add your answers above!", "forminator"), ), // src/poll/components/builder/answers.js:82
"Enter Answer" => array( null, __("Enter Answer", "forminator"), ), // src/poll/components/builder/answer-row.js:121
"Enter placeholder" => array( null, __("Enter placeholder", "forminator"), ), // src/poll/components/builder/answer-row.js:148
"Answer options" => array( null, __("Answer options", "forminator"), ), // src/poll/components/builder/answer-row.js:173
"Enable custom input" => array( null, __("Enable custom input", "forminator"), ), // src/poll/components/builder/answer-row.js:180
"Remove custom input" => array( null, __("Remove custom input", "forminator"), ), // src/poll/components/builder/answer-row.js:187
"Vote Count" => array( null, __("Vote Count", "forminator"), ), // src/poll/components/behaviour/vote-count.js:16
"Display the number of votes on results" => array( null, __("Display the number of votes on results", "forminator"), ), // src/poll/components/behaviour/vote-count.js:18
"Hide" => array( null, __("Hide", "forminator"), ), // src/poll/components/behaviour/vote-count.js:29
"Show" => array( null, __("Show", "forminator"), ), // src/poll/components/behaviour/vote-count.js:30
"Submission Method" => array( null, __("Submission Method", "forminator"), ), // src/poll/components/behaviour/submission-method.js:17
"By default, submissions don't require the page to reload. If you are having issues you might want use the traditional method of reloading the page." => array( null, __("By default, submissions don't require the page to reload. If you are having issues you might want use the traditional method of reloading the page.", "forminator"), ), // src/poll/components/behaviour/submission-method.js:20
"Reload Page" => array( null, __("Reload Page", "forminator"), ), // src/poll/components/behaviour/submission-method.js:33
"Ajax" => array( null, __("Ajax", "forminator"), ), // src/poll/components/behaviour/submission-method.js:34
"Pie Chart" => array( null, __("Pie Chart", "forminator"), ), // src/poll/components/behaviour/results-display.js:36
"Bar Graph" => array( null, __("Bar Graph", "forminator"), ), // src/poll/components/behaviour/results-display.js:42
"Results Display" => array( null, __("Results Display", "forminator"), ), // src/poll/components/behaviour/results-display.js:50
"Choose how you want to display poll results to new submissions. You can customize colors in the {{link}}Appearance{{/link}} tab." => array( null, __("Choose how you want to display poll results to new submissions. You can customize colors in the {{link}}Appearance{{/link}} tab.", "forminator"), ), // src/poll/components/behaviour/results-display.js:52
"Link on poll" => array( null, __("Link on poll", "forminator"), ), // src/poll/components/behaviour/results-display.js:72
"Show after voted" => array( null, __("Show after voted", "forminator"), ), // src/poll/components/behaviour/results-display.js:81
"Do not show" => array( null, __("Do not show", "forminator"), ), // src/poll/components/behaviour/results-display.js:89
"Choose how you want your poll to be rendered for users." => array( null, __("Choose how you want your poll to be rendered for users.", "forminator"), ), // src/poll/components/behaviour/render.js:15
"Load poll using AJAX" => array( null, __("Load poll using AJAX", "forminator"), ), // src/poll/components/behaviour/render.js:23
"Enabling this feature will load the poll via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your poll." => array( null, __("Enabling this feature will load the poll via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your poll.", "forminator"), ), // src/poll/components/behaviour/render.js:25
"Prevent page caching on poll pages" => array( null, __("Prevent page caching on poll pages", "forminator"), ), // src/poll/components/behaviour/render.js:35
"Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic polls. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this poll on it from being cached." => array( null, __("Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic polls. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this poll on it from being cached.", "forminator"), ), // src/poll/components/behaviour/render.js:37
"Vote Opening" => array( null, __("Vote Opening", "forminator"), ), // src/poll/components/behaviour/opening.js:25
"Choose when you want to open and close voting" => array( null, __("Choose when you want to open and close voting", "forminator"), ), // src/poll/components/behaviour/opening.js:29
"Status" => array( null, __("Status", "forminator"), ), // src/poll/components/behaviour/opening.js:38
"Choose the status of voting" => array( null, __("Choose the status of voting", "forminator"), ), // src/poll/components/behaviour/opening.js:41
"Open" => array( null, __("Open", "forminator"), ), // src/poll/components/behaviour/opening.js:53
"Pause" => array( null, __("Pause", "forminator"), ), // src/poll/components/behaviour/opening.js:57
"Close" => array( null, __("Close", "forminator"), ), // src/poll/components/behaviour/opening.js:61
"Open from" => array( null, __("Open from", "forminator"), ), // src/poll/components/behaviour/opening.js:69
"Choose when voting will be opened" => array( null, __("Choose when voting will be opened", "forminator"), ), // src/poll/components/behaviour/opening.js:72
"Now" => array( null, __("Now", "forminator"), ), // src/poll/components/behaviour/opening.js:84
"Specific Date Time" => array( null, __("Specific Date Time", "forminator"), ), // src/poll/components/behaviour/opening.js:89
"Open until" => array( null, __("Open until", "forminator"), ), // src/poll/components/behaviour/opening.js:106
"Choose how long voting will remain open" => array( null, __("Choose how long voting will remain open", "forminator"), ), // src/poll/components/behaviour/opening.js:109
"Forever" => array( null, __("Forever", "forminator"), ), // src/poll/components/behaviour/opening.js:121
"Custom messages" => array( null, __("Custom messages", "forminator"), ), // src/poll/components/behaviour/opening.js:143
"Message when voting is closed" => array( null, __("Message when voting is closed", "forminator"), ), // src/poll/components/behaviour/opening.js:148
"E.g. Voting is closed" => array( null, __("E.g. Voting is closed", "forminator"), ), // src/poll/components/behaviour/opening.js:151
"Message when voting is paused" => array( null, __("Message when voting is paused", "forminator"), ), // src/poll/components/behaviour/opening.js:156
"E.g. Voting is paused, check again later" => array( null, __("E.g. Voting is paused, check again later", "forminator"), ), // src/poll/components/behaviour/opening.js:159
"Message before voting open from time" => array( null, __("Message before voting open from time", "forminator"), ), // src/poll/components/behaviour/opening.js:164
"E.g. Voting has not been started yet" => array( null, __("E.g. Voting has not been started yet", "forminator"), ), // src/poll/components/behaviour/opening.js:167
"Voting Limit" => array( null, __("Voting Limit", "forminator"), ), // src/poll/components/behaviour/limits.js:26
"Choose whether you want to limit the number of votes per users and how do you want to impose that limit. " => array( null, __("Choose whether you want to limit the number of votes per users and how do you want to impose that limit. ", "forminator"), ), // src/poll/components/behaviour/limits.js:30
"Votes per user" => array( null, __("Votes per user", "forminator"), ), // src/poll/components/behaviour/limits.js:41
"By default, a user can only vote once on a poll. However, you can allow the users to vote multiple times and also specify the time after which a user can vote again." => array( null, __("By default, a user can only vote once on a poll. However, you can allow the users to vote multiple times and also specify the time after which a user can vote again.", "forminator"), ), // src/poll/components/behaviour/limits.js:49
"Once" => array( null, __("Once", "forminator"), ), // src/poll/components/behaviour/limits.js:64
"Allow Multiple" => array( null, __("Allow Multiple", "forminator"), ), // src/poll/components/behaviour/limits.js:70
"minute(s)" => array( null, __("minute(s)", "forminator"), ), // src/poll/components/behaviour/limits.js:92
"hour(s)" => array( null, __("hour(s)", "forminator"), ), // src/poll/components/behaviour/limits.js:93
"Method" => array( null, __("Method", "forminator"), ), // src/poll/components/behaviour/limits.js:109
"Choose the method you want to use to limit the number of votes." => array( null, __("Choose the method you want to use to limit the number of votes.", "forminator"), ), // src/poll/components/behaviour/limits.js:112
"User IP" => array( null, __("User IP", "forminator"), ), // src/poll/components/behaviour/limits.js:119
"Browser Cookie" => array( null, __("Browser Cookie", "forminator"), ), // src/poll/components/behaviour/limits.js:120
"Adjust the answers layout and overall poll alignment." => array( null, __("Adjust the answers layout and overall poll alignment.", "forminator"), ), // src/poll/components/appearance/options-layout.js:20
"Choose whether the poll answers should appear in a list or a grid." => array( null, __("Choose whether the poll answers should appear in a list or a grid.", "forminator"), ), // src/poll/components/appearance/options-layout.js:51
"Choose the number of columns to fit in one row. Note that grid layout changes to two columns on smaller screens so this won't affect the smaller screens." => array( null, __("Choose the number of columns to fit in one row. Note that grid layout changes to two columns on smaller screens so this won't affect the smaller screens.", "forminator"), ), // src/poll/components/appearance/options-layout.js:78
"Answer Type" => array( null, __("Answer Type", "forminator"), ), // src/poll/components/appearance/options-layout.js:133
"Choose how your poll answers should be displayed on the frontend." => array( null, __("Choose how your poll answers should be displayed on the frontend.", "forminator"), ), // src/poll/components/appearance/options-layout.js:135
"Image and Radio Button" => array( null, __("Image and Radio Button", "forminator"), ), // src/poll/components/appearance/options-layout.js:140
"Image only" => array( null, __("Image only", "forminator"), ), // src/poll/components/appearance/options-layout.js:144
"Choose a pre-made style for your poll and further customize it's appearance below." => array( null, __("Choose a pre-made style for your poll and further customize it's appearance below.", "forminator"), ), // src/poll/components/appearance/design-style.js:29
"Form Container" => array( null, __("Form Container", "forminator"), ), // src/poll/components/appearance/container.js:17
"Customize the form container's padding and border." => array( null, __("Customize the form container's padding and border.", "forminator"), ), // src/poll/components/appearance/container.js:19
"By default the form will fill the available space where you insert it. You can add some padding here to better suit your theme." => array( null, __("By default the form will fill the available space where you insert it. You can add some padding here to better suit your theme.", "forminator"), ), // src/poll/components/appearance/container.js:30
"Add an optional border around the form." => array( null, __("Add an optional border around the form.", "forminator"), ), // src/poll/components/appearance/container.js:49
"Choose how much spacing you want between each poll option." => array( null, __("Choose how much spacing you want between each poll option.", "forminator"), ), // src/poll/components/appearance/container.js:67
"Enclosed" => array( null, __("Enclosed", "forminator"), ), // src/poll/components/appearance/container.js:73
"Use default colors" => array( null, __("Use default colors", "forminator"), ), // src/poll/components/appearance/colors.js:51
"Poll Container" => array( null, __("Poll Container", "forminator"), ), // src/poll/components/appearance/colors.js:67
"Poll Basics" => array( null, __("Poll Basics", "forminator"), ), // src/poll/components/appearance/colors.js:74
"Answers - Radio Option" => array( null, __("Answers - Radio Option", "forminator"), ), // src/poll/components/appearance/colors.js:82
"Radio Options" => array( null, __("Radio Options", "forminator"), ), // src/poll/components/appearance/colors.js:83
"Answers - Radio Image" => array( null, __("Answers - Radio Image", "forminator"), ), // src/poll/components/appearance/colors.js:92
"Custom Answer Input" => array( null, __("Custom Answer Input", "forminator"), ), // src/poll/components/appearance/colors.js:100
"Response Success" => array( null, __("Response Success", "forminator"), ), // src/poll/components/appearance/colors.js:121
"Response Error" => array( null, __("Response Error", "forminator"), ), // src/poll/components/appearance/colors.js:128
"Results Chart" => array( null, __("Results Chart", "forminator"), ), // src/poll/components/appearance/colors.js:136
"You have opted for no stylesheet to be enqueued. The form will inherit styles from your theme's CSS." => array( null, __("You have opted for no stylesheet to be enqueued. The form will inherit styles from your theme's CSS.", "forminator"), ), // src/poll/components/appearance/design-style/none.js:12
"0" => array( null, __("0", "forminator"), ), // src/poll/components/appearance/container/spacing-custom.js:20
"Text color" => array( null, __("Text color", "forminator"), ), // src/poll/components/appearance/colors/submit.js:36
"Successful response message will be displayed after poll submission succeeds." => array( null, __("Successful response message will be displayed after poll submission succeeds.", "forminator"), ), // src/poll/components/appearance/colors/response-success.js:18
"Error response message will be displayed after poll vote submission fails." => array( null, __("Error response message will be displayed after poll vote submission fails.", "forminator"), ), // src/poll/components/appearance/colors/response-error.js:18
"Background" => array( null, __("Background", "forminator"), ), // src/poll/components/appearance/colors/options.js:36
"Link color" => array( null, __("Link color", "forminator"), ), // src/poll/components/appearance/colors/links.js:29
"Placeholder" => array( null, __("Placeholder", "forminator"), ), // src/poll/components/appearance/colors/input.js:43
"\"No votes yet\" text color" => array( null, __("\"No votes yet\" text color", "forminator"), ), // src/poll/components/appearance/colors/content.js:30
"Users see this text next to submit button when \"link on poll\" submission is enabled." => array( null, __("Users see this text next to submit button when \"link on poll\" submission is enabled.", "forminator"), ), // src/poll/components/appearance/colors/content.js:34
"Box shadow" => array( null, __("Box shadow", "forminator"), ), // src/poll/components/appearance/colors/container.js:32
"Basics" => array( null, __("Basics", "forminator"), ), // src/poll/components/appearance/colors/chart.js:26
"Chart grid lines" => array( null, __("Chart grid lines", "forminator"), ), // src/poll/components/appearance/colors/chart.js:31
"Legend text color" => array( null, __("Legend text color", "forminator"), ), // src/poll/components/appearance/colors/chart.js:39
"Chart labels color" => array( null, __("Chart labels color", "forminator"), ), // src/poll/components/appearance/colors/chart.js:40
"Legends are always displayed on top of the chart." => array( null, __("Legends are always displayed on top of the chart.", "forminator"), ), // src/poll/components/appearance/colors/chart.js:43
"Votes count" => array( null, __("Votes count", "forminator"), ), // src/poll/components/appearance/colors/chart.js:52
"Text displayed inside bars." => array( null, __("Text displayed inside bars.", "forminator"), ), // src/poll/components/appearance/colors/chart.js:54
"Tooltips" => array( null, __("Tooltips", "forminator"), ), // src/poll/components/appearance/colors/chart.js:63
"Choose the graph colors for each poll answers below." => array( null, __("Choose the graph colors for each poll answers below.", "forminator"), ), // src/poll/components/appearance/colors/chart.js:86
"{{b}}Notice!{{/b}} User/Site registration is disabled in your WordPress network settings. Visitors can still submit this form, but no new sites or user accounts will be created. To enable registration, go to {{link}}Network Admin → Settings → Allow new registrations{{/link}} or use the manual activation method in the {{settings}}User Registration tab{{/settings}}." => array( null, __("{{b}}Notice!{{/b}} User/Site registration is disabled in your WordPress network settings. Visitors can still submit this form, but no new sites or user accounts will be created. To enable registration, go to {{link}}Network Admin → Settings → Allow new registrations{{/link}} or use the manual activation method in the {{settings}}User Registration tab{{/settings}}.", "forminator"), ), // src/global/components/notice.js:41
"{{b}}Notice!{{/b}} User registration is disabled in your WordPress settings. Visitors can still submit this form, but no new user accounts will be created. To enable registration, go to {{link}}Settings → General → Membership{{/link}} or use the manual activation method in the {{settings}}User Registration tab{{/settings}}." => array( null, __("{{b}}Notice!{{/b}} User registration is disabled in your WordPress settings. Visitors can still submit this form, but no new user accounts will be created. To enable registration, go to {{link}}Settings → General → Membership{{/link}} or use the manual activation method in the {{settings}}User Registration tab{{/settings}}.", "forminator"), ), // src/global/components/notice.js:62
"Shape the new Form Editor" => array( null, __("Shape the new Form Editor", "forminator"), ), // src/global/components/sidebar/feedback.js:17
"Share your feedback and help us make it even better!" => array( null, __("Share your feedback and help us make it even better!", "forminator"), ), // src/global/components/sidebar/feedback.js:57
"Discard Changes?" => array( null, __("Discard Changes?", "forminator"), ), // src/global/components/modals/revert.js:34
"Are you sure you want to discard your saved changes and revert to the last published version? This action cannot be undone." => array( null, __("Are you sure you want to discard your saved changes and revert to the last published version? This action cannot be undone.", "forminator"), ), // src/global/components/modals/revert.js:38
"Discard" => array( null, __("Discard", "forminator"), ), // src/global/components/modals/revert.js:54
"Thanks for your feedback!" => array( null, __("Thanks for your feedback!", "forminator"), ), // src/global/components/modals/feedback.js:48
"It helps us make Forminator even better." => array( null, __("It helps us make Forminator even better.", "forminator"), ), // src/global/components/modals/feedback.js:48
"Share your feedback" => array( null, __("Share your feedback", "forminator"), ), // src/global/components/modals/feedback.js:94
"We’ve just started rolling out updates to the new form editor — and this is only the beginning!" => array( null, __("We’ve just started rolling out updates to the new form editor — and this is only the beginning!", "forminator"), ), // src/global/components/modals/feedback.js:99
"How was your experience with the new form editor?" => array( null, __("How was your experience with the new form editor?", "forminator"), ), // src/global/components/modals/feedback.js:108
"Dislike" => array( null, __("Dislike", "forminator"), ), // src/global/components/modals/feedback.js:124
"Love it!" => array( null, __("Love it!", "forminator"), ), // src/global/components/modals/feedback.js:127
"Additional details {{span}}(optional){{/span}}" => array( null, __("Additional details {{span}}(optional){{/span}}", "forminator"), ), // src/global/components/modals/feedback.js:136
"Tell us what you loved or what could be better..." => array( null, __("Tell us what you loved or what could be better...", "forminator"), ), // src/global/components/modals/feedback.js:152
"Share feedback" => array( null, __("Share feedback", "forminator"), ), // src/global/components/modals/feedback.js:163
"Sending feedback..." => array( null, __("Sending feedback...", "forminator"), ), // src/global/components/modals/feedback.js:167
"Poll Editor" => array( null, __("Poll Editor", "forminator"), ), // src/global/components/meta/status.js:62
"Quiz Editor" => array( null, __("Quiz Editor", "forminator"), ), // src/global/components/meta/status.js:65
"PDF Editor" => array( null, __("PDF Editor", "forminator"), ), // src/global/components/meta/status.js:69
"Form Editor" => array( null, __("Form Editor", "forminator"), ), // src/global/components/meta/status.js:69
"Back to form" => array( null, __("Back to form", "forminator"), ), // src/global/components/meta/status.js:85
"Live" => array( null, __("Live", "forminator"), ), // src/global/components/meta/status.js:109
"Draft" => array( null, __("Draft", "forminator"), ), // src/global/components/meta/status.js:111
"Auto-saving changes..." => array( null, __("Auto-saving changes...", "forminator"), ), // src/global/components/meta/status.js:121
"Auto-saving..." => array( null, __("Auto-saving...", "forminator"), ), // src/global/components/meta/status.js:121
"Saving changes..." => array( null, __("Saving changes...", "forminator"), ), // src/global/components/meta/status.js:129
"Saving..." => array( null, __("Saving...", "forminator"), ), // src/global/components/meta/status.js:129
"You’ve made changes that haven’t been saved yet. Click the Save icon to keep them." => array( null, __("You’ve made changes that haven’t been saved yet. Click the Save icon to keep them.", "forminator"), ), // src/global/components/meta/status.js:136
"Unsaved changes" => array( null, __("Unsaved changes", "forminator"), ), // src/global/components/meta/status.js:140
"Save changes" => array( null, __("Save changes", "forminator"), ), // src/global/components/meta/status.js:147
"Autosaved" => array( null, __("Autosaved", "forminator"), ), // src/global/components/meta/status.js:163
"Saved" => array( null, __("Saved", "forminator"), ), // src/global/components/meta/status.js:163
"These changes are saved but not yet published." => array( null, __("These changes are saved but not yet published.", "forminator"), ), // src/global/components/meta/status.js:173
"Click '%s' to make them live." => array( null, __("Click '%s' to make them live.", "forminator"), ), // src/global/components/meta/status.js:175
"Publish Changes" => array( null, __("Publish Changes", "forminator"), ), // src/global/components/meta/status.js:176
"Changes autosaved" => array( null, __("Changes autosaved", "forminator"), ), // src/global/components/meta/status.js:180
"Changes saved" => array( null, __("Changes saved", "forminator"), ), // src/global/components/meta/status.js:180
"Discard changes" => array( null, __("Discard changes", "forminator"), ), // src/global/components/meta/status.js:187
"Publish" => array( null, __("Publish", "forminator"), ), // src/global/components/meta/status.js:226
"Open form options" => array( null, __("Open form options", "forminator"), ), // src/global/components/meta/more-option.js:30
"Open poll options" => array( null, __("Open poll options", "forminator"), ), // src/global/components/meta/more-option.js:49
"Open quiz options" => array( null, __("Open quiz options", "forminator"), ), // src/global/components/meta/more-option.js:68
"Something went wrong." => array( null, __("Something went wrong.", "forminator"), ), // src/global/components/meta/more-option.js:109
"More options" => array( null, __("More options", "forminator"), ), // src/global/components/meta/more-option.js:170
"Create New" => array( null, __("Create New", "forminator"), ), // src/global/components/meta/more-option.js:189
"View Submissions" => array( null, __("View Submissions", "forminator"), ), // src/global/components/meta/more-option.js:229
"View Report" => array( null, __("View Report", "forminator"), ), // src/global/components/meta/more-option.js:243
"Reset Tracking Data" => array( null, __("Reset Tracking Data", "forminator"), ), // src/global/components/meta/more-option.js:257
"Unpublish" => array( null, __("Unpublish", "forminator"), ), // src/global/components/meta/more-option.js:273
"Duplicate isn't supported at the moment for the quizzes with lead capturing enabled." => array( null, __("Duplicate isn't supported at the moment for the quizzes with lead capturing enabled.", "forminator"), ), // src/global/components/meta/more-option.js:312
"Coming soon" => array( null, __("Coming soon", "forminator"), ), // src/global/components/meta/more-option.js:324
"Export isn't supported at the moment for the quizzes with lead capturing enabled." => array( null, __("Export isn't supported at the moment for the quizzes with lead capturing enabled.", "forminator"), ), // src/global/components/meta/more-option.js:347
"Export" => array( null, __("Export", "forminator"), ), // src/global/components/meta/more-option.js:356
"Documentation" => array( null, __("Documentation", "forminator"), ), // src/global/components/meta/more-option.js:390
"Security" => array( null, __("Security", "forminator"), ), // src/global/components/behaviour/security.js:28
"Added layers of security to prevent spam submissions." => array( null, __("Added layers of security to prevent spam submissions.", "forminator"), ), // src/global/components/behaviour/security.js:31
"Enable Honeypot protection" => array( null, __("Enable Honeypot protection", "forminator"), ), // src/global/components/behaviour/security.js:39
"Enabling this feature tricks spam bots by giving them a hidden challenge only bots will see. If the bot tries the challenge we know it's not a human and prevent the form being submitted." => array( null, __("Enabling this feature tricks spam bots by giving them a hidden challenge only bots will see. If the bot tries the challenge we know it's not a human and prevent the form being submitted.", "forminator"), ), // src/global/components/behaviour/security.js:42
"Enable Akismet spam protection" => array( null, __("Enable Akismet spam protection", "forminator"), ), // src/global/components/behaviour/security.js:51
"If you have installed the {{link}}Akismet anti-spam plugin{{/link}}, you can enable this option to tell Forminator how to handle submissions that Akismet flags as spam." => array( null, __("If you have installed the {{link}}Akismet anti-spam plugin{{/link}}, you can enable this option to tell Forminator how to handle submissions that Akismet flags as spam.", "forminator"), ), // src/global/components/behaviour/security.js:55
"How should Forminator handle spam submissions?" => array( null, __("How should Forminator handle spam submissions?", "forminator"), ), // src/global/components/behaviour/security.js:69
"Fail Submission" => array( null, __("Fail Submission", "forminator"), ), // src/global/components/behaviour/security.js:74
"Custom error message" => array( null, __("Custom error message", "forminator"), ), // src/global/components/behaviour/security.js:77
"Enter a custom error message to let your visitors know why the submission failed." => array( null, __("Enter a custom error message to let your visitors know why the submission failed.", "forminator"), ), // src/global/components/behaviour/security.js:81
"Mark as Spam" => array( null, __("Mark as Spam", "forminator"), ), // src/global/components/behaviour/security.js:87
"Entries marked as spam will be captured in the database, but not shown in Submissions. Additionally, Payments, Notification emails, and other automatic processes will be blocked." => array( null, __("Entries marked as spam will be captured in the database, but not shown in Submissions. Additionally, Payments, Notification emails, and other automatic processes will be blocked.", "forminator"), ), // src/global/components/behaviour/security.js:103
"Enable logged in submission only" => array( null, __("Enable logged in submission only", "forminator"), ), // src/global/components/behaviour/security.js:121
"Lock down your form submissions to registered users only." => array( null, __("Lock down your form submissions to registered users only.", "forminator"), ), // src/global/components/behaviour/security.js:124
"Submissions limit per logged in user" => array( null, __("Submissions limit per logged in user", "forminator"), ), // src/global/components/behaviour/security.js:130
"Enter the number of times a logged in user can submit this form. Leave blank or enter “0” for no limit." => array( null, __("Enter the number of times a logged in user can submit this form. Leave blank or enter “0” for no limit.", "forminator"), ), // src/global/components/behaviour/security.js:131
"Message when user has already reached submissions limit" => array( null, __("Message when user has already reached submissions limit", "forminator"), ), // src/global/components/behaviour/security.js:140
"You’ve already reached submissions limit." => array( null, __("You’ve already reached submissions limit.", "forminator"), ), // src/global/components/behaviour/security.js:141
"You don't have permission to edit this Registration Form. Contact a site administrator if you need access." => array( null, __("You don't have permission to edit this Registration Form. Contact a site administrator if you need access.", "forminator"), ), // src/form/containers/main.js:211
"Back" => array( null, __("Back", "forminator"), ), // src/form/containers/main.js:308
"remove" => array( null, __("remove", "forminator"), ), // src/form/components/settings.js:50
"retain" => array( null, __("retain", "forminator"), ), // src/form/components/settings.js:50
"By default we will store all submissions in your database." => array( null, __("By default we will store all submissions in your database.", "forminator"), ), // src/form/components/settings.js:70
"User’s Geolocation" => array( null, __("User’s Geolocation", "forminator"), ), // src/form/components/settings.js:92
"Enabling this option will attempt to collect and store users' location information when this form is submitted." => array( null, __("Enabling this option will attempt to collect and store users' location information when this form is submitted.", "forminator"), ), // src/form/components/settings.js:95
"Enable current user’s Geolocation" => array( null, __("Enable current user’s Geolocation", "forminator"), ), // src/form/components/settings.js:102
"Enable the checkbox to make it mandatory for users to grant access to the location permission to submit this form." => array( null, __("Enable the checkbox to make it mandatory for users to grant access to the location permission to submit this form.", "forminator"), ), // src/form/components/settings.js:107
"Require access to users' location" => array( null, __("Require access to users' location", "forminator"), ), // src/form/components/settings.js:111
"Error message" => array( null, __("Error message", "forminator"), ), // src/form/components/settings.js:117
"Enter message" => array( null, __("Enter message", "forminator"), ), // src/form/components/settings.js:118
"Multiple Option Value" => array( null, __("Multiple Option Value", "forminator"), ), // src/form/components/settings.js:129
"Choose how you want to handle multiple option values in form submissions and email notifications." => array( null, __("Choose how you want to handle multiple option values in form submissions and email notifications.", "forminator"), ), // src/form/components/settings.js:133
"Default Stored Value" => array( null, __("Default Stored Value", "forminator"), ), // src/form/components/settings.js:141
"By default, we store option labels of multiple option fields ({{strong}}e.g., Radio, Checkbox, and Select{{/strong}}) in submissions, and use the same in email notifications. You can choose to use option values instead." => array( null, __("By default, we store option labels of multiple option fields ({{strong}}e.g., Radio, Checkbox, and Select{{/strong}}) in submissions, and use the same in email notifications. You can choose to use option values instead.", "forminator"), ), // src/form/components/settings.js:145
"Option labels" => array( null, __("Option labels", "forminator"), ), // src/form/components/settings.js:160
"Option values" => array( null, __("Option values", "forminator"), ), // src/form/components/settings.js:162
"Email Image Options" => array( null, __("Email Image Options", "forminator"), ), // src/form/components/settings.js:171
"Choose how images are shown in email notifications. You can embed images directly in the email or display them as clickable links." => array( null, __("Choose how images are shown in email notifications. You can embed images directly in the email or display them as clickable links.", "forminator"), ), // src/form/components/settings.js:175
"Image Link" => array( null, __("Image Link", "forminator"), ), // src/form/components/settings.js:187
"This setting applies to images from E-Signature and File Upload fields." => array( null, __("This setting applies to images from E-Signature and File Upload fields.", "forminator"), ), // src/form/components/settings.js:202
"Image Preview" => array( null, __("Image Preview", "forminator"), ), // src/form/components/settings.js:209
"This setting applies to images from E-Signature, File Upload, Radio, and Checkbox fields." => array( null, __("This setting applies to images from E-Signature, File Upload, Radio, and Checkbox fields.", "forminator"), ), // src/form/components/settings.js:224
"Choose how you want to handle this form's data storage." => array( null, __("Choose how you want to handle this form's data storage.", "forminator"), ), // src/form/components/settings.js:242
"By default we will use the configuration you have set in your" => array( null, __("By default we will use the configuration you have set in your", "forminator"), ), // src/form/components/settings.js:247
"How long do you want to retain this form's submissions for?" => array( null, __("How long do you want to retain this form's submissions for?", "forminator"), ), // src/form/components/settings.js:262
"Your default setting value is to keep the submissions" => array( null, __("Your default setting value is to keep the submissions", "forminator"), ), // src/form/components/settings.js:290
"Days" => array( null, __("Days", "forminator"), ), // src/form/components/settings.js:324
"Weeks" => array( null, __("Weeks", "forminator"), ), // src/form/components/settings.js:327
"Months" => array( null, __("Months", "forminator"), ), // src/form/components/settings.js:330
"Years" => array( null, __("Years", "forminator"), ), // src/form/components/settings.js:333
"Account Erasure Requests" => array( null, __("Account Erasure Requests", "forminator"), ), // src/form/components/settings.js:349
"When handling an account erasure request that contains an email associated with a submission, what do you want to do?" => array( null, __("When handling an account erasure request that contains an email associated with a submission, what do you want to do?", "forminator"), ), // src/form/components/settings.js:353
"Your default setting value is to " => array( null, __("Your default setting value is to ", "forminator"), ), // src/form/components/settings.js:383
" the submission." => array( null, __(" the submission.", "forminator"), ), // src/form/components/settings.js:385
"Retain Submissions" => array( null, __("Retain Submissions", "forminator"), ), // src/form/components/settings.js:406
"Remove Submissions" => array( null, __("Remove Submissions", "forminator"), ), // src/form/components/settings.js:409
"Submission Files" => array( null, __("Submission Files", "forminator"), ), // src/form/components/settings.js:418
"If your form has file upload field(s), choose whether to delete the file(s) related to a submission when that submission gets deleted." => array( null, __("If your form has file upload field(s), choose whether to delete the file(s) related to a submission when that submission gets deleted.", "forminator"), ), // src/form/components/settings.js:421
"Keep" => array( null, __("Keep", "forminator"), ), // src/form/components/settings.js:431
"User Registration" => array( null, __("User Registration", "forminator"), ), // src/form/components/registration.js:32
"PDF" => array( null, __("PDF", "forminator"), ), // src/form/components/pdf.js:47
"Pro" => array( null, __("Pro", "forminator"), ), // src/form/components/pdf.js:52
"Generate and send PDF files (e.g. forms entries, receipts, invoices, quotations) to users after form submission." => array( null, __("Generate and send PDF files (e.g. forms entries, receipts, invoices, quotations) to users after form submission.", "forminator"), ), // src/form/components/pdf-disconnected.js:23
"Upgrade to PRO{{icon/}}" => array( null, __("Upgrade to PRO{{icon/}}", "forminator"), ), // src/form/components/pdf-disconnected.js:34
"You can send customized email notifications to your site admins and visitors on successful form submission. Advanced features like email routing and conditional emails provide granular control over the email notifications." => array( null, __("You can send customized email notifications to your site admins and visitors on successful form submission. Advanced features like email routing and conditional emails provide granular control over the email notifications.", "forminator"), ), // src/form/components/notifications.js:36
"Customize Form" => array( null, __("Customize Form", "forminator"), ), // src/form/components/navigation.js:10
"Something went wrong while reverting your form. Please try again." => array( null, __("Something went wrong while reverting your form. Please try again.", "forminator"), ), // src/form/components/meta.js:174
"Login User" => array( null, __("Login User", "forminator"), ), // src/form/components/login.js:30
"Don't send" => array( null, __("Don't send", "forminator"), ), // src/form/components/integrations.js:117
"data if" => array( null, __("data if", "forminator"), ), // src/form/components/integrations.js:127
"Applications" => array( null, __("Applications", "forminator"), ), // src/form/components/integrations.js:254
"You can send this form's data to any of the connected third party apps. Connect to more apps on the {{link}}Integrations{{/link}} page." => array( null, __("You can send this form's data to any of the connected third party apps. Connect to more apps on the {{link}}Integrations{{/link}} page.", "forminator"), ), // src/form/components/integrations.js:256
"Appearance Preview" => array( null, __("Appearance Preview", "forminator"), ), // src/form/components/instant-preview.js:126
"In Preview mode, Conditional Logic is ignored so you can see all fields and review the full layout." => array( null, __("In Preview mode, Conditional Logic is ignored so you can see all fields and review the full layout.", "forminator"), ), // src/form/components/instant-preview.js:129
"Stripe field has been migrated successfully." => array( null, __("Stripe field has been migrated successfully.", "forminator"), ), // src/form/components/builder.js:60
"Please review the updated settings of the new Stripe field below. If everything works fine, feel free to remove the old Stripe field." => array( null, __("Please review the updated settings of the new Stripe field below. If everything works fine, feel free to remove the old Stripe field.", "forminator"), ), // src/form/components/builder.js:62
"{{b}}Warning!{{/b}} You are using the Stripe simple Card Element which is being deprecated. To ensure seamless transaction, migrate to the new Stripe Payment Element field." => array( null, __("{{b}}Warning!{{/b}} You are using the Stripe simple Card Element which is being deprecated. To ensure seamless transaction, migrate to the new Stripe Payment Element field.", "forminator"), ), // src/form/components/builder.js:88
"Migrate to new Stripe field" => array( null, __("Migrate to new Stripe field", "forminator"), ), // src/form/components/builder.js:100
"This form includes a Stripe or PayPal field that needs to be configured if you wish to accept payments through this form. To set it up, click the button below, or remove the payment field from the form." => array( null, __("This form includes a Stripe or PayPal field that needs to be configured if you wish to accept payments through this form. To set it up, click the button below, or remove the payment field from the form.", "forminator"), ), // src/form/components/builder.js:153
"Set API keys" => array( null, __("Set API keys", "forminator"), ), // src/form/components/builder.js:165
"Product ID for the subscription plan on Stripe has not been created. {{link}}Verify your Stripe keys{{/link}} and click the {{b}}Update{{/b}} button on this form." => array( null, __("Product ID for the subscription plan on Stripe has not been created. {{link}}Verify your Stripe keys{{/link}} and click the {{b}}Update{{/b}} button on this form.", "forminator"), ), // src/form/components/builder.js:174
"Form created successfully." => array( null, __("Form created successfully.", "forminator"), ), // src/form/components/builder.js:241
"Some of the settings you'd find in a regular form are unavailable in this form template because they are either unnecessary or controlled by the parent quiz automatically." => array( null, __("Some of the settings you'd find in a regular form are unavailable in this form template because they are either unnecessary or controlled by the parent quiz automatically.", "forminator"), ), // src/form/components/behaviour.js:71
"Global Appearance Presets" => array( null, __("Global Appearance Presets", "forminator"), ), // src/form/components/appearance.js:47
"Layout and Spacing" => array( null, __("Layout and Spacing", "forminator"), ), // src/form/components/appearance.js:73
"Form Abandonment" => array( null, __("Form Abandonment", "forminator"), ), // src/form/components/abandonment.js:44
"New" => array( null, __("New", "forminator"), ), // src/form/components/abandonment.js:49
"FREE PLAN" => array( null, __("FREE PLAN", "forminator"), ), // src/form/components/abandonment.js:54
"this field if" => array( null, __("this field if", "forminator"), ), // src/form/components/settings/visibility.js:157
"this page when" => array( null, __("this page when", "forminator"), ), // src/form/components/settings/visibility.js:157
"Process this plan if" => array( null, __("Process this plan if", "forminator"), ), // src/form/components/settings/visibility.js:185
"of the following conditions match:" => array( null, __("of the following conditions match:", "forminator"), ), // src/form/components/settings/visibility.js:200
"Note: The conditions on this page will be ignored as the last page will always be visible." => array( null, __("Note: The conditions on this page will be ignored as the last page will always be visible.", "forminator"), ), // src/form/components/settings/visibility.js:229
"You can't apply visibility rules to the last page. It will always be visible." => array( null, __("You can't apply visibility rules to the last page. It will always be visible.", "forminator"), ), // src/form/components/settings/visibility.js:249
"Rules" => array( null, __("Rules", "forminator"), ), // src/form/components/settings/visibility.js:262
"Set conditions to display this field only when specific criteria are met—like selecting a checkbox or entering a certain value." => array( null, __("Set conditions to display this field only when specific criteria are met—like selecting a checkbox or entering a certain value.", "forminator"), ), // src/form/components/settings/visibility.js:269
"Set a condition to display this page and its fields only when specific criteria are met—like selecting a checkbox or entering a certain value." => array( null, __("Set a condition to display this page and its fields only when specific criteria are met—like selecting a checkbox or entering a certain value.", "forminator"), ), // src/form/components/settings/visibility.js:270
"{{link}}Learn more{{/link}}" => array( null, __("{{link}}Learn more{{/link}}", "forminator"), ), // src/form/components/settings/visibility.js:272
"By default, this page is always visible." => array( null, __("By default, this page is always visible.", "forminator"), ), // src/form/components/settings/visibility.js:290
"Add a rule to control when it should be hidden or shown." => array( null, __("Add a rule to control when it should be hidden or shown.", "forminator"), ), // src/form/components/settings/visibility.js:292
"Add conditions for how this plan will be processed based on your form field data." => array( null, __("Add conditions for how this plan will be processed based on your form field data.", "forminator"), ), // src/form/components/settings/visibility.js:295
"By default, this field is always visible." => array( null, __("By default, this field is always visible.", "forminator"), ), // src/form/components/settings/visibility.js:298
"Add rules to control when it should appear based on user input." => array( null, __("Add rules to control when it should appear based on user input.", "forminator"), ), // src/form/components/settings/visibility.js:300
"You need more than one field to configure visibility conditions. Add more fields!" => array( null, __("You need more than one field to configure visibility conditions. Add more fields!", "forminator"), ), // src/form/components/settings/visibility.js:322
"Add conditions" => array( null, __("Add conditions", "forminator"), ), // src/form/components/settings/visibility.js:358
"checked" => array( null, __("checked", "forminator"), ), // src/form/components/settings/visibility-rule.js:87
"Is before" => array( null, __("Is before", "forminator"), ), // src/form/components/settings/visibility-rule.js:298
"Is after" => array( null, __("Is after", "forminator"), ), // src/form/components/settings/visibility-rule.js:301
"Is before n or more days" => array( null, __("Is before n or more days", "forminator"), ), // src/form/components/settings/visibility-rule.js:304
"Is before less than n days" => array( null, __("Is before less than n days", "forminator"), ), // src/form/components/settings/visibility-rule.js:307
"Is after n or more days" => array( null, __("Is after n or more days", "forminator"), ), // src/form/components/settings/visibility-rule.js:310
"Is after less than n days" => array( null, __("Is after less than n days", "forminator"), ), // src/form/components/settings/visibility-rule.js:313
"Select date" => array( null, __("Select date", "forminator"), ), // src/form/components/settings/visibility-rule.js:431
"Number of days" => array( null, __("Number of days", "forminator"), ), // src/form/components/settings/visibility-rule.js:457
"E.g. 10" => array( null, __("E.g. 10", "forminator"), ), // src/form/components/settings/visibility-rule.js:458
"Validate" => array( null, __("Validate", "forminator"), ), // src/form/components/settings/validation.js:31
"Make sure the user has filled out this field correctly and warn them when they haven't." => array( null, __("Make sure the user has filled out this field correctly and warn them when they haven't.", "forminator"), ), // src/form/components/settings/validation.js:34
"Validate Field" => array( null, __("Validate Field", "forminator"), ), // src/form/components/settings/validation.js:51
"Validation message" => array( null, __("Validation message", "forminator"), ), // src/form/components/settings/validation.js:62
"Enter validation message" => array( null, __("Enter validation message", "forminator"), ), // src/form/components/settings/validation.js:68
"Confirm Email error messages" => array( null, __("Confirm Email error messages", "forminator"), ), // src/form/components/settings/validation-confirm-email.js:17
"Use this option to customize error messages for the Confirm Email field, ensuring users enter a matching email address." => array( null, __("Use this option to customize error messages for the Confirm Email field, ensuring users enter a matching email address.", "forminator"), ), // src/form/components/settings/validation-confirm-email.js:20
"Error message for empty Confirm Email field" => array( null, __("Error message for empty Confirm Email field", "forminator"), ), // src/form/components/settings/validation-confirm-email.js:30
"You must confirm your email address" => array( null, __("You must confirm your email address", "forminator"), ), // src/form/components/settings/validation-confirm-email.js:31
"Email mis-match error message" => array( null, __("Email mis-match error message", "forminator"), ), // src/form/components/settings/validation-confirm-email.js:37
"Add User Role" => array( null, __("Add User Role", "forminator"), ), // src/form/components/settings/user-role.js:174
"Network's Main Site Role" => array( null, __("Network's Main Site Role", "forminator"), ), // src/form/components/settings/user-role-rule.js:158
"If you don't want to create a user in the network's main site, set this meta key to {{strong}}Don't create a user in the network's main site{{/strong}}." => array( null, __("If you don't want to create a user in the network's main site, set this meta key to {{strong}}Don't create a user in the network's main site{{/strong}}.", "forminator"), ), // src/form/components/settings/user-role-rule.js:160
"{{strong}}\"%(label)s\"{{/strong}} when {{strong}}%(field)s{{/strong}} %(rule)s {{strong}}%(value)s{{/strong}}" => array( null, __("{{strong}}\"%(label)s\"{{/strong}} when {{strong}}%(field)s{{/strong}} %(rule)s {{strong}}%(value)s{{/strong}}", "forminator"), ), // src/form/components/settings/user-role-rule.js:200
"Condition (Required)" => array( null, __("Condition (Required)", "forminator"), ), // src/form/components/settings/user-role-rule.js:278
"Enter value" => array( null, __("Enter value", "forminator"), ), // src/form/components/settings/user-role-rule.js:407
"Additional CSS Classes" => array( null, __("Additional CSS Classes", "forminator"), ), // src/form/components/settings/styling.js:35
"Add custom CSS classes to style this field’s container—great for adjusting spacing, colors, or layout." => array( null, __("Add custom CSS classes to style this field’s container—great for adjusting spacing, colors, or layout.", "forminator"), ), // src/form/components/settings/styling.js:39
"E.g. form-field" => array( null, __("E.g. form-field", "forminator"), ), // src/form/components/settings/styling.js:60
"Add one or more class names, separated by spaces. These apply to the field container." => array( null, __("Add one or more class names, separated by spaces. These apply to the field container.", "forminator"), ), // src/form/components/settings/styling.js:69
"Field Description Placement" => array( null, __("Field Description Placement", "forminator"), ), // src/form/components/settings/styling.js:79
"Select where the description of this field should appear." => array( null, __("Select where the description of this field should appear.", "forminator"), ), // src/form/components/settings/styling.js:83
"Enter required message" => array( null, __("Enter required message", "forminator"), ), // src/form/components/settings/required.js:44
"Required" => array( null, __("Required", "forminator"), ), // src/form/components/settings/required.js:56
"Force users to fill out this field, otherwise it will be optional." => array( null, __("Force users to fill out this field, otherwise it will be optional.", "forminator"), ), // src/form/components/settings/required.js:59
"Optional" => array( null, __("Optional", "forminator"), ), // src/form/components/settings/required.js:70
"Password error message" => array( null, __("Password error message", "forminator"), ), // src/form/components/settings/required.js:96
"‘Other’ Field validation message" => array( null, __("‘Other’ Field validation message", "forminator"), ), // src/form/components/settings/required.js:130
"Please, enter a custom value" => array( null, __("Please, enter a custom value", "forminator"), ), // src/form/components/settings/required.js:136
"Confirm Password error message" => array( null, __("Confirm Password error message", "forminator"), ), // src/form/components/settings/required.js:159
"Enter confirm password message" => array( null, __("Enter confirm password message", "forminator"), ), // src/form/components/settings/required.js:165
"radio button" => array( null, __("radio button", "forminator"), ), // src/form/components/settings/radio-checkbox-visibility.js:23
"checkbox" => array( null, __("checkbox", "forminator"), ), // src/form/components/settings/radio-checkbox-visibility.js:24
"visibility" => array( null, __("visibility", "forminator"), ), // src/form/components/settings/radio-checkbox-visibility.js:35
"{{b}}Note:{{/b}} Using WordPress Reserved Terms as query parameters may cause unexpected form behavior. Find the complete list of {{link}}{{icon/}} WordPress Reserved Terms here{{/link}}." => array( null, __("{{b}}Note:{{/b}} Using WordPress Reserved Terms as query parameters may cause unexpected form behavior. Find the complete list of {{link}}{{icon/}} WordPress Reserved Terms here{{/link}}.", "forminator"), ), // src/form/components/settings/prefill.js:17
"Automatically fill this field using a value passed through your form URL. Enter the query parameter key used in your URL—for example, email in ?email=value. When the form loads, the field will be filled with the matching value." => array( null, __("Automatically fill this field using a value passed through your form URL. Enter the query parameter key used in your URL—for example, email in ?email=value. When the form loads, the field will be filled with the matching value.", "forminator"), ), // src/form/components/settings/prefill.js:39
"Pre-populate" => array( null, __("Pre-populate", "forminator"), ), // src/form/components/settings/prefill.js:54
"Query parameter (optional)" => array( null, __("Query parameter (optional)", "forminator"), ), // src/form/components/settings/prefill.js:63
"E.g. query_parameter_key" => array( null, __("E.g. query_parameter_key", "forminator"), ), // src/form/components/settings/prefill.js:65
"Page" => array( null, __("Page", "forminator"), ), // src/form/components/settings/pagination-custom-text.js:16
"Previous Button" => array( null, __("Previous Button", "forminator"), ), // src/form/components/settings/pagination-custom-text.js:17
"Next Button" => array( null, __("Next Button", "forminator"), ), // src/form/components/settings/pagination-custom-text.js:18
"No Previous button" => array( null, __("No Previous button", "forminator"), ), // src/form/components/settings/pagination-custom-text.js:36
"No Next button" => array( null, __("No Next button", "forminator"), ), // src/form/components/settings/pagination-custom-text.js:106
"options display order" => array( null, __("options display order", "forminator"), ), // src/form/components/settings/options-order.js:28
"Orderly" => array( null, __("Orderly", "forminator"), ), // src/form/components/settings/options-order.js:47
"Random" => array( null, __("Random", "forminator"), ), // src/form/components/settings/options-order.js:48
"Other" => array( null, __("Other", "forminator"), ), // src/form/components/settings/multi-value.js:40
"The File APIs are not fully supported in this browser. You may copy and paste your options on the text area above or switch to a modern browser to use the importer." => array( null, __("The File APIs are not fully supported in this browser. You may copy and paste your options on the text area above or switch to a modern browser to use the importer.", "forminator"), ), // src/form/components/settings/multi-value.js:186
"Whoops, only .csv filetype is allowed." => array( null, __("Whoops, only .csv filetype is allowed.", "forminator"), ), // src/form/components/settings/multi-value.js:218
"Importing this will replace your current options. Click import to continue." => array( null, __("Importing this will replace your current options. Click import to continue.", "forminator"), ), // src/form/components/settings/multi-value.js:227
"This browser doesn't seem to support the `files` property of file inputs." => array( null, __("This browser doesn't seem to support the `files` property of file inputs.", "forminator"), ), // src/form/components/settings/multi-value.js:255
"Option " => array( null, __("Option ", "forminator"), ), // src/form/components/settings/multi-value.js:613
"Expand All" => array( null, __("Expand All", "forminator"), ), // src/form/components/settings/multi-value.js:711
"Collapse All" => array( null, __("Collapse All", "forminator"), ), // src/form/components/settings/multi-value.js:712
"Select" => array( null, __("Select", "forminator"), ), // src/form/components/settings/multi-value.js:730
"Radio" => array( null, __("Radio", "forminator"), ), // src/form/components/settings/multi-value.js:733
"Checkbox" => array( null, __("Checkbox", "forminator"), ), // src/form/components/settings/multi-value.js:736
"Label; value; selection (0 or 1); image-url" => array( null, __("Label; value; selection (0 or 1); image-url", "forminator"), ), // src/form/components/settings/multi-value.js:740
"Label; value; selection (0 or 1); submission limit" => array( null, __("Label; value; selection (0 or 1); submission limit", "forminator"), ), // src/form/components/settings/multi-value.js:743
"Label; value; selection (0 or 1)" => array( null, __("Label; value; selection (0 or 1)", "forminator"), ), // src/form/components/settings/multi-value.js:745
"Warning! You've added more than 1000 options. Switching back to the standard (non-bulk) editor could make your browser slow or unresponsive. Proceed with caution." => array( null, __("Warning! You've added more than 1000 options. Switching back to the standard (non-bulk) editor could make your browser slow or unresponsive. Proceed with caution.", "forminator"), ), // src/form/components/settings/multi-value.js:779
"Other option" => array( null, __("Other option", "forminator"), ), // src/form/components/settings/multi-value.js:801
"Bulk Edit" => array( null, __("Bulk Edit", "forminator"), ), // src/form/components/settings/multi-value.js:832
"Loading" => array( null, __("Loading", "forminator"), ), // src/form/components/settings/multi-value.js:843
"Add Option" => array( null, __("Add Option", "forminator"), ), // src/form/components/settings/multi-value.js:887
"Enter field options (one per line)" => array( null, __("Enter field options (one per line)", "forminator"), ), // src/form/components/settings/multi-value.js:904
"Import options from CSV" => array( null, __("Import options from CSV", "forminator"), ), // src/form/components/settings/multi-value.js:922
"Import" => array( null, __("Import", "forminator"), ), // src/form/components/settings/multi-value.js:945
"Choose a CSV (.csv) file to import field options and values." => array( null, __("Choose a CSV (.csv) file to import field options and values.", "forminator"), ), // src/form/components/settings/multi-value.js:971
"Download csv template" => array( null, __("Download csv template", "forminator"), ), // src/form/components/settings/multi-value.js:974
"Toggle" => array( null, __("Toggle", "forminator"), ), // src/form/components/settings/multi-option.js:188
"Selected" => array( null, __("Selected", "forminator"), ), // src/form/components/settings/multi-option.js:237
"Delete option" => array( null, __("Delete option", "forminator"), ), // src/form/components/settings/multi-option.js:249
"Submission limit" => array( null, __("Submission limit", "forminator"), ), // src/form/components/settings/multi-option.js:280
"First Name" => array( null, __("First Name", "forminator"), ), // src/form/components/settings/multi-name.js:20
"Middle Name" => array( null, __("Middle Name", "forminator"), ), // src/form/components/settings/multi-name.js:24
"Last Name" => array( null, __("Last Name", "forminator"), ), // src/form/components/settings/multi-name.js:28
"Prefix" => array( null, __("Prefix", "forminator"), ), // src/form/components/settings/multi-name.js:36
"Enter label" => array( null, __("Enter label", "forminator"), ), // src/form/components/settings/multi-name.js:48
"Default value" => array( null, __("Default value", "forminator"), ), // src/form/components/settings/multi-name.js:55
"Mr." => array( null, __("Mr.", "forminator"), ), // src/form/components/settings/multi-name.js:59
"Mrs." => array( null, __("Mrs.", "forminator"), ), // src/form/components/settings/multi-name.js:60
"Ms." => array( null, __("Ms.", "forminator"), ), // src/form/components/settings/multi-name.js:61
"Mx." => array( null, __("Mx.", "forminator"), ), // src/form/components/settings/multi-name.js:62
"Miss" => array( null, __("Miss", "forminator"), ), // src/form/components/settings/multi-name.js:63
"Dr." => array( null, __("Dr.", "forminator"), ), // src/form/components/settings/multi-name.js:64
"Prof." => array( null, __("Prof.", "forminator"), ), // src/form/components/settings/multi-name.js:65
"Enter description" => array( null, __("Enter description", "forminator"), ), // src/form/components/settings/multi-name.js:75
"Placeholder (optional)" => array( null, __("Placeholder (optional)", "forminator"), ), // src/form/components/settings/multi-name.js:107
"Other option placeholder" => array( null, __("Other option placeholder", "forminator"), ), // src/form/components/settings/multi-custom-option.js:85
"Add Custom User Meta" => array( null, __("Add Custom User Meta", "forminator"), ), // src/form/components/settings/multi-custom-field-value.js:137
"Delete meta" => array( null, __("Delete meta", "forminator"), ), // src/form/components/settings/multi-custom-field-option.js:113
"Add Custom Meta" => array( null, __("Add Custom Meta", "forminator"), ), // src/form/components/settings/metadata-value.js:132
"No custom meta data created yet. Click on \"+ Add Custom to create custom meta and map form fields to it." => array( null, __("No custom meta data created yet. Click on \"+ Add Custom to create custom meta and map form fields to it.", "forminator"), ), // src/form/components/settings/metadata-value.js:142
"Select a Field" => array( null, __("Select a Field", "forminator"), ), // src/form/components/settings/metadata-option.js:83
"Delete MetaData" => array( null, __("Delete MetaData", "forminator"), ), // src/form/components/settings/metadata-option.js:102
"Start & End date" => array( null, __("Start & End date", "forminator"), ), // src/form/components/settings/limits.js:71
"Choose a start and end date limit for the calendar to restrict the date selection between a specific date range. Note that we will use the timezone set in your {{a}}WordPress Settings{{/a}}." => array( null, __("Choose a start and end date limit for the calendar to restrict the date selection between a specific date range. Note that we will use the timezone set in your {{a}}WordPress Settings{{/a}}.", "forminator"), ), // src/form/components/settings/limits.js:75
"Start Date" => array( null, __("Start Date", "forminator"), ), // src/form/components/settings/limits.js:97
"No limit" => array( null, __("No limit", "forminator"), ), // src/form/components/settings/limits.js:102
"Specific date" => array( null, __("Specific date", "forminator"), ), // src/form/components/settings/limits.js:103
"Today" => array( null, __("Today", "forminator"), ), // src/form/components/settings/limits.js:104
"Date fields" => array( null, __("Date fields", "forminator"), ), // src/form/components/settings/limits.js:106
"Pick a date" => array( null, __("Pick a date", "forminator"), ), // src/form/components/settings/limits.js:130
"Offset (optional)" => array( null, __("Offset (optional)", "forminator"), ), // src/form/components/settings/limits.js:143
"+" => array( null, __("+", "forminator"), ), // src/form/components/settings/limits.js:156
"-" => array( null, __("-", "forminator"), ), // src/form/components/settings/limits.js:157
"days" => array( null, __("days", "forminator"), ), // src/form/components/settings/limits.js:177
"weeks" => array( null, __("weeks", "forminator"), ), // src/form/components/settings/limits.js:178
"months" => array( null, __("months", "forminator"), ), // src/form/components/settings/limits.js:179
"years" => array( null, __("years", "forminator"), ), // src/form/components/settings/limits.js:180
"End Date" => array( null, __("End Date", "forminator"), ), // src/form/components/settings/limits.js:198
"Days of the week" => array( null, __("Days of the week", "forminator"), ), // src/form/components/settings/limits.js:297
"Choose which days of the week should be available on the calendar." => array( null, __("Choose which days of the week should be available on the calendar.", "forminator"), ), // src/form/components/settings/limits.js:301
"All days" => array( null, __("All days", "forminator"), ), // src/form/components/settings/limits.js:311
"Selected days" => array( null, __("Selected days", "forminator"), ), // src/form/components/settings/limits.js:317
"Sunday" => array( null, __("Sunday", "forminator"), ), // src/form/components/settings/limits.js:329
"Wednesday" => array( null, __("Wednesday", "forminator"), ), // src/form/components/settings/limits.js:337
"Saturday" => array( null, __("Saturday", "forminator"), ), // src/form/components/settings/limits.js:345
"Monday" => array( null, __("Monday", "forminator"), ), // src/form/components/settings/limits.js:357
"Thursday" => array( null, __("Thursday", "forminator"), ), // src/form/components/settings/limits.js:365
"Tuesday" => array( null, __("Tuesday", "forminator"), ), // src/form/components/settings/limits.js:377
"Friday" => array( null, __("Friday", "forminator"), ), // src/form/components/settings/limits.js:385
"Disable dates" => array( null, __("Disable dates", "forminator"), ), // src/form/components/settings/limits.js:403
"Use this setting to disable specific dates on the calendar." => array( null, __("Use this setting to disable specific dates on the calendar.", "forminator"), ), // src/form/components/settings/limits.js:406
"Disable date ranges" => array( null, __("Disable date ranges", "forminator"), ), // src/form/components/settings/limits.js:420
"Use this setting to disable specific dates ranges on the calendar." => array( null, __("Use this setting to disable specific dates ranges on the calendar.", "forminator"), ), // src/form/components/settings/limits.js:423
"Error Message" => array( null, __("Error Message", "forminator"), ), // src/form/components/settings/limits.js:436
"Choose an error message to be used when visitor enters a date that is disabled." => array( null, __("Choose an error message to be used when visitor enters a date that is disabled.", "forminator"), ), // src/form/components/settings/limits.js:440
"Confirm Email" => array( null, __("Confirm Email", "forminator"), ), // src/form/components/settings/labels.js:54
"Confirm Email Address" => array( null, __("Confirm Email Address", "forminator"), ), // src/form/components/settings/labels.js:67
"Re-type Email Address" => array( null, __("Re-type Email Address", "forminator"), ), // src/form/components/settings/labels.js:78
"Failed to connect to the Google Maps API. Please ensure you have entered a valid API key in the {{link}}Settings page{{/link}}." => array( null, __("Failed to connect to the Google Maps API. Please ensure you have entered a valid API key in the {{link}}Settings page{{/link}}.", "forminator"), ), // src/form/components/settings/geolocation.js:65
"Autocomplete" => array( null, __("Autocomplete", "forminator"), ), // src/form/components/settings/geolocation.js:85
"Enable this option to integrate Google Maps' address auto-completion service into your addresses field. This powerful feature will simplify the address entry process for users by providing real-time suggestions as they type." => array( null, __("Enable this option to integrate Google Maps' address auto-completion service into your addresses field. This powerful feature will simplify the address entry process for users by providing real-time suggestions as they type.", "forminator"), ), // src/form/components/settings/geolocation.js:88
"Display address on Map" => array( null, __("Display address on Map", "forminator"), ), // src/form/components/settings/geolocation.js:106
"Use this option to display a Google Map next to your address field(s), showing the entered address. Users will be able to see their selected address on the map." => array( null, __("Use this option to display a Google Map next to your address field(s), showing the entered address. Users will be able to see their selected address on the map.", "forminator"), ), // src/form/components/settings/geolocation.js:109
"Map position" => array( null, __("Map position", "forminator"), ), // src/form/components/settings/geolocation.js:129
"The map is displayed at the bottom of the address field by default. You can also set it to be displayed above the address field below." => array( null, __("The map is displayed at the bottom of the address field by default. You can also set it to be displayed above the address field below.", "forminator"), ), // src/form/components/settings/geolocation.js:132
"Above Address field(s)" => array( null, __("Above Address field(s)", "forminator"), ), // src/form/components/settings/geolocation.js:146
"Below Address field(s)" => array( null, __("Below Address field(s)", "forminator"), ), // src/form/components/settings/geolocation.js:147
"Map Size" => array( null, __("Map Size", "forminator"), ), // src/form/components/settings/geolocation.js:173
"Set the size of your map." => array( null, __("Set the size of your map.", "forminator"), ), // src/form/components/settings/geolocation.js:176
"Responsive" => array( null, __("Responsive", "forminator"), ), // src/form/components/settings/geolocation.js:188
"Custom Size" => array( null, __("Custom Size", "forminator"), ), // src/form/components/settings/geolocation.js:192
"Enter Height" => array( null, __("Enter Height", "forminator"), ), // src/form/components/settings/geolocation.js:206
"Enter Width" => array( null, __("Enter Width", "forminator"), ), // src/form/components/settings/geolocation.js:219
"Default map location" => array( null, __("Default map location", "forminator"), ), // src/form/components/settings/geolocation.js:231
"By default we show a 0.0 latitude and longitude on the map, you can use the option below to specify a default geolocation to display on the Map." => array( null, __("By default we show a 0.0 latitude and longitude on the map, you can use the option below to specify a default geolocation to display on the Map.", "forminator"), ), // src/form/components/settings/geolocation.js:234
"Default location" => array( null, __("Default location", "forminator"), ), // src/form/components/settings/geolocation.js:246
"Custom location" => array( null, __("Custom location", "forminator"), ), // src/form/components/settings/geolocation.js:250
"Enter coordinates" => array( null, __("Enter coordinates", "forminator"), ), // src/form/components/settings/geolocation.js:261
"E.g., 1.234567, 9.876543" => array( null, __("E.g., 1.234567, 9.876543", "forminator"), ), // src/form/components/settings/geolocation.js:262
"To get coordinates, visit {{link}}https://map.google.com{{/link}} navigate to your preferred location, and right-click on any point and click on the first option with digits." => array( null, __("To get coordinates, visit {{link}}https://map.google.com{{/link}} navigate to your preferred location, and right-click on any point and click on the first option with digits.", "forminator"), ), // src/form/components/settings/geolocation.js:264
"E.g., 16" => array( null, __("E.g., 16", "forminator"), ), // src/form/components/settings/fonts.js:108
"Add a comma-separated list of additional file types along with their MIME types separated by “ | ”." => array( null, __("Add a comma-separated list of additional file types along with their MIME types separated by “ | ”.", "forminator"), ), // src/form/components/settings/filetypes.js:117
"Allowed filetypes" => array( null, __("Allowed filetypes", "forminator"), ), // src/form/components/settings/filetypes.js:134
"We use WordPress' {{a}}default allowed mime types{{/a}} to determine which file types can be uploaded. If you want to allow or restrict specific file types from being upload, you can do so by choosing the Specific filetypes option below." => array( null, __("We use WordPress' {{a}}default allowed mime types{{/a}} to determine which file types can be uploaded. If you want to allow or restrict specific file types from being upload, you can do so by choosing the Specific filetypes option below.", "forminator"), ), // src/form/components/settings/filetypes.js:137
"Specific filetypes" => array( null, __("Specific filetypes", "forminator"), ), // src/form/components/settings/filetypes.js:165
"Images" => array( null, __("Images", "forminator"), ), // src/form/components/settings/filetypes.js:174
"Documents" => array( null, __("Documents", "forminator"), ), // src/form/components/settings/filetypes.js:184
"Audio" => array( null, __("Audio", "forminator"), ), // src/form/components/settings/filetypes.js:194
"Video" => array( null, __("Video", "forminator"), ), // src/form/components/settings/filetypes.js:204
"Archive" => array( null, __("Archive", "forminator"), ), // src/form/components/settings/filetypes.js:216
"Text" => array( null, __("Text", "forminator"), ), // src/form/components/settings/filetypes.js:226
"Spreadsheet" => array( null, __("Spreadsheet", "forminator"), ), // src/form/components/settings/filetypes.js:236
"Interactive" => array( null, __("Interactive", "forminator"), ), // src/form/components/settings/filetypes.js:246
"Additional filetypes" => array( null, __("Additional filetypes", "forminator"), ), // src/form/components/settings/filetypes.js:259
"E.g. .dts|audio/vnd.dts, .ai|application/postscript" => array( null, __("E.g. .dts|audio/vnd.dts, .ai|application/postscript", "forminator"), ), // src/form/components/settings/filetypes.js:260
"Note that if you're having trouble uploading one of the enabled filetypes, that filetype may be restricted by your hosting provider." => array( null, __("Note that if you're having trouble uploading one of the enabled filetypes, that filetype may be restricted by your hosting provider.", "forminator"), ), // src/form/components/settings/filetypes.js:278
"For security reasons, the following file types are disabled by default: .htm, .html, .shtml, .phtml, .jse, .jar, .xml, .css, .asp, .aspx, .jsp, .sql, .hta, .dll, .bat, .com, .sh, .bash, .py, .pl, .js, .php, .svg, .swf, .dfxp, .rar and .exe. The above file types could potentially allow malicious files to be uploaded, which could be used to gain access to your site." => array( null, __("For security reasons, the following file types are disabled by default: .htm, .html, .shtml, .phtml, .jse, .jar, .xml, .css, .asp, .aspx, .jsp, .sql, .hta, .dll, .bat, .com, .sh, .bash, .py, .pl, .js, .php, .svg, .swf, .dfxp, .rar and .exe. The above file types could potentially allow malicious files to be uploaded, which could be used to gain access to your site.", "forminator"), ), // src/form/components/settings/filetypes.js:306
"Above Inputs" => array( null, __("Above Inputs", "forminator"), ), // src/form/components/settings/description-placement.js:23
"Below Inputs" => array( null, __("Below Inputs", "forminator"), ), // src/form/components/settings/description-placement.js:26
"Pick custom date(s) to restrict" => array( null, __("Pick custom date(s) to restrict", "forminator"), ), // src/form/components/settings/date-multiple.js:67
"Restricted dates" => array( null, __("Restricted dates", "forminator"), ), // src/form/components/settings/date-multiple.js:93
"Enable browser autofill" => array( null, __("Enable browser autofill", "forminator"), ), // src/form/components/settings/browser-autofill.js:30
"Allow browsers to automatically fill this field when the form loads." => array( null, __("Allow browsers to automatically fill this field when the form loads.", "forminator"), ), // src/form/components/settings/browser-autofill.js:34
"Unknown setting" => array( null, __("Unknown setting", "forminator"), ), // src/form/components/settings/advanced.js:110
"It is impossible to disable calculation for this field because it is in use in %(names)s field(s)." => array( null, __("It is impossible to disable calculation for this field because it is in use in %(names)s field(s).", "forminator"), ), // src/form/components/settings/calculations/toggle.js:80
"Choose whether to allow this field to be used in calculations or not. The value used in calculations is the same as the input value of this field." => array( null, __("Choose whether to allow this field to be used in calculations or not. The value used in calculations is the same as the input value of this field.", "forminator"), ), // src/form/components/settings/calculations/toggle.js:91
"Calculations" => array( null, __("Calculations", "forminator"), ), // src/form/components/settings/calculations/toggle.js:112
"Assign a calculation value to each option. These values will not be shown on the form. You can assign only a numeric value." => array( null, __("Assign a calculation value to each option. These values will not be shown on the form. You can assign only a numeric value.", "forminator"), ), // src/form/components/settings/calculations/options.js:43
"Calculation value" => array( null, __("Calculation value", "forminator"), ), // src/form/components/settings/calculations/options.js:61
"Calculation value is required!" => array( null, __("Calculation value is required!", "forminator"), ), // src/form/components/settings/calculations/options.js:69
"When this field is hidden, should its value be null (zero), or should the field be ignored in calculations?" => array( null, __("When this field is hidden, should its value be null (zero), or should the field be ignored in calculations?", "forminator"), ), // src/form/components/settings/calculations/hidden-behavior.js:19
"Null (zero)" => array( null, __("Null (zero)", "forminator"), ), // src/form/components/settings/calculations/hidden-behavior.js:22
"Ignore this field" => array( null, __("Ignore this field", "forminator"), ), // src/form/components/settings/calculations/hidden-behavior.js:23
"Site Registration" => array( null, __("Site Registration", "forminator"), ), // src/form/components/registration/site-registration.js:23
"Choose whether to allow site registrations on your multisite network and different related settings." => array( null, __("Choose whether to allow site registrations on your multisite network and different related settings.", "forminator"), ), // src/form/components/registration/site-registration.js:27
"Assign form fields to the default WordPress site meta keys below." => array( null, __("Assign form fields to the default WordPress site meta keys below.", "forminator"), ), // src/form/components/registration/site-registration.js:52
"Site Name" => array( null, __("Site Name", "forminator"), ), // src/form/components/registration/site-registration.js:58
"Site Title" => array( null, __("Site Title", "forminator"), ), // src/form/components/registration/site-registration.js:79
"Site Role" => array( null, __("Site Role", "forminator"), ), // src/form/components/registration/site-registration.js:94
"User Meta Mapping" => array( null, __("User Meta Mapping", "forminator"), ), // src/form/components/registration/meta-mapping.js:90
"Assign your form fields to the user meta keys to use the data collected from the visitor to create a user profile." => array( null, __("Assign your form fields to the user meta keys to use the data collected from the visitor to create a user profile.", "forminator"), ), // src/form/components/registration/meta-mapping.js:92
"Default Meta Keys" => array( null, __("Default Meta Keys", "forminator"), ), // src/form/components/registration/meta-mapping.js:101
"Assign form fields to the default WordPress user meta keys (used in Profiles) below. You can assign a form field to multiple meta keys. If you assign a non-required form field to a required user meta, that form field will automatically become required in your form." => array( null, __("Assign form fields to the default WordPress user meta keys (used in Profiles) below. You can assign a form field to multiple meta keys. If you assign a non-required form field to a required user meta, that form field will automatically become required in your form.", "forminator"), ), // src/form/components/registration/meta-mapping.js:107
"Username" => array( null, __("Username", "forminator"), ), // src/form/components/registration/meta-mapping.js:119
"Select a field" => array( null, __("Select a field", "forminator"), ), // src/form/components/registration/meta-mapping.js:124
"Website" => array( null, __("Website", "forminator"), ), // src/form/components/registration/meta-mapping.js:179
"Password" => array( null, __("Password", "forminator"), ), // src/form/components/registration/meta-mapping.js:193
"Auto Generated Password" => array( null, __("Auto Generated Password", "forminator"), ), // src/form/components/registration/meta-mapping.js:204
"This form includes a {{strong}}Password field{{/strong}}. Since user passwords will be {{strong}}automatically generated{{/strong}}, the {{strong}}Password field{{/strong}} should be deleted." => array( null, __("This form includes a {{strong}}Password field{{/strong}}. Since user passwords will be {{strong}}automatically generated{{/strong}}, the {{strong}}Password field{{/strong}} should be deleted.", "forminator"), ), // src/form/components/registration/meta-mapping.js:223
"This form is set to {{strong}}automatically generate{{/strong}} user passwords. To allow users to set their own passwords, insert a {{strong}}Password field{{/strong}} into {{link}}this form{{/link}}." => array( null, __("This form is set to {{strong}}automatically generate{{/strong}} user passwords. To allow users to set their own passwords, insert a {{strong}}Password field{{/strong}} into {{link}}this form{{/link}}.", "forminator"), ), // src/form/components/registration/meta-mapping.js:255
"Choose which user role you want to assign to the visitors signing up. You can either assign a fixed user role to all of them or assign a user role conditionally, based on their response to the form fields." => array( null, __("Choose which user role you want to assign to the visitors signing up. You can either assign a fixed user role to all of them or assign a user role conditionally, based on their response to the form fields.", "forminator"), ), // src/form/components/registration/meta-mapping.js:294
"Fixed Role to All" => array( null, __("Fixed Role to All", "forminator"), ), // src/form/components/registration/meta-mapping.js:302
"Assign Role Conditionally" => array( null, __("Assign Role Conditionally", "forminator"), ), // src/form/components/registration/meta-mapping.js:305
"Caution" => array( null, __("Caution", "forminator"), ), // src/form/components/registration/meta-mapping.js:324
"Granting the Administrator role gives users complete access to your site. Please assign this role carefully to prevent unauthorized access." => array( null, __("Granting the Administrator role gives users complete access to your site. Please assign this role carefully to prevent unauthorized access.", "forminator"), ), // src/form/components/registration/meta-mapping.js:326
"No custom user meta created yet. Click on \"+ Add Custom User Meta\" to create custom user meta and map form fields to it." => array( null, __("No custom user meta created yet. Click on \"+ Add Custom User Meta\" to create custom user meta and map form fields to it.", "forminator"), ), // src/form/components/registration/meta-mapping.js:365
"Custom User Meta" => array( null, __("Custom User Meta", "forminator"), ), // src/form/components/registration/meta-mapping.js:376
"Create custom user meta keys and assign your form fields to them to set additional user meta keys upon successful user registration." => array( null, __("Create custom user meta keys and assign your form fields to them to set additional user meta keys upon successful user registration.", "forminator"), ), // src/form/components/registration/meta-mapping.js:379
"Additional Settings" => array( null, __("Additional Settings", "forminator"), ), // src/form/components/registration/additional-settings.js:21
"These settings will add some extra control on your registration process." => array( null, __("These settings will add some extra control on your registration process.", "forminator"), ), // src/form/components/registration/additional-settings.js:25
"Automatically log in newly activated users" => array( null, __("Automatically log in newly activated users", "forminator"), ), // src/form/components/registration/additional-settings.js:35
"This will automatically log in a user upon successful activation of their account." => array( null, __("This will automatically log in a user upon successful activation of their account.", "forminator"), ), // src/form/components/registration/additional-settings.js:36
"Hide the form if a user is already logged in" => array( null, __("Hide the form if a user is already logged in", "forminator"), ), // src/form/components/registration/additional-settings.js:41
"Enabling this will hide the form from logged-in users." => array( null, __("Enabling this will hide the form from logged-in users.", "forminator"), ), // src/form/components/registration/additional-settings.js:42
"Message (optional)" => array( null, __("Message (optional)", "forminator"), ), // src/form/components/registration/additional-settings.js:52
"Type a message for logged in users here…" => array( null, __("Type a message for logged in users here…", "forminator"), ), // src/form/components/registration/additional-settings.js:55
"You can optionally add a message for logged in users, which appears when the form is hidden." => array( null, __("You can optionally add a message for logged in users, which appears when the form is hidden.", "forminator"), ), // src/form/components/registration/additional-settings.js:57
"User Account Activation" => array( null, __("User Account Activation", "forminator"), ), // src/form/components/registration/account-activation.js:23
"Choose the activation method and other settings for the user accounts." => array( null, __("Choose the activation method and other settings for the user accounts.", "forminator"), ), // src/form/components/registration/account-activation.js:27
"Activation Method" => array( null, __("Activation Method", "forminator"), ), // src/form/components/registration/account-activation.js:36
"By default, the user account is activated upon form submission. However, you can choose between {{strong}}Email Activation{{/strong}}, which requires the user to click on an activation email, or {{strong}}Manual Approval{{/strong}} which requires site admin to approve an account." => array( null, __("By default, the user account is activated upon form submission. However, you can choose between {{strong}}Email Activation{{/strong}}, which requires the user to click on an activation email, or {{strong}}Manual Approval{{/strong}} which requires site admin to approve an account.", "forminator"), ), // src/form/components/registration/account-activation.js:39
"Email Activation" => array( null, __("Email Activation", "forminator"), ), // src/form/components/registration/account-activation.js:55
"Confirmation Page" => array( null, __("Confirmation Page", "forminator"), ), // src/form/components/registration/account-activation.js:61
"Choose the page to redirect users to when they click on the confirmation link." => array( null, __("Choose the page to redirect users to when they click on the confirmation link.", "forminator"), ), // src/form/components/registration/account-activation.js:64
"page ID: " => array( null, __("page ID: ", "forminator"), ), // src/form/components/registration/account-activation.js:69
"Manual Approval" => array( null, __("Manual Approval", "forminator"), ), // src/form/components/registration/account-activation.js:74
"A site admin will have to manually approve each entry from the submissions page to activate the user accounts." => array( null, __("A site admin will have to manually approve each entry from the submissions page to activate the user accounts.", "forminator"), ), // src/form/components/registration/account-activation.js:90
"Activation Email" => array( null, __("Activation Email", "forminator"), ), // src/form/components/registration/account-activation.js:107
"By default, WordPress sends an activation email containing user account information after the account activation. However, you can choose not to send this email." => array( null, __("By default, WordPress sends an activation email containing user account information after the account activation. However, you can choose not to send this email.", "forminator"), ), // src/form/components/registration/account-activation.js:110
"Since the {{strong}}Password{{/strong}} user meta key is mapped to {{strong}}Auto Generate Password{{/strong}}, it's recommended to keep this option to {{strong}}Default{{/strong}} so the auto-generated password can be sent to the users." => array( null, __("Since the {{strong}}Password{{/strong}} user meta key is mapped to {{strong}}Auto Generate Password{{/strong}}, it's recommended to keep this option to {{strong}}Default{{/strong}} so the auto-generated password can be sent to the users.", "forminator"), ), // src/form/components/registration/account-activation.js:133
"Since the activation requires manual approval from site admin, it's recommended to keep this option to {{strong}}Default{{/strong}} to let users know when their account is activated." => array( null, __("Since the activation requires manual approval from site admin, it's recommended to keep this option to {{strong}}Default{{/strong}} to let users know when their account is activated.", "forminator"), ), // src/form/components/registration/account-activation.js:163
"The {{b}}Forminator PDF Generator Add-on{{/b}} is required to use the PDF generator feature. Install it from the Add-ons page." => array( null, __("The {{b}}Forminator PDF Generator Add-on{{/b}} is required to use the PDF generator feature. Install it from the Add-ons page.", "forminator"), ), // src/form/components/pdf/view-addons.js:23
"Get the Add-on" => array( null, __("Get the Add-on", "forminator"), ), // src/form/components/pdf/view-addons.js:42
"Preview this PDF" => array( null, __("Preview this PDF", "forminator"), ), // src/form/components/pdf/pdf-table.js:62
"Edit PDF File" => array( null, __("Edit PDF File", "forminator"), ), // src/form/components/pdf/pdf-table.js:73
"Delete PDF File" => array( null, __("Delete PDF File", "forminator"), ), // src/form/components/pdf/pdf-table.js:84
"You haven't created any PDF files yet. When you do, you'll be able to view them all here." => array( null, __("You haven't created any PDF files yet. When you do, you'll be able to view them all here.", "forminator"), ), // src/form/components/pdf/no-pdf.js:26
"Manage PDF files" => array( null, __("Manage PDF files", "forminator"), ), // src/form/components/pdf/manage-pdfs.js:33
"Create one or more PDF file templates that will be generated and populated with user data on form submissions. " => array( null, __("Create one or more PDF file templates that will be generated and populated with user data on form submissions. ", "forminator"), ), // src/form/components/pdf/manage-pdfs.js:36
"Available PDF files" => array( null, __("Available PDF files", "forminator"), ), // src/form/components/pdf/manage-pdfs.js:45
"{{b}}Forminator PDF Generator Add-on{{/b}} requires the following modules ({{b}}mbstring{{/b}} and {{b}}gd{{/b}}). Please contact your hosting provider to enable the extensions." => array( null, __("{{b}}Forminator PDF Generator Add-on{{/b}} requires the following modules ({{b}}mbstring{{/b}} and {{b}}gd{{/b}}). Please contact your hosting provider to enable the extensions.", "forminator"), ), // src/form/components/pdf/manage-pdfs.js:67
"Create New PDF" => array( null, __("Create New PDF", "forminator"), ), // src/form/components/pdf/create-pdf.js:136
"You have unsaved changes" => array( null, __("You have unsaved changes", "forminator"), ), // src/form/components/pdf/slides/unsaved-changes.js:153
"Your form contains unsaved changes. Please save your form before proceeding." => array( null, __("Your form contains unsaved changes. Please save your form before proceeding.", "forminator"), ), // src/form/components/pdf/slides/unsaved-changes.js:157
"Save and Continue" => array( null, __("Save and Continue", "forminator"), ), // src/form/components/pdf/slides/unsaved-changes.js:174
"Payee and Payer Details" => array( null, __("Payee and Payer Details", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:90
"Enter the payee and payer details for your receipt. You can insert merge tags or manually enter the details below. The details can later be changed in the PDF editor." => array( null, __("Enter the payee and payer details for your receipt. You can insert merge tags or manually enter the details below. The details can later be changed in the PDF editor.", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:93
"Payee details" => array( null, __("Payee details", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:103
"Site Information" => array( null, __("Site Information", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:124
"Insert dynamic data" => array( null, __("Insert dynamic data", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:132
"Add dynamic data" => array( null, __("Add dynamic data", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:133
"Company:" => array( null, __("Company:", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:135
"Address:" => array( null, __("Address:", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:136
"Invoice No:" => array( null, __("Invoice No:", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:137
"Payer details" => array( null, __("Payer details", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:143
"Name / Company:" => array( null, __("Name / Company:", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:171
"Email:" => array( null, __("Email:", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:173
"Date:" => array( null, __("Date:", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:174
"Payment note or other instructions (Optional)" => array( null, __("Payment note or other instructions (Optional)", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:180
"Create" => array( null, __("Create", "forminator"), ), // src/form/components/pdf/slides/receipt-info.js:223
"Preload form fields in PDF file" => array( null, __("Preload form fields in PDF file", "forminator"), ), // src/form/components/pdf/slides/preload-content.js:35
"Start with a blank PDF file" => array( null, __("Start with a blank PDF file", "forminator"), ), // src/form/components/pdf/slides/preload-content.js:39
"Preload PDF Content" => array( null, __("Preload PDF Content", "forminator"), ), // src/form/components/pdf/slides/preload-content.js:57
"Choose if you want to load form data into your PDF file or start with a blank PDF file." => array( null, __("Choose if you want to load form data into your PDF file or start with a blank PDF file.", "forminator"), ), // src/form/components/pdf/slides/preload-content.js:60
"Something went wrong while creating your PDF. Please try again." => array( null, __("Something went wrong while creating your PDF. Please try again.", "forminator"), ), // src/form/components/pdf/slides/loading.js:64
"Hold tight a few moments while we create your PDF file." => array( null, __("Hold tight a few moments while we create your PDF file.", "forminator"), ), // src/form/components/pdf/slides/loading.js:92
"Enter PDF filename" => array( null, __("Enter PDF filename", "forminator"), ), // src/form/components/pdf/slides/filename.js:73
"Give your file a name so you can identify it later." => array( null, __("Give your file a name so you can identify it later.", "forminator"), ), // src/form/components/pdf/slides/filename.js:76
"PDF File Created!" => array( null, __("PDF File Created!", "forminator"), ), // src/form/components/pdf/slides/file-created.js:65
"The PDF file has been created. Click “Edit PDF” to customize the created PDF or “Continue” to continue building your form." => array( null, __("The PDF file has been created. Click “Edit PDF” to customize the created PDF or “Continue” to continue building your form.", "forminator"), ), // src/form/components/pdf/slides/file-created.js:69
"Edit PDF" => array( null, __("Edit PDF", "forminator"), ), // src/form/components/pdf/slides/file-created.js:81
"Continue" => array( null, __("Continue", "forminator"), ), // src/form/components/pdf/slides/file-created.js:88
"Choose a template" => array( null, __("Choose a template", "forminator"), ), // src/form/components/pdf/slides/choose-template.js:81
"Select a template below to get started." => array( null, __("Select a template below to get started.", "forminator"), ), // src/form/components/pdf/slides/choose-template.js:84
"Coming Soon" => array( null, __("Coming Soon", "forminator"), ), // src/form/components/pdf/slides/choose-template.js:115
"Receipt template requires at least one payment field. Please add a PayPal or Stripe field to your form to proceed or choose a different template." => array( null, __("Receipt template requires at least one payment field. Please add a PayPal or Stripe field to your form to proceed or choose a different template.", "forminator"), ), // src/form/components/pdf/slides/choose-template.js:149
"Confirmation Email" => array( null, __("Confirmation Email", "forminator"), ), // src/form/components/notifications/confirmation-email.js:303
"In addition to notifying people of new submissions, you can also send a confirmation email to the user who submitted the form." => array( null, __("In addition to notifying people of new submissions, you can also send a confirmation email to the user who submitted the form.", "forminator"), ), // src/form/components/notifications/confirmation-email.js:307
"Send a confirmation email to the user" => array( null, __("Send a confirmation email to the user", "forminator"), ), // src/form/components/notifications/confirmation-email.js:318
"If you leave it blank, we will automatically find first email field in the form as recipient. If there is no email field and user is logged in we will use their email." => array( null, __("If you leave it blank, we will automatically find first email field in the form as recipient. If there is no email field and user is logged in we will use their email.", "forminator"), ), // src/form/components/notifications/confirmation-email.js:364
"By default we’ll send an email to the nominated email account. You customize this email or turn it off all together." => array( null, __("By default we’ll send an email to the nominated email account. You customize this email or turn it off all together.", "forminator"), ), // src/form/components/notifications/admin-email.js:307
"Form Fields" => array( null, __("Form Fields", "forminator"), ), // src/form/components/navigation/menu.js:39
"User Login" => array( null, __("User Login", "forminator"), ), // src/form/components/navigation/menu.js:88
"You can configure email notifications on the parent quiz as it is shared between this form and the parent quiz." => array( null, __("You can configure email notifications on the parent quiz as it is shared between this form and the parent quiz.", "forminator"), ), // src/form/components/navigation/menu.js:147
"You can configure integrations on the parent quiz as it is shared between this form and the parent quiz." => array( null, __("You can configure integrations on the parent quiz as it is shared between this form and the parent quiz.", "forminator"), ), // src/form/components/navigation/menu.js:193
"Customize Submit Button" => array( null, __("Customize Submit Button", "forminator"), ), // src/form/components/modals/submit.js:54
"Field Labels" => array( null, __("Field Labels", "forminator"), ), // src/form/components/modals/submit.js:70
"Visibility" => array( null, __("Visibility", "forminator"), ), // src/form/components/modals/submit.js:79
"Styling" => array( null, __("Styling", "forminator"), ), // src/form/components/modals/submit.js:88
"Button text" => array( null, __("Button text", "forminator"), ), // src/form/components/modals/submit.js:115
"Your form is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!" => array( null, __("Your form is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!", "forminator"), ), // src/form/components/modals/shortcode.js:52
"Copy shortcode" => array( null, __("Copy shortcode", "forminator"), ), // src/form/components/modals/shortcode.js:90
"At least one field must be enabled" => array( null, __("At least one field must be enabled", "forminator"), ), // src/form/components/modals/settings.js:151
"Please fill required fields" => array( null, __("Please fill required fields", "forminator"), ), // src/form/components/modals/settings.js:157
"Calculation values are required!" => array( null, __("Calculation values are required!", "forminator"), ), // src/form/components/modals/settings.js:175
"Option labels are required!" => array( null, __("Option labels are required!", "forminator"), ), // src/form/components/modals/settings.js:184
"Add one or more options to add this field." => array( null, __("Add one or more options to add this field.", "forminator"), ), // src/form/components/modals/settings.js:192
"Please add a placeholder or select a default option." => array( null, __("Please add a placeholder or select a default option.", "forminator"), ), // src/form/components/modals/settings.js:206
"At least one of Title, Content, or Excerpt must be enabled for post data to be submitted." => array( null, __("At least one of Title, Content, or Excerpt must be enabled for post data to be submitted.", "forminator"), ), // src/form/components/modals/settings.js:216
"Please, connect your Stripe account first!" => array( null, __("Please, connect your Stripe account first!", "forminator"), ), // src/form/components/modals/settings.js:224
"You need at least one payment plan!" => array( null, __("You need at least one payment plan!", "forminator"), ), // src/form/components/modals/settings.js:229
"Please select an email address for payment receipt." => array( null, __("Please select an email address for payment receipt.", "forminator"), ), // src/form/components/modals/settings.js:235
"Empty labels are not allowed for meta values!" => array( null, __("Empty labels are not allowed for meta values!", "forminator"), ), // src/form/components/modals/settings.js:246
"Please connect your PayPal account first!" => array( null, __("Please connect your PayPal account first!", "forminator"), ), // src/form/components/modals/settings.js:258
"Please enter PayPal payment amount!" => array( null, __("Please enter PayPal payment amount!", "forminator"), ), // src/form/components/modals/settings.js:263
"Please select PayPal payment variable field!" => array( null, __("Please select PayPal payment variable field!", "forminator"), ), // src/form/components/modals/settings.js:269
"Limit Min value should be less than Max value." => array( null, __("Limit Min value should be less than Max value.", "forminator"), ), // src/form/components/modals/settings.js:287
"Please enter API keys." => array( null, __("Please enter API keys.", "forminator"), ), // src/form/components/modals/settings.js:309
"Please select a valid end time limit." => array( null, __("Please select a valid end time limit.", "forminator"), ), // src/form/components/modals/settings.js:408
"Please fix the Default time error." => array( null, __("Please fix the Default time error.", "forminator"), ), // src/form/components/modals/settings.js:414
"Please fix the Start or End time." => array( null, __("Please fix the Start or End time.", "forminator"), ), // src/form/components/modals/settings.js:428
"Please fix the limit Start or End date." => array( null, __("Please fix the limit Start or End date.", "forminator"), ), // src/form/components/modals/settings.js:566
"Maximum Rating value should be less than 50." => array( null, __("Maximum Rating value should be less than 50.", "forminator"), ), // src/form/components/modals/settings.js:577
"Customize %s" => array( null, __("Customize %s", "forminator"), ), // src/form/components/modals/settings.js:654
"Customize %s Field" => array( null, __("Customize %s Field", "forminator"), ), // src/form/components/modals/settings.js:655
"Customize Page Visibility" => array( null, __("Customize Page Visibility", "forminator"), ), // src/form/components/modals/settings.js:659
"Geolocation" => array( null, __("Geolocation", "forminator"), ), // src/form/components/modals/settings.js:717
"Geolocation {{span}}Pro{{/span}}" => array( null, __("Geolocation {{span}}Pro{{/span}}", "forminator"), ), // src/form/components/modals/settings.js:719
"Products/Plans" => array( null, __("Products/Plans", "forminator"), ), // src/form/components/modals/settings.js:746
"Repeater" => array( null, __("Repeater", "forminator"), ), // src/form/components/modals/settings.js:766
"Limits" => array( null, __("Limits", "forminator"), ), // src/form/components/modals/settings.js:780
"Customize" => array( null, __("Customize", "forminator"), ), // src/form/components/modals/settings.js:832
"Something went wrong while saving your template. Please try again." => array( null, __("Something went wrong while saving your template. Please try again.", "forminator"), ), // src/form/components/modals/save-template.js:147
"Save Template" => array( null, __("Save Template", "forminator"), ), // src/form/components/modals/save-template.js:199
"Enter a name to save this form as a template or select an existing template to overwrite." => array( null, __("Enter a name to save this form as a template or select an existing template to overwrite.", "forminator"), ), // src/form/components/modals/save-template.js:204
"New Template" => array( null, __("New Template", "forminator"), ), // src/form/components/modals/save-template.js:219
"Name" => array( null, __("Name", "forminator"), ), // src/form/components/modals/save-template.js:223
"E.g., Registration form template" => array( null, __("E.g., Registration form template", "forminator"), ), // src/form/components/modals/save-template.js:224
"Update Existing Template" => array( null, __("Update Existing Template", "forminator"), ), // src/form/components/modals/save-template.js:232
"Choose template" => array( null, __("Choose template", "forminator"), ), // src/form/components/modals/save-template.js:235
"Select a template" => array( null, __("Select a template", "forminator"), ), // src/form/components/modals/save-template.js:242
"Searching…" => array( null, __("Searching…", "forminator"), ), // src/form/components/modals/save-template.js:245
"Load more" => array( null, __("Load more", "forminator"), ), // src/form/components/modals/save-template.js:258
"Warning! The selected template will be overwritten by this form." => array( null, __("Warning! The selected template will be overwritten by this form.", "forminator"), ), // src/form/components/modals/save-template.js:279
"Template Saved" => array( null, __("Template Saved", "forminator"), ), // src/form/components/modals/save-template-success.js:36
"Template successfully saved to your Hub account. You can access the saved template in the " => array( null, __("Template successfully saved to your Hub account. You can access the saved template in the ", "forminator"), ), // src/form/components/modals/save-template-success.js:41
"Templates Page." => array( null, __("Templates Page.", "forminator"), ), // src/form/components/modals/save-template-success.js:43
"Publishing form…" => array( null, __("Publishing form…", "forminator"), ), // src/form/components/modals/publish.js:30
"Disable validations" => array( null, __("Disable validations", "forminator"), ), // src/form/components/modals/preview.js:81
"Note:" => array( null, __("Note:", "forminator"), ), // src/form/components/modals/preview.js:145
"The form preview doesn't reflect your theme's styles. For the most accurate view, check the form on the actual page or post." => array( null, __("The form preview doesn't reflect your theme's styles. For the most accurate view, check the form on the actual page or post.", "forminator"), ), // src/form/components/modals/preview.js:145
"Customize Pagination Field" => array( null, __("Customize Pagination Field", "forminator"), ), // src/form/components/modals/pagination.js:67
"Your form is divided into multiple pages by Page Break field(s), and you can customize the label of each page here. Page names appear on your form header along with the progress indicator." => array( null, __("Your form is divided into multiple pages by Page Break field(s), and you can customize the label of each page here. Page names appear on your form header along with the progress indicator.", "forminator"), ), // src/form/components/modals/pagination.js:114
"Finish" => array( null, __("Finish", "forminator"), ), // src/form/components/modals/pagination.js:169
"Progress Indicator" => array( null, __("Progress Indicator", "forminator"), ), // src/form/components/modals/pagination.js:197
"Choose whether to show a progress indicator on top of your form, so your users know how far they are through your form." => array( null, __("Choose whether to show a progress indicator on top of your form, so your users know how far they are through your form.", "forminator"), ), // src/form/components/modals/pagination.js:201
"Steps" => array( null, __("Steps", "forminator"), ), // src/form/components/modals/pagination.js:239
"Progress Bar" => array( null, __("Progress Bar", "forminator"), ), // src/form/components/modals/pagination.js:249
"Progress type" => array( null, __("Progress type", "forminator"), ), // src/form/components/modals/pagination.js:258
"Choose how to display progress: as a percentage (e.g., 60%) or by page number (e.g., Page 2 of 5)." => array( null, __("Choose how to display progress: as a percentage (e.g., 60%) or by page number (e.g., Page 2 of 5).", "forminator"), ), // src/form/components/modals/pagination.js:266
"Progress" => array( null, __("Progress", "forminator"), ), // src/form/components/modals/pagination.js:278
"Page number" => array( null, __("Page number", "forminator"), ), // src/form/components/modals/pagination.js:279
"Buttons Text" => array( null, __("Buttons Text", "forminator"), ), // src/form/components/modals/pagination.js:298
"Choose whether you want to use default text for the Previous and Next button or use custom text." => array( null, __("Choose whether you want to use default text for the Previous and Next button or use custom text.", "forminator"), ), // src/form/components/modals/pagination.js:302
"Customize Header Field" => array( null, __("Customize Header Field", "forminator"), ), // src/form/components/modals/page-header.js:147
"Logo Type" => array( null, __("Logo Type", "forminator"), ), // src/form/components/modals/page-header.js:218
"Logo Text" => array( null, __("Logo Text", "forminator"), ), // src/form/components/modals/page-header.js:247
"Logo image source" => array( null, __("Logo image source", "forminator"), ), // src/form/components/modals/page-header.js:285
"Use site logo" => array( null, __("Use site logo", "forminator"), ), // src/form/components/modals/page-header.js:301
"Your site’s logo will be used as the logo for this PDF file." => array( null, __("Your site’s logo will be used as the logo for this PDF file.", "forminator"), ), // src/form/components/modals/page-header.js:323
"Your site doesn’t have any logo image set. You can set a site logo or upload a new logo for your PDF file." => array( null, __("Your site doesn’t have any logo image set. You can set a site logo or upload a new logo for your PDF file.", "forminator"), ), // src/form/components/modals/page-header.js:350
"Use logo image" => array( null, __("Use logo image", "forminator"), ), // src/form/components/modals/page-header.js:363
"Upload Image" => array( null, __("Upload Image", "forminator"), ), // src/form/components/modals/page-header.js:382
"Supported formats (.png, .gif, .jpg, and .svg). For best output, please upload an image with a height of 80px." => array( null, __("Supported formats (.png, .gif, .jpg, and .svg). For best output, please upload an image with a height of 80px.", "forminator"), ), // src/form/components/modals/page-header.js:385
"Logo URL" => array( null, __("Logo URL", "forminator"), ), // src/form/components/modals/page-header.js:392
"Image URL" => array( null, __("Image URL", "forminator"), ), // src/form/components/modals/page-header.js:409
"E.g. https://domain.com/images/logo.png" => array( null, __("E.g. https://domain.com/images/logo.png", "forminator"), ), // src/form/components/modals/page-header.js:412
"Please enter the image URL for the logo." => array( null, __("Please enter the image URL for the logo.", "forminator"), ), // src/form/components/modals/page-header.js:415
"For best output, image height is constrained to 80px. You can adjust this size using custom CSS." => array( null, __("For best output, image height is constrained to 80px. You can adjust this size using custom CSS.", "forminator"), ), // src/form/components/modals/page-header.js:418
"Title alignment" => array( null, __("Title alignment", "forminator"), ), // src/form/components/modals/page-header.js:476
"Customize Footer Field" => array( null, __("Customize Footer Field", "forminator"), ), // src/form/components/modals/page-footer.js:86
"Show page number" => array( null, __("Show page number", "forminator"), ), // src/form/components/modals/page-footer.js:179
"(Separate multiple emails with a comma)" => array( null, __("(Separate multiple emails with a comma)", "forminator"), ), // src/form/components/modals/notification.js:620
"Some hosts do not allow \"from email\" to be overridden or replaced due to spam issues." => array( null, __("Some hosts do not allow \"from email\" to be overridden or replaced due to spam issues.", "forminator"), ), // src/form/components/modals/notification.js:793
"Collect payments like a pro" => array( null, __("Collect payments like a pro", "forminator"), ), // src/form/components/modals/fields.js:201
"You have added both Stripe and PayPal fields to your form. We recommend that you use the visibility conditions, so only one of them is visible at a time. For example:" => array( null, __("You have added both Stripe and PayPal fields to your form. We recommend that you use the visibility conditions, so only one of them is visible at a time. For example:", "forminator"), ), // src/form/components/modals/fields.js:203
"Add an option to your form using a Radio (or Select) field that allows visitors to choose the payment method." => array( null, __("Add an option to your form using a Radio (or Select) field that allows visitors to choose the payment method.", "forminator"), ), // src/form/components/modals/fields.js:208
"Apply visibility conditions to both Stripe and PayPal fields so only one is visible based on the visitor's selection in the Radio (or Select) field." => array( null, __("Apply visibility conditions to both Stripe and PayPal fields so only one is visible based on the visitor's selection in the Radio (or Select) field.", "forminator"), ), // src/form/components/modals/fields.js:212
"PDF file" => array( null, __("PDF file", "forminator"), ), // src/form/components/modals/fields.js:274
"form" => array( null, __("form", "forminator"), ), // src/form/components/modals/fields.js:277
"Insert Fields" => array( null, __("Insert Fields", "forminator"), ), // src/form/components/modals/fields.js:291
"Select one or more fields below to include in your %s." => array( null, __("Select one or more fields below to include in your %s.", "forminator"), ), // src/form/components/modals/fields.js:299
"You can have only one Stripe field in your form for Stripe to work accurately. Please delete the existing Stripe field to add a new one." => array( null, __("You can have only one Stripe field in your form for Stripe to work accurately. Please delete the existing Stripe field to add a new one.", "forminator"), ), // src/form/components/modals/fields.js:324
"You can have only one PayPal field in your form for PayPal to work accurately. Please delete the existing PayPal field to add a new one." => array( null, __("You can have only one PayPal field in your form for PayPal to work accurately. Please delete the existing PayPal field to add a new one.", "forminator"), ), // src/form/components/modals/fields.js:335
"You can have only one captcha field in your form for captcha to work accurately. Please delete the existing captcha field to add a new one." => array( null, __("You can have only one captcha field in your form for captcha to work accurately. Please delete the existing captcha field to add a new one.", "forminator"), ), // src/form/components/modals/fields.js:346
"{{b}}Note{{/b}}: You can use the {{b}}Rich Text{{/b}} field to add form fields and custom text to your PDF." => array( null, __("{{b}}Note{{/b}}: You can use the {{b}}Rich Text{{/b}} field to add form fields and custom text to your PDF.", "forminator"), ), // src/form/components/modals/fields.js:357
"E-Signature" => array( null, __("E-Signature", "forminator"), ), // src/form/components/modals/fields.js:438
"Quotation" => array( null, __("Quotation", "forminator"), ), // src/form/components/modals/fields.js:457
"Need access to pro form fields? {{link}}Upgrade to Pro{{/link}}" => array( null, __("Need access to pro form fields? {{link}}Upgrade to Pro{{/link}}", "forminator"), ), // src/form/components/modals/fields.js:487
"Dismiss" => array( null, __("Dismiss", "forminator"), ), // src/form/components/modals/fields.js:508
"This PDF is linked to a form without a payment field. To include payment information in your PDF, please add either a PayPal or Stripe field to your form." => array( null, __("This PDF is linked to a form without a payment field. To include payment information in your PDF, please add either a PayPal or Stripe field to your form.", "forminator"), ), // src/form/components/modals/fields.js:535
"Delete Field Group" => array( null, __("Delete Field Group", "forminator"), ), // src/form/components/modals/delete.js:165
"Delete Field" => array( null, __("Delete Field", "forminator"), ), // src/form/components/modals/delete.js:165
"Are you sure you want to delete this group and all the fields it contains?" => array( null, __("Are you sure you want to delete this group and all the fields it contains?", "forminator"), ), // src/form/components/modals/delete.js:167
"Deleting this field {%(name)s} will also remove associated values from existing submissions." => array( null, __("Deleting this field {%(name)s} will also remove associated values from existing submissions.", "forminator"), ), // src/form/components/modals/delete.js:169
"Note that this field is mapped in {{link}}Default Meta Keys{{/link}}. If deleted, you will need to remap meta keys {{link}}here{{/link}}." => array( null, __("Note that this field is mapped in {{link}}Default Meta Keys{{/link}}. If deleted, you will need to remap meta keys {{link}}here{{/link}}.", "forminator"), ), // src/form/components/modals/delete.js:205
"Edit Field" => array( null, __("Edit Field", "forminator"), ), // src/form/components/modals/delete.js:267
"Please remove the references to this field from the following form fields first." => array( null, __("Please remove the references to this field from the following form fields first.", "forminator"), ), // src/form/components/modals/delete.js:295
"PDF file successfully deleted." => array( null, __("PDF file successfully deleted.", "forminator"), ), // src/form/components/modals/delete-pdf.js:37
"Are you sure you wish to delete" => array( null, __("Are you sure you wish to delete", "forminator"), ), // src/form/components/modals/delete-pdf.js:102
"Clear Color Customization?" => array( null, __("Clear Color Customization?", "forminator"), ), // src/form/components/modals/clear-color-customization.js:307
"Are you sure you want to clear your form's color customization? All customized color options will be lost." => array( null, __("Are you sure you want to clear your form's color customization? All customized color options will be lost.", "forminator"), ), // src/form/components/modals/clear-color-customization.js:314
"Proceed" => array( null, __("Proceed", "forminator"), ), // src/form/components/modals/clear-color-customization.js:335
"After Submission" => array( null, __("After Submission", "forminator"), ), // src/form/components/modals/behavior.js:109
"Only used to identify this behavior, and not displayed to users." => array( null, __("Only used to identify this behavior, and not displayed to users.", "forminator"), ), // src/form/components/modals/behavior.js:178
"E.g., Inline Message" => array( null, __("E.g., Inline Message", "forminator"), ), // src/form/components/modals/behavior.js:181
"Success message editor" => array( null, __("Success message editor", "forminator"), ), // src/form/components/modals/behavior.js:208
"Display an inline success message to the user after the form is submitted." => array( null, __("Display an inline success message to the user after the form is submitted.", "forminator"), ), // src/form/components/modals/behavior.js:209
"Enable auto-close after success message" => array( null, __("Enable auto-close after success message", "forminator"), ), // src/form/components/modals/behavior.js:232
"Auto-close success message after" => array( null, __("Auto-close success message after", "forminator"), ), // src/form/components/modals/behavior.js:240
"E.g. 5" => array( null, __("E.g. 5", "forminator"), ), // src/form/components/modals/behavior.js:248
"Seconds for auto-close" => array( null, __("Seconds for auto-close", "forminator"), ), // src/form/components/modals/behavior.js:252
"seconds." => array( null, __("seconds.", "forminator"), ), // src/form/components/modals/behavior.js:258
"https://www.mywebsite.com" => array( null, __("https://www.mywebsite.com", "forminator"), ), // src/form/components/modals/behavior.js:274
"Redirect URL" => array( null, __("Redirect URL", "forminator"), ), // src/form/components/modals/behavior.js:278
"Provide the absolute URL of the page you want to redirect users to after submitting the login form. For example, to redirect users to the WordPress admin, use the URL  {{strong}}http://www.website.com/wp-admin/{{/strong}}." => array( null, __("Provide the absolute URL of the page you want to redirect users to after submitting the login form. For example, to redirect users to the WordPress admin, use the URL  {{strong}}http://www.website.com/wp-admin/{{/strong}}.", "forminator"), ), // src/form/components/modals/behavior.js:282
"Redirection Option" => array( null, __("Redirection Option", "forminator"), ), // src/form/components/modals/behavior.js:310
"Redirect on the same tab" => array( null, __("Redirect on the same tab", "forminator"), ), // src/form/components/modals/behavior.js:313
"Redirect on new tab and show thank you message on form page" => array( null, __("Redirect on new tab and show thank you message on form page", "forminator"), ), // src/form/components/modals/behavior.js:314
"Redirect on new tab and hide form on the form page" => array( null, __("Redirect on new tab and hide form on the form page", "forminator"), ), // src/form/components/modals/behavior.js:315
"Hide the form after submission, and display a success message to the user." => array( null, __("Hide the form after submission, and display a success message to the user.", "forminator"), ), // src/form/components/modals/behavior.js:334
"Submit Message" => array( null, __("Submit Message", "forminator"), ), // src/form/components/modals/behavior.js:338
"Appearance preset successfully applied." => array( null, __("Appearance preset successfully applied.", "forminator"), ), // src/form/components/modals/apply-preset.js:45
"Apply Appearance preset?" => array( null, __("Apply Appearance preset?", "forminator"), ), // src/form/components/modals/apply-preset.js:84
"Are you sure you want to apply the selected preset to your form? Your current appearance configurations will be overwritten." => array( null, __("Are you sure you want to apply the selected preset to your form? Your current appearance configurations will be overwritten.", "forminator"), ), // src/form/components/modals/apply-preset.js:86
"Applying preset…" => array( null, __("Applying preset…", "forminator"), ), // src/form/components/modals/apply-preset.js:102
"Access PDF Generator Add-on" => array( null, __("Access PDF Generator Add-on", "forminator"), ), // src/form/components/modals/access-pdf-addon.js:46
"Create an account with WPMU DEV (the developers of Forminator) to get instant access to PDF Add-on, plus a host of bonus site management tools that come included. It’s fast, easy, and free!" => array( null, __("Create an account with WPMU DEV (the developers of Forminator) to get instant access to PDF Add-on, plus a host of bonus site management tools that come included. It’s fast, easy, and free!", "forminator"), ), // src/form/components/modals/access-pdf-addon.js:52
"Connect to WPMU DEV" => array( null, __("Connect to WPMU DEV", "forminator"), ), // src/form/components/modals/access-pdf-addon.js:71
"Already a member? {{link}}Connect site{{/link}}" => array( null, __("Already a member? {{link}}Connect site{{/link}}", "forminator"), ), // src/form/components/modals/access-pdf-addon.js:84
"Use this merge tag to dynamically include this field’s value in email notification, success messages, and other text elements." => array( null, __("Use this merge tag to dynamically include this field’s value in email notification, success messages, and other text elements.", "forminator"), ), // src/form/components/modals/partials/title.js:65
"The {{strong}}Forminator PDF Generator Add-on{{/strong}} is required to use the PDF generator feature. Install it from the Add-ons page." => array( null, __("The {{strong}}Forminator PDF Generator Add-on{{/strong}} is required to use the PDF generator feature. Install it from the Add-ons page.", "forminator"), ), // src/form/components/modals/partials/pdf-attachment.js:41
"PDF Attachments" => array( null, __("PDF Attachments", "forminator"), ), // src/form/components/modals/partials/pdf-attachment.js:97
"Select PDF file(s) to attach to this email notification." => array( null, __("Select PDF file(s) to attach to this email notification.", "forminator"), ), // src/form/components/modals/partials/pdf-attachment.js:105
"No PDF file available for this form yet. Go to the {{link}}PDF tab{{/link}} to create one." => array( null, __("No PDF file available for this form yet. Go to the {{link}}PDF tab{{/link}} to create one.", "forminator"), ), // src/form/components/modals/partials/pdf-attachment-none.js:39
"Forminator image" => array( null, __("Forminator image", "forminator"), ), // src/form/components/modals/partials/image.js:14
"Close this dialog" => array( null, __("Close this dialog", "forminator"), ), // src/form/components/modals/partials/close.js:14
"Login Fields" => array( null, __("Login Fields", "forminator"), ), // src/form/components/login/meta-mapping.js:39
"Map your form fields to the meta keys and have additional control over the login form fields." => array( null, __("Map your form fields to the meta keys and have additional control over the login form fields.", "forminator"), ), // src/form/components/login/meta-mapping.js:43
"Form Fields Mapping" => array( null, __("Form Fields Mapping", "forminator"), ), // src/form/components/login/meta-mapping.js:52
"Assign your form fields to the meta keys required to login a user." => array( null, __("Assign your form fields to the meta keys required to login a user.", "forminator"), ), // src/form/components/login/meta-mapping.js:56
"Remember Me Field" => array( null, __("Remember Me Field", "forminator"), ), // src/form/components/login/meta-mapping.js:96
"Choose whether to show the {{strong}}Remember Me{{/strong}} field in your form. This option will add a Remember Me checkbox before the submit button." => array( null, __("Choose whether to show the {{strong}}Remember Me{{/strong}} field in your form. This option will add a Remember Me checkbox before the submit button.", "forminator"), ), // src/form/components/login/meta-mapping.js:99
"Remember me" => array( null, __("Remember me", "forminator"), ), // src/form/components/login/meta-mapping.js:117
"Cookie Expiration" => array( null, __("Cookie Expiration", "forminator"), ), // src/form/components/login/meta-mapping.js:130
"Users will have to provide login details again after the selected period." => array( null, __("Users will have to provide login details again after the selected period.", "forminator"), ), // src/form/components/login/meta-mapping.js:156
"These settings will add some extra control on your login process." => array( null, __("These settings will add some extra control on your login process.", "forminator"), ), // src/form/components/login/additional-settings.js:25
"of the conditions below are met." => array( null, __("of the conditions below are met.", "forminator"), ), // src/form/components/integrations/conditions.js:157
"Use conditional logic to send data to this app based on submitted form data." => array( null, __("Use conditional logic to send data to this app based on submitted form data.", "forminator"), ), // src/form/components/integrations/conditions.js:173
"Add conditions under which data should be sent to this app." => array( null, __("Add conditions under which data should be sent to this app.", "forminator"), ), // src/form/components/integrations/conditions.js:197
"Add Condition" => array( null, __("Add Condition", "forminator"), ), // src/form/components/integrations/conditions.js:244
"Give your form a name" => array( null, __("Give your form a name", "forminator"), ), // src/form/components/header/title.js:43
"Save to Cloud" => array( null, __("Save to Cloud", "forminator"), ), // src/form/components/header/save-template.js:41
"Default Value (optional)" => array( null, __("Default Value (optional)", "forminator"), ), // src/form/components/fields/website.js:52
"Enter default value" => array( null, __("Enter default value", "forminator"), ), // src/form/components/fields/website.js:53
"Type" => array( null, __("Type", "forminator"), ), // src/form/components/fields/upload.js:52
"Single" => array( null, __("Single", "forminator"), ), // src/form/components/fields/upload.js:56
"Multiple" => array( null, __("Multiple", "forminator"), ), // src/form/components/fields/upload.js:57
"Limit number of files" => array( null, __("Limit number of files", "forminator"), ), // src/form/components/fields/upload.js:90
"Choose the maximum number of files that can be uploaded using this field." => array( null, __("Choose the maximum number of files that can be uploaded using this field.", "forminator"), ), // src/form/components/fields/upload.js:94
"Unlimited" => array( null, __("Unlimited", "forminator"), ), // src/form/components/fields/upload.js:107
"File upload limit" => array( null, __("File upload limit", "forminator"), ), // src/form/components/fields/upload.js:123
"Filesize limit per file" => array( null, __("Filesize limit per file", "forminator"), ), // src/form/components/fields/upload.js:138
"Filesize limit" => array( null, __("Filesize limit", "forminator"), ), // src/form/components/fields/upload.js:139
"We've detected your server will allow uploads up to %(maxUpload)sMB in size currently. You can set a lower limit than this using the input below, however if you want uploads of more than %(maxUpload)sMB you'll need to adjust this in your server's PHP.ini settings." => array( null, __("We've detected your server will allow uploads up to %(maxUpload)sMB in size currently. You can set a lower limit than this using the input below, however if you want uploads of more than %(maxUpload)sMB you'll need to adjust this in your server's PHP.ini settings.", "forminator"), ), // src/form/components/fields/upload.js:145
"Upload limit per file" => array( null, __("Upload limit per file", "forminator"), ), // src/form/components/fields/upload.js:162
"Select upload size unit (KB or MB)" => array( null, __("Select upload size unit (KB or MB)", "forminator"), ), // src/form/components/fields/upload.js:190
"MB" => array( null, __("MB", "forminator"), ), // src/form/components/fields/upload.js:192
"KB" => array( null, __("KB", "forminator"), ), // src/form/components/fields/upload.js:193
"B" => array( null, __("B", "forminator"), ), // src/form/components/fields/upload.js:194
"The file size you have entered exceeds what your current hosting settings are capped to. You need to increase your max filesize limit at the server level first." => array( null, __("The file size you have entered exceeds what your current hosting settings are capped to. You need to increase your max filesize limit at the server level first.", "forminator"), ), // src/form/components/fields/upload.js:221
"Upload method" => array( null, __("Upload method", "forminator"), ), // src/form/components/fields/upload.js:241
"Choose whether you want to use AJAX to upload individual files as they are selected or use the traditional method of uploading all files together on form submission. We recommend using the AJAX method to avoid server timeouts." => array( null, __("Choose whether you want to use AJAX to upload individual files as they are selected or use the traditional method of uploading all files together on form submission. We recommend using the AJAX method to avoid server timeouts.", "forminator"), ), // src/form/components/fields/upload.js:245
"AJAX" => array( null, __("AJAX", "forminator"), ), // src/form/components/fields/upload.js:259
"On form submission" => array( null, __("On form submission", "forminator"), ), // src/form/components/fields/upload.js:260
"Show files in media library" => array( null, __("Show files in media library", "forminator"), ), // src/form/components/fields/upload.js:271
"Choose whether you want to show the files uploaded by your visitors using this field in your media library." => array( null, __("Choose whether you want to show the files uploaded by your visitors using this field in your media library.", "forminator"), ), // src/form/components/fields/upload.js:275
"{{strong}}Note:{{/strong}} The query parameter's value passed in URL should match with the selected time format." => array( null, __("{{strong}}Note:{{/strong}} The query parameter's value passed in URL should match with the selected time format.", "forminator"), ), // src/form/components/fields/time.js:196
"Dropdowns" => array( null, __("Dropdowns", "forminator"), ), // src/form/components/fields/time.js:232
"Number inputs" => array( null, __("Number inputs", "forminator"), ), // src/form/components/fields/time.js:233
"Format" => array( null, __("Format", "forminator"), ), // src/form/components/fields/time.js:241
"12 hour" => array( null, __("12 hour", "forminator"), ), // src/form/components/fields/time.js:244
"24 hour" => array( null, __("24 hour", "forminator"), ), // src/form/components/fields/time.js:245
"Fields" => array( null, __("Fields", "forminator"), ), // src/form/components/fields/time.js:299
"Hours" => array( null, __("Hours", "forminator"), ), // src/form/components/fields/time.js:306
"Label (optional)" => array( null, __("Label (optional)", "forminator"), ), // src/form/components/fields/time.js:313
"Minutes" => array( null, __("Minutes", "forminator"), ), // src/form/components/fields/time.js:332
"Increments" => array( null, __("Increments", "forminator"), ), // src/form/components/fields/time.js:386
"Choose what time increments you want to use for the hour and minute timepickers." => array( null, __("Choose what time increments you want to use for the hour and minute timepickers.", "forminator"), ), // src/form/components/fields/time.js:389
"Choose a time limit for the time picker field to restrict the time selection between specific hours." => array( null, __("Choose a time limit for the time picker field to restrict the time selection between specific hours.", "forminator"), ), // src/form/components/fields/time.js:426
"Specific Hours" => array( null, __("Specific Hours", "forminator"), ), // src/form/components/fields/time.js:444
"Start Time" => array( null, __("Start Time", "forminator"), ), // src/form/components/fields/time.js:447
"AM" => array( null, __("AM", "forminator"), ), // src/form/components/fields/time.js:482
"PM" => array( null, __("PM", "forminator"), ), // src/form/components/fields/time.js:483
"End Time" => array( null, __("End Time", "forminator"), ), // src/form/components/fields/time.js:489
"This error message will be used when time entered is out of the set limits." => array( null, __("This error message will be used when time entered is out of the set limits.", "forminator"), ), // src/form/components/fields/time.js:539
"Default Time" => array( null, __("Default Time", "forminator"), ), // src/form/components/fields/time.js:552
"Use this feature to specify a default selected time." => array( null, __("Use this feature to specify a default selected time.", "forminator"), ), // src/form/components/fields/time.js:555
"Default time can't be outside the allowed time limit." => array( null, __("Default time can't be outside the allowed time limit.", "forminator"), ), // src/form/components/fields/time.js:619
"You can add new line" => array( null, __("You can add new line", "forminator"), ), // src/form/components/fields/textarea.js:48
"Rich-Text editor" => array( null, __("Rich-Text editor", "forminator"), ), // src/form/components/fields/textarea.js:76
"Enable TinyMCE editor to allow the formatted text." => array( null, __("Enable TinyMCE editor to allow the formatted text.", "forminator"), ), // src/form/components/fields/textarea.js:78
"Max characters" => array( null, __("Max characters", "forminator"), ), // src/form/components/fields/textarea.js:96
"By default the user can enter as many characters as they want. Use this setting to limit the number of characters the user can enter. Leave field blank to allow unlimited characters." => array( null, __("By default the user can enter as many characters as they want. Use this setting to limit the number of characters the user can enter. Leave field blank to allow unlimited characters.", "forminator"), ), // src/form/components/fields/textarea.js:100
"Character limit" => array( null, __("Character limit", "forminator"), ), // src/form/components/fields/textarea.js:109
"E.g. 100" => array( null, __("E.g. 100", "forminator"), ), // src/form/components/fields/textarea.js:116
"Characters" => array( null, __("Characters", "forminator"), ), // src/form/components/fields/textarea.js:125
"Words" => array( null, __("Words", "forminator"), ), // src/form/components/fields/textarea.js:126
"Default height" => array( null, __("Default height", "forminator"), ), // src/form/components/fields/textarea.js:142
"Choose the default minimum height of your textarea field." => array( null, __("Choose the default minimum height of your textarea field.", "forminator"), ), // src/form/components/fields/textarea.js:146
"px" => array( null, __("px", "forminator"), ), // src/form/components/fields/textarea.js:158
"Credit / Debit Card" => array( null, __("Credit / Debit Card", "forminator"), ), // src/form/components/fields/stripe.js:162
"Language" => array( null, __("Language", "forminator"), ), // src/form/components/fields/stripe.js:186
"Choose your preferred language for the Stripe field. This will affect the placeholders language, and the card validation errors returned by the Stripe." => array( null, __("Choose your preferred language for the Stripe field. This will affect the placeholders language, and the card validation errors returned by the Stripe.", "forminator"), ), // src/form/components/fields/stripe.js:188
"Auto" => array( null, __("Auto", "forminator"), ), // src/form/components/fields/stripe.js:193
"English (en)" => array( null, __("English (en)", "forminator"), ), // src/form/components/fields/stripe.js:194
"Simplified Chinese (zh)" => array( null, __("Simplified Chinese (zh)", "forminator"), ), // src/form/components/fields/stripe.js:195
"Danish (da)" => array( null, __("Danish (da)", "forminator"), ), // src/form/components/fields/stripe.js:196
"Dutch (nl)" => array( null, __("Dutch (nl)", "forminator"), ), // src/form/components/fields/stripe.js:197
"Finnish (fi)" => array( null, __("Finnish (fi)", "forminator"), ), // src/form/components/fields/stripe.js:198
"French (fr)" => array( null, __("French (fr)", "forminator"), ), // src/form/components/fields/stripe.js:199
"German (de)" => array( null, __("German (de)", "forminator"), ), // src/form/components/fields/stripe.js:200
"Italian (it)" => array( null, __("Italian (it)", "forminator"), ), // src/form/components/fields/stripe.js:201
"Japanese (ja)" => array( null, __("Japanese (ja)", "forminator"), ), // src/form/components/fields/stripe.js:202
"Norwegian (no)" => array( null, __("Norwegian (no)", "forminator"), ), // src/form/components/fields/stripe.js:203
"Spanish (es)" => array( null, __("Spanish (es)", "forminator"), ), // src/form/components/fields/stripe.js:204
"Swedish (sv)" => array( null, __("Swedish (sv)", "forminator"), ), // src/form/components/fields/stripe.js:205
"Card icon" => array( null, __("Card icon", "forminator"), ), // src/form/components/fields/stripe.js:216
"Choose whether you want to show the card icon on the Stripe field." => array( null, __("Choose whether you want to show the card icon on the Stripe field.", "forminator"), ), // src/form/components/fields/stripe.js:218
"Postal code" => array( null, __("Postal code", "forminator"), ), // src/form/components/fields/stripe.js:234
"Choose whether you want to collect the postal code on the Stripe field." => array( null, __("Choose whether you want to collect the postal code on the Stripe field.", "forminator"), ), // src/form/components/fields/stripe.js:236
"Prefill (optional)" => array( null, __("Prefill (optional)", "forminator"), ), // src/form/components/fields/stripe.js:255
"Select field" => array( null, __("Select field", "forminator"), ), // src/form/components/fields/stripe.js:264
"If you are already collecting ZIP code on your form, you can pre-fill it on the Stripe field." => array( null, __("If you are already collecting ZIP code on your form, you can pre-fill it on the Stripe field.", "forminator"), ), // src/form/components/fields/stripe.js:278
"You have not connected your Stripe account with Forminator. " => array( null, __("You have not connected your Stripe account with Forminator. ", "forminator"), ), // src/form/components/fields/stripe.js:315
"Connect your Stripe account {{link}}here{{/link}} and then come back to configure this field." => array( null, __("Connect your Stripe account {{link}}here{{/link}} and then come back to configure this field.", "forminator"), ), // src/form/components/fields/stripe.js:320
"Payment Mode" => array( null, __("Payment Mode", "forminator"), ), // src/form/components/fields/stripe.js:341
"We recommend using Test mode to ensure the payments are working as expected and when you are ready to start collecting live payments, switch to Live payments mode. " => array( null, __("We recommend using Test mode to ensure the payments are working as expected and when you are ready to start collecting live payments, switch to Live payments mode. ", "forminator"), ), // src/form/components/fields/stripe.js:349
"Test" => array( null, __("Test", "forminator"), ), // src/form/components/fields/stripe.js:362
"Charge currency" => array( null, __("Charge currency", "forminator"), ), // src/form/components/fields/stripe.js:369
"Choose the currency your users will be charged in." => array( null, __("Choose the currency your users will be charged in.", "forminator"), ), // src/form/components/fields/stripe.js:372
"Payment Plan" => array( null, __("Payment Plan", "forminator"), ), // src/form/components/fields/stripe.js:387
"Payment plans let you set up options for accepting payments on your site. You can add multiple plans and conditionally process them based on your form data." => array( null, __("Payment plans let you set up options for accepting payments on your site. You can add multiple plans and conditionally process them based on your form data.", "forminator"), ), // src/form/components/fields/stripe.js:395
"Note: You'll need to configure conditions on each plan to let Forminator know when to process each of the payment plans below." => array( null, __("Note: You'll need to configure conditions on each plan to let Forminator know when to process each of the payment plans below.", "forminator"), ), // src/form/components/fields/stripe.js:417
"There is an error in one or more of your payment plans. Please review the error and try again." => array( null, __("There is an error in one or more of your payment plans. Please review the error and try again.", "forminator"), ), // src/form/components/fields/stripe.js:444
"Payment Receipt" => array( null, __("Payment Receipt", "forminator"), ), // src/form/components/fields/stripe.js:473
"Choose whether you want Stripe to email a receipt to your customers on successful payment. Note that Stripe sends the email receipt only for live payments. {{link}}Customize email template{{/link}}." => array( null, __("Choose whether you want Stripe to email a receipt to your customers on successful payment. Note that Stripe sends the email receipt only for live payments. {{link}}Customize email template{{/link}}.", "forminator"), ), // src/form/components/fields/stripe.js:481
"Email address" => array( null, __("Email address", "forminator"), ), // src/form/components/fields/stripe.js:509
"E.g. john@doe.com" => array( null, __("E.g. john@doe.com", "forminator"), ), // src/form/components/fields/stripe.js:511
"Select an email field" => array( null, __("Select an email field", "forminator"), ), // src/form/components/fields/stripe.js:513
"Payment Details (optional)" => array( null, __("Payment Details (optional)", "forminator"), ), // src/form/components/fields/stripe.js:539
"You can add a statement decipher and a description to help you and your customers recognise the transactions made on this form." => array( null, __("You can add a statement decipher and a description to help you and your customers recognise the transactions made on this form.", "forminator"), ), // src/form/components/fields/stripe.js:547
"Statement decipher" => array( null, __("Statement decipher", "forminator"), ), // src/form/components/fields/stripe.js:556
"E.g. Company Name" => array( null, __("E.g. Company Name", "forminator"), ), // src/form/components/fields/stripe.js:559
"This is the business name your customers will see on their card statement." => array( null, __("This is the business name your customers will see on their card statement.", "forminator"), ), // src/form/components/fields/stripe.js:563
"Up to 22 characters only" => array( null, __("Up to 22 characters only", "forminator"), ), // src/form/components/fields/stripe.js:567
"Enter your payment description here" => array( null, __("Enter your payment description here", "forminator"), ), // src/form/components/fields/stripe.js:575
"This appears on your Stripe account and on the payment receipt sent to your customers." => array( null, __("This appears on your Stripe account and on the payment receipt sent to your customers.", "forminator"), ), // src/form/components/fields/stripe.js:578
"Payment description" => array( null, __("Payment description", "forminator"), ), // src/form/components/fields/stripe.js:581
"Card Validation" => array( null, __("Card Validation", "forminator"), ), // src/form/components/fields/stripe.js:600
"Note: Stripe field automatically validates the card as the user fills the card details regardless of the validation behavior set on the Behaviours tab." => array( null, __("Note: Stripe field automatically validates the card as the user fills the card details regardless of the validation behavior set on the Behaviours tab.", "forminator"), ), // src/form/components/fields/stripe.js:618
"Billing Details" => array( null, __("Billing Details", "forminator"), ), // src/form/components/fields/stripe.js:635
"If you are collecting billing details on your forms, you can send that data to Stripe. The billing details will appear on your Stripe dashboard for each payment." => array( null, __("If you are collecting billing details on your forms, you can send that data to Stripe. The billing details will appear on your Stripe dashboard for each payment.", "forminator"), ), // src/form/components/fields/stripe.js:643
"Customer name (optional)" => array( null, __("Customer name (optional)", "forminator"), ), // src/form/components/fields/stripe.js:666
"Select a name field" => array( null, __("Select a name field", "forminator"), ), // src/form/components/fields/stripe.js:668
"Customer email address (optional)" => array( null, __("Customer email address (optional)", "forminator"), ), // src/form/components/fields/stripe.js:683
"Billing address (optional)" => array( null, __("Billing address (optional)", "forminator"), ), // src/form/components/fields/stripe.js:700
"Select an address field" => array( null, __("Select an address field", "forminator"), ), // src/form/components/fields/stripe.js:702
"Meta Data" => array( null, __("Meta Data", "forminator"), ), // src/form/components/fields/stripe.js:727
"You can send custom meta data to Stripe. This would appear under the MetaData section of every payment. A maximum of 20 meta keys can be sent. The key name must be 20 characters or less, and the mapped data will be truncated to 500 characters as Stripe's requirements." => array( null, __("You can send custom meta data to Stripe. This would appear under the MetaData section of every payment. A maximum of 20 meta keys can be sent. The key name must be 20 characters or less, and the mapped data will be truncated to 500 characters as Stripe's requirements.", "forminator"), ), // src/form/components/fields/stripe.js:735
"MetaData" => array( null, __("MetaData", "forminator"), ), // src/form/components/fields/stripe.js:777
"Stripe automatically adds classes to the container DOM element based on the field state. However, you can customize them here. {{link}}Read more{{/link}}" => array( null, __("Stripe automatically adds classes to the container DOM element based on the field state. However, you can customize them here. {{link}}Read more{{/link}}", "forminator"), ), // src/form/components/fields/stripe.js:798
"Base class" => array( null, __("Base class", "forminator"), ), // src/form/components/fields/stripe.js:813
"Complete" => array( null, __("Complete", "forminator"), ), // src/form/components/fields/stripe.js:821
"Empty" => array( null, __("Empty", "forminator"), ), // src/form/components/fields/stripe.js:829
"Focused" => array( null, __("Focused", "forminator"), ), // src/form/components/fields/stripe.js:837
"Invalid" => array( null, __("Invalid", "forminator"), ), // src/form/components/fields/stripe.js:845
"Autofilled (Chrome and Safari only)" => array( null, __("Autofilled (Chrome and Safari only)", "forminator"), ), // src/form/components/fields/stripe.js:853
"Add your products, services and plans below. You can add multiple products and conditionally process each one based on your form data." => array( null, __("Add your products, services and plans below. You can add multiple products and conditionally process each one based on your form data.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:303
"Note: You'll need to configure conditions on each product to let Forminator know when to process each of the products below." => array( null, __("Note: You'll need to configure conditions on each product to let Forminator know when to process each of the products below.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:324
"There is an error in one or more of your products. Please review the error and try again." => array( null, __("There is an error in one or more of your products. Please review the error and try again.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:351
"Payment Methods" => array( null, __("Payment Methods", "forminator"), ), // src/form/components/fields/stripe-ocs.js:381
"Choose how customers can pay. The default option allows card payments only. To allow other payment methods like Venmo, Google Pay, or AliPay, select the Dynamic Payment Methods option below." => array( null, __("Choose how customers can pay. The default option allows card payments only. To allow other payment methods like Venmo, Google Pay, or AliPay, select the Dynamic Payment Methods option below.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:389
"Dynamic Payment Methods" => array( null, __("Dynamic Payment Methods", "forminator"), ), // src/form/components/fields/stripe-ocs.js:406
"You’ve selected dynamic payment methods. Please configure accepted payment methods on your {{link}}Stripe Dashboard{{/link}}." => array( null, __("You’ve selected dynamic payment methods. Please configure accepted payment methods on your {{link}}Stripe Dashboard{{/link}}.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:414
"Note: Only payment methods with immediate confirmation are supported." => array( null, __("Note: Only payment methods with immediate confirmation are supported.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:439
"{{link}}Learn more{{/link}}." => array( null, __("{{link}}Learn more{{/link}}.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:441
"Cards Only" => array( null, __("Cards Only", "forminator"), ), // src/form/components/fields/stripe-ocs.js:463
"Use these below options to enable and configure additional options for your Stripe payment." => array( null, __("Use these below options to enable and configure additional options for your Stripe payment.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:542
"Send Payment Receipt" => array( null, __("Send Payment Receipt", "forminator"), ), // src/form/components/fields/stripe-ocs.js:549
"Enable Stripe to email a receipt to your customers upon successful payment. Note that Stripe sends the email receipt only for live payments. {{link}}Customize email template{{/link}}." => array( null, __("Enable Stripe to email a receipt to your customers upon successful payment. Note that Stripe sends the email receipt only for live payments. {{link}}Customize email template{{/link}}.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:551
"Enable Billing Details" => array( null, __("Enable Billing Details", "forminator"), ), // src/form/components/fields/stripe-ocs.js:585
"Customer phone number (optional)" => array( null, __("Customer phone number (optional)", "forminator"), ), // src/form/components/fields/stripe-ocs.js:632
"Select a phone field" => array( null, __("Select a phone field", "forminator"), ), // src/form/components/fields/stripe-ocs.js:634
"Payment Element Layout" => array( null, __("Payment Element Layout", "forminator"), ), // src/form/components/fields/stripe-ocs.js:738
"Choose the Payment Element’s layout that fits your checkout flow." => array( null, __("Choose the Payment Element’s layout that fits your checkout flow.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:746
"Tabs" => array( null, __("Tabs", "forminator"), ), // src/form/components/fields/stripe-ocs.js:760
"Accordion with radio buttons" => array( null, __("Accordion with radio buttons", "forminator"), ), // src/form/components/fields/stripe-ocs.js:769
"Accordion without radio buttons" => array( null, __("Accordion without radio buttons", "forminator"), ), // src/form/components/fields/stripe-ocs.js:778
"Select a theme from the Stripe Appearance API to control the style of all elements." => array( null, __("Select a theme from the Stripe Appearance API to control the style of all elements.", "forminator"), ), // src/form/components/fields/stripe-ocs.js:811
"Night" => array( null, __("Night", "forminator"), ), // src/form/components/fields/stripe-ocs.js:820
"Customize Appearance" => array( null, __("Customize Appearance", "forminator"), ), // src/form/components/fields/stripe-ocs.js:829
"Customize Colors" => array( null, __("Customize Colors", "forminator"), ), // src/form/components/fields/stripe-ocs.js:836
"Primary color" => array( null, __("Primary color", "forminator"), ), // src/form/components/fields/stripe-ocs.js:841
"Error" => array( null, __("Error", "forminator"), ), // src/form/components/fields/stripe-ocs.js:862
"Other options" => array( null, __("Other options", "forminator"), ), // src/form/components/fields/stripe-ocs.js:870
"Border radius" => array( null, __("Border radius", "forminator"), ), // src/form/components/fields/stripe-ocs.js:903
"Note: Pass comma-separated values for this query parameter to pre-populate multiple options." => array( null, __("Note: Pass comma-separated values for this query parameter to pre-populate multiple options.", "forminator"), ), // src/form/components/fields/singlevalue.js:40
"Multi Select Style" => array( null, __("Multi Select Style", "forminator"), ), // src/form/components/fields/singlevalue.js:119
"Choose whether you want to use the Standard or Modern style." => array( null, __("Choose whether you want to use the Standard or Modern style.", "forminator"), ), // src/form/components/fields/singlevalue.js:127
"Standard" => array( null, __("Standard", "forminator"), ), // src/form/components/fields/singlevalue.js:148
"Modern" => array( null, __("Modern", "forminator"), ), // src/form/components/fields/singlevalue.js:156
"Search" => array( null, __("Search", "forminator"), ), // src/form/components/fields/singlevalue.js:169
"Display the search box in a dropdown" => array( null, __("Display the search box in a dropdown", "forminator"), ), // src/form/components/fields/singlevalue.js:177
"Checkbox In Dropdown Options" => array( null, __("Checkbox In Dropdown Options", "forminator"), ), // src/form/components/fields/singlevalue.js:208
"Select if you want to show or hide checkboxes in the Multi Select dropdown options" => array( null, __("Select if you want to show or hide checkboxes in the Multi Select dropdown options", "forminator"), ), // src/form/components/fields/singlevalue.js:217
"Limit Submission" => array( null, __("Limit Submission", "forminator"), ), // src/form/components/fields/singlevalue.js:245
"You can limit submissions of each option to a certain number, and once an option reaches the submission limit, we'll hide that option from the dropdown list." => array( null, __("You can limit submissions of each option to a certain number, and once an option reaches the submission limit, we'll hide that option from the dropdown list.", "forminator"), ), // src/form/components/fields/singlevalue.js:253
"You can set a limit for your options in the LABELS tab. Options for which limit field is left empty can have unlimited submissions." => array( null, __("You can set a limit for your options in the LABELS tab. Options for which limit field is left empty can have unlimited submissions.", "forminator"), ), // src/form/components/fields/singlevalue.js:298
"Signature Filetype" => array( null, __("Signature Filetype", "forminator"), ), // src/form/components/fields/signature.js:31
"Choose the filetype to save your users' signature in." => array( null, __("Choose the filetype to save your users' signature in.", "forminator"), ), // src/form/components/fields/signature.js:34
"PNG" => array( null, __("PNG", "forminator"), ), // src/form/components/fields/signature.js:47
"JPG" => array( null, __("JPG", "forminator"), ), // src/form/components/fields/signature.js:48
"Choose the height of your signature field. The default value is 180px." => array( null, __("Choose the height of your signature field. The default value is 180px.", "forminator"), ), // src/form/components/fields/signature.js:57
"Stroke Thickness" => array( null, __("Stroke Thickness", "forminator"), ), // src/form/components/fields/signature.js:74
"Choose the thickness in pixels for signature strokes. The default value is 2px." => array( null, __("Choose the thickness in pixels for signature strokes. The default value is 2px.", "forminator"), ), // src/form/components/fields/signature.js:77
"Enter title" => array( null, __("Enter title", "forminator"), ), // src/form/components/fields/section.js:32
"Subtitle (optional)" => array( null, __("Subtitle (optional)", "forminator"), ), // src/form/components/fields/section.js:40
"Enter subtitle" => array( null, __("Enter subtitle", "forminator"), ), // src/form/components/fields/section.js:41
"Add a border to this section." => array( null, __("Add a border to this section.", "forminator"), ), // src/form/components/fields/section.js:57
"Color" => array( null, __("Color", "forminator"), ), // src/form/components/fields/section.js:90
"Maximum Rating" => array( null, __("Maximum Rating", "forminator"), ), // src/form/components/fields/rating.js:59
"Specify the maximum rating number." => array( null, __("Specify the maximum rating number.", "forminator"), ), // src/form/components/fields/rating.js:61
"Max value should be 50." => array( null, __("Max value should be 50.", "forminator"), ), // src/form/components/fields/rating.js:70
"Enter Maximum Rating" => array( null, __("Enter Maximum Rating", "forminator"), ), // src/form/components/fields/rating.js:71
"Rating Icon" => array( null, __("Rating Icon", "forminator"), ), // src/form/components/fields/rating.js:88
"Select the style and size of the rating icon." => array( null, __("Select the style and size of the rating icon.", "forminator"), ), // src/form/components/fields/rating.js:96
"Show suffix" => array( null, __("Show suffix", "forminator"), ), // src/form/components/fields/rating.js:102
"Star" => array( null, __("Star", "forminator"), ), // src/form/components/fields/rating.js:123
"Heart" => array( null, __("Heart", "forminator"), ), // src/form/components/fields/rating.js:126
"Thumb" => array( null, __("Thumb", "forminator"), ), // src/form/components/fields/rating.js:129
"Smiley face" => array( null, __("Smiley face", "forminator"), ), // src/form/components/fields/rating.js:132
"Small - 16px" => array( null, __("Small - 16px", "forminator"), ), // src/form/components/fields/rating.js:144
"Medium - 24px" => array( null, __("Medium - 24px", "forminator"), ), // src/form/components/fields/rating.js:147
"Large - 32px" => array( null, __("Large - 32px", "forminator"), ), // src/form/components/fields/rating.js:150
"Wrong field type!" => array( null, __("Wrong field type!", "forminator"), ), // src/form/components/fields/rating.js:183
"By default, we stack the options vertically. However, you can change the options layout below." => array( null, __("By default, we stack the options vertically. However, you can change the options layout below.", "forminator"), ), // src/form/components/fields/radio.js:73
"Vertical" => array( null, __("Vertical", "forminator"), ), // src/form/components/fields/radio.js:85
"Horizontal" => array( null, __("Horizontal", "forminator"), ), // src/form/components/fields/radio.js:86
"Choose whether to allow this field to be used in calculations or not." => array( null, __("Choose whether to allow this field to be used in calculations or not.", "forminator"), ), // src/form/components/fields/radio.js:106
"Excerpt" => array( null, __("Excerpt", "forminator"), ), // src/form/components/fields/postdata.js:38
"Featured Image" => array( null, __("Featured Image", "forminator"), ), // src/form/components/fields/postdata.js:43
"Custom Fields" => array( null, __("Custom Fields", "forminator"), ), // src/form/components/fields/postdata.js:68
"Allow users to submit post data with this field. By default, this will create new posts, but you can assign it to any post type in the {{a}}Settings{{/a}} tab." => array( null, __("Allow users to submit post data with this field. By default, this will create new posts, but you can assign it to any post type in the {{a}}Settings{{/a}} tab.", "forminator"), ), // src/form/components/fields/postdata.js:89
"Post type" => array( null, __("Post type", "forminator"), ), // src/form/components/fields/postdata.js:250
"Choose the post type associated with this field." => array( null, __("Choose the post type associated with this field.", "forminator"), ), // src/form/components/fields/postdata.js:254
"Assigned post type" => array( null, __("Assigned post type", "forminator"), ), // src/form/components/fields/postdata.js:260
"post" => array( null, __("post", "forminator"), ), // src/form/components/fields/postdata.js:261
"Default status" => array( null, __("Default status", "forminator"), ), // src/form/components/fields/postdata.js:280
"When a user submits this form, choose what status this post data is." => array( null, __("When a user submits this form, choose what status this post data is.", "forminator"), ), // src/form/components/fields/postdata.js:285
"pending" => array( null, __("pending", "forminator"), ), // src/form/components/fields/postdata.js:294
"Pending Review" => array( null, __("Pending Review", "forminator"), ), // src/form/components/fields/postdata.js:302
"Published" => array( null, __("Published", "forminator"), ), // src/form/components/fields/postdata.js:305
"Default author" => array( null, __("Default author", "forminator"), ), // src/form/components/fields/postdata.js:314
"By default we'll assign posts to users if they're logged in, and fall back to the user specified below if you're allowing visitors to make posts. You can also override this to always assign posts to a specified user." => array( null, __("By default we'll assign posts to users if they're logged in, and fall back to the user specified below if you're allowing visitors to make posts. You can also override this to always assign posts to a specified user.", "forminator"), ), // src/form/components/fields/postdata.js:318
"Always assign posts to this user" => array( null, __("Always assign posts to this user", "forminator"), ), // src/form/components/fields/postdata.js:346
"Taxonomies limits" => array( null, __("Taxonomies limits", "forminator"), ), // src/form/components/fields/postdata.js:359
"Choose whether to allow single or multiple categories or tags on this post." => array( null, __("Choose whether to allow single or multiple categories or tags on this post.", "forminator"), ), // src/form/components/fields/postdata.js:363
"Validation" => array( null, __("Validation", "forminator"), ), // src/form/components/fields/phone.js:43
"Make sure the users fill this field as per the selected validation and warn them when they haven't" => array( null, __("Make sure the users fill this field as per the selected validation and warn them when they haven't", "forminator"), ), // src/form/components/fields/phone.js:46
"National" => array( null, __("National", "forminator"), ), // src/form/components/fields/phone.js:64
"Select the country to validate phone number for" => array( null, __("Select the country to validate phone number for", "forminator"), ), // src/form/components/fields/phone.js:71
"International" => array( null, __("International", "forminator"), ), // src/form/components/fields/phone.js:90
"Default country" => array( null, __("Default country", "forminator"), ), // src/form/components/fields/phone.js:97
"Character Limit" => array( null, __("Character Limit", "forminator"), ), // src/form/components/fields/phone.js:117
"Limit field to" => array( null, __("Limit field to", "forminator"), ), // src/form/components/fields/phone.js:124
"10" => array( null, __("10", "forminator"), ), // src/form/components/fields/phone.js:126
"In %s" => array( null, __("In %s", "forminator"), ), // src/form/components/fields/paypal.js:73
"You have not connected your PayPal account with Forminator. " => array( null, __("You have not connected your PayPal account with Forminator. ", "forminator"), ), // src/form/components/fields/paypal.js:105
"Connect your PayPal account {{link}}here{{/link}} and then come back to configure this field." => array( null, __("Connect your PayPal account {{link}}here{{/link}} and then come back to configure this field.", "forminator"), ), // src/form/components/fields/paypal.js:110
"Mode of payment" => array( null, __("Mode of payment", "forminator"), ), // src/form/components/fields/paypal.js:133
"We recommend using sandbox mode to ensure the payments are working as expected and when you are ready to start collecting live payments, switch to the {{strong}}Live{{/strong}} payments mode." => array( null, __("We recommend using sandbox mode to ensure the payments are working as expected and when you are ready to start collecting live payments, switch to the {{strong}}Live{{/strong}} payments mode.", "forminator"), ), // src/form/components/fields/paypal.js:137
"Sandbox" => array( null, __("Sandbox", "forminator"), ), // src/form/components/fields/paypal.js:146
"It's recommended to charge in your customers' currency to drive more sales and avoid foreign exchange fee to your customers." => array( null, __("It's recommended to charge in your customers' currency to drive more sales and avoid foreign exchange fee to your customers.", "forminator"), ), // src/form/components/fields/paypal.js:156
"Payment amount" => array( null, __("Payment amount", "forminator"), ), // src/form/components/fields/paypal.js:171
"Fixed" => array( null, __("Fixed", "forminator"), ), // src/form/components/fields/paypal.js:178
"Fixed amount" => array( null, __("Fixed amount", "forminator"), ), // src/form/components/fields/paypal.js:188
"E.g. 20.00" => array( null, __("E.g. 20.00", "forminator"), ), // src/form/components/fields/paypal.js:190
"Enter an amount or choose a form field." => array( null, __("Enter an amount or choose a form field.", "forminator"), ), // src/form/components/fields/paypal.js:192
"Variable" => array( null, __("Variable", "forminator"), ), // src/form/components/fields/paypal.js:201
"Variable amount" => array( null, __("Variable amount", "forminator"), ), // src/form/components/fields/paypal.js:211
"A currency field can be used to take user-defined payments such as donations and calculation field can be used to charge a calculated value based on a formula." => array( null, __("A currency field can be used to take user-defined payments such as donations and calculation field can be used to charge a calculated value based on a formula.", "forminator"), ), // src/form/components/fields/paypal.js:236
"Choose a label for your PayPal button. Note that PayPal checkout doesn't allow a custom label for the PayPal button. You can only choose from the pre-defined labels." => array( null, __("Choose a label for your PayPal button. Note that PayPal checkout doesn't allow a custom label for the PayPal button. You can only choose from the pre-defined labels.", "forminator"), ), // src/form/components/fields/paypal.js:258
"PayPal Checkout" => array( null, __("PayPal Checkout", "forminator"), ), // src/form/components/fields/paypal.js:264
"Pay with PayPal" => array( null, __("Pay with PayPal", "forminator"), ), // src/form/components/fields/paypal.js:265
"PayPal" => array( null, __("PayPal", "forminator"), ), // src/form/components/fields/paypal.js:266
"PayPal recommends using the Gold button since it is widely known as their brand color. However, if that does not suit your theme, you can choose a different color." => array( null, __("PayPal recommends using the Gold button since it is widely known as their brand color. However, if that does not suit your theme, you can choose a different color.", "forminator"), ), // src/form/components/fields/paypal.js:277
"Gold" => array( null, __("Gold", "forminator"), ), // src/form/components/fields/paypal.js:282
"Blue" => array( null, __("Blue", "forminator"), ), // src/form/components/fields/paypal.js:283
"Silver" => array( null, __("Silver", "forminator"), ), // src/form/components/fields/paypal.js:284
"White" => array( null, __("White", "forminator"), ), // src/form/components/fields/paypal.js:285
"Black" => array( null, __("Black", "forminator"), ), // src/form/components/fields/paypal.js:286
"E.g. 250" => array( null, __("E.g. 250", "forminator"), ), // src/form/components/fields/paypal.js:308
"Choose the width of PayPal Smart Buttons. It can be anywhere between 150px to 750px. Leave this empty if you want the buttons to take the full width of the form up to the 750px limit." => array( null, __("Choose the width of PayPal Smart Buttons. It can be anywhere between 150px to 750px. Leave this empty if you want the buttons to take the full width of the form up to the 750px limit.", "forminator"), ), // src/form/components/fields/paypal.js:318
"Choose the height of PayPal Smart Buttons. It can be anywhere between 25px to 55px" => array( null, __("Choose the height of PayPal Smart Buttons. It can be anywhere between 25px to 55px", "forminator"), ), // src/form/components/fields/paypal.js:354
"Shape" => array( null, __("Shape", "forminator"), ), // src/form/components/fields/paypal.js:364
"Choose your preferred shape from your PayPal Smart Buttons." => array( null, __("Choose your preferred shape from your PayPal Smart Buttons.", "forminator"), ), // src/form/components/fields/paypal.js:368
"Rectangular" => array( null, __("Rectangular", "forminator"), ), // src/form/components/fields/paypal.js:372
"Pill" => array( null, __("Pill", "forminator"), ), // src/form/components/fields/paypal.js:373
"We recommend the vertical layout as it allows additional payment methods such as Credit Cards. You can read about the layout options {{link}}here{{/link}}." => array( null, __("We recommend the vertical layout as it allows additional payment methods such as Credit Cards. You can read about the layout options {{link}}here{{/link}}.", "forminator"), ), // src/form/components/fields/paypal.js:384
"Tagline" => array( null, __("Tagline", "forminator"), ), // src/form/components/fields/paypal.js:402
"Choose whether to show the default PayPal tagline {{strong}}\"The safer, easier way to pay\"{{/strong}} below your PayPal button." => array( null, __("Choose whether to show the default PayPal tagline {{strong}}\"The safer, easier way to pay\"{{/strong}} below your PayPal button.", "forminator"), ), // src/form/components/fields/paypal.js:406
"Disable Funding Sources" => array( null, __("Disable Funding Sources", "forminator"), ), // src/form/components/fields/paypal.js:427
"PayPal automatically adds additional funding sources to the PayPal checkout for visitors from supported countries. However, you can choose to disable funding sources which shouldn't be displayed to visitors." => array( null, __("PayPal automatically adds additional funding sources to the PayPal checkout for visitors from supported countries. However, you can choose to disable funding sources which shouldn't be displayed to visitors.", "forminator"), ), // src/form/components/fields/paypal.js:435
"Credit or debit cards" => array( null, __("Credit or debit cards", "forminator"), ), // src/form/components/fields/paypal.js:448
"PayPal Credit" => array( null, __("PayPal Credit", "forminator"), ), // src/form/components/fields/paypal.js:455
"Bancontact" => array( null, __("Bancontact", "forminator"), ), // src/form/components/fields/paypal.js:462
"BLIK" => array( null, __("BLIK", "forminator"), ), // src/form/components/fields/paypal.js:469
"eps" => array( null, __("eps", "forminator"), ), // src/form/components/fields/paypal.js:476
"giropay" => array( null, __("giropay", "forminator"), ), // src/form/components/fields/paypal.js:483
"iDEAL" => array( null, __("iDEAL", "forminator"), ), // src/form/components/fields/paypal.js:490
"Mercado Pago" => array( null, __("Mercado Pago", "forminator"), ), // src/form/components/fields/paypal.js:499
"MyBank" => array( null, __("MyBank", "forminator"), ), // src/form/components/fields/paypal.js:506
"Przelewy24" => array( null, __("Przelewy24", "forminator"), ), // src/form/components/fields/paypal.js:513
"SEPA-Lastschrift" => array( null, __("SEPA-Lastschrift", "forminator"), ), // src/form/components/fields/paypal.js:520
"Sofort" => array( null, __("Sofort", "forminator"), ), // src/form/components/fields/paypal.js:527
"Venmo" => array( null, __("Venmo", "forminator"), ), // src/form/components/fields/paypal.js:534
"Pre-fill Billing Details" => array( null, __("Pre-fill Billing Details", "forminator"), ), // src/form/components/fields/paypal.js:544
"Pre-fill the payer's billing info collected on your form on the Debit or Credit Card checkout, so the payer doesn't have to enter those details again." => array( null, __("Pre-fill the payer's billing info collected on your form on the Debit or Credit Card checkout, so the payer doesn't have to enter those details again.", "forminator"), ), // src/form/components/fields/paypal.js:552
"Ensure the Country option is enabled and required for {{strong}}%(fieldName)s{{/strong}} to process Paypal’s transaction successfully." => array( null, __("Ensure the Country option is enabled and required for {{strong}}%(fieldName)s{{/strong}} to process Paypal’s transaction successfully.", "forminator"), ), // src/form/components/fields/paypal.js:669
"Shipping Address" => array( null, __("Shipping Address", "forminator"), ), // src/form/components/fields/paypal.js:705
"If you are selling a product that doesn't need to be shipped, you can choose to disable and hide the shipping address fields from the PayPal payment page." => array( null, __("If you are selling a product that doesn't need to be shipped, you can choose to disable and hide the shipping address fields from the PayPal payment page.", "forminator"), ), // src/form/components/fields/paypal.js:713
"By default, PayPal detects the language for the visitors based on their geolocation and browser preferences. It is recommended to pass this parameter only if you need the PayPal buttons to render in the same language as the rest of your site. {{link}}Supported locale codes.{{/link}}" => array( null, __("By default, PayPal detects the language for the visitors based on their geolocation and browser preferences. It is recommended to pass this parameter only if you need the PayPal buttons to render in the same language as the rest of your site. {{link}}Supported locale codes.{{/link}}", "forminator"), ), // src/form/components/fields/paypal.js:743
"Eg. en_US" => array( null, __("Eg. en_US", "forminator"), ), // src/form/components/fields/paypal.js:761
"Debug Mode" => array( null, __("Debug Mode", "forminator"), ), // src/form/components/fields/paypal.js:771
"PayPal debug mode helps troubleshoot any issues. However, it's recommended to disable this in production as it causes a significant increase in the script size and performance decrease." => array( null, __("PayPal debug mode helps troubleshoot any issues. However, it's recommended to disable this in production as it causes a significant increase in the script size and performance decrease.", "forminator"), ), // src/form/components/fields/paypal.js:779
"Confirm Password" => array( null, __("Confirm Password", "forminator"), ), // src/form/components/fields/password.js:71
"Confirm password" => array( null, __("Confirm password", "forminator"), ), // src/form/components/fields/password.js:82
"Confirm new password" => array( null, __("Confirm new password", "forminator"), ), // src/form/components/fields/password.js:92
"Minimum password strength" => array( null, __("Minimum password strength", "forminator"), ), // src/form/components/fields/password.js:123
"Choose a minimum password strength required to force your users to sign up with a password stronger than the minimum requirement." => array( null, __("Choose a minimum password strength required to force your users to sign up with a password stronger than the minimum requirement.", "forminator"), ), // src/form/components/fields/password.js:126
"Short" => array( null, __("Short", "forminator"), ), // src/form/components/fields/password.js:141
"Bad" => array( null, __("Bad", "forminator"), ), // src/form/components/fields/password.js:142
"Good" => array( null, __("Good", "forminator"), ), // src/form/components/fields/password.js:143
"Strong" => array( null, __("Strong", "forminator"), ), // src/form/components/fields/password.js:144
"This is displayed when the user's password is weaker than the minimum requirement." => array( null, __("This is displayed when the user's password is weaker than the minimum requirement.", "forminator"), ), // src/form/components/fields/password.js:158
"Password validation error message" => array( null, __("Password validation error message", "forminator"), ), // src/form/components/fields/password.js:171
"Enter an error message to be displayed when the passwords do not match." => array( null, __("Enter an error message to be displayed when the passwords do not match.", "forminator"), ), // src/form/components/fields/password.js:174
"Passwords do not match. Please try again." => array( null, __("Passwords do not match. Please try again.", "forminator"), ), // src/form/components/fields/password.js:182
"Step label" => array( null, __("Step label", "forminator"), ), // src/form/components/fields/pagination.js:25
"Enter step label" => array( null, __("Enter step label", "forminator"), ), // src/form/components/fields/pagination.js:26
"Set the minimum and maximum values the user can choose. Leave the fields blank to allow any number including negatives." => array( null, __("Set the minimum and maximum values the user can choose. Leave the fields blank to allow any number including negatives.", "forminator"), ), // src/form/components/fields/number.js:93
"Minimum" => array( null, __("Minimum", "forminator"), ), // src/form/components/fields/number.js:106
"Maximum" => array( null, __("Maximum", "forminator"), ), // src/form/components/fields/number.js:115
"Error Messages" => array( null, __("Error Messages", "forminator"), ), // src/form/components/fields/number.js:125
"When number is smaller than the min limit" => array( null, __("When number is smaller than the min limit", "forminator"), ), // src/form/components/fields/number.js:144
"E.g. Please enter a number greater than 0." => array( null, __("E.g. Please enter a number greater than 0.", "forminator"), ), // src/form/components/fields/number.js:147
"When number is greater than the max limit" => array( null, __("When number is greater than the max limit", "forminator"), ), // src/form/components/fields/number.js:157
"E.g. Please enter a number lower than 1000." => array( null, __("E.g. Please enter a number lower than 1000.", "forminator"), ), // src/form/components/fields/number.js:160
"Formatting" => array( null, __("Formatting", "forminator"), ), // src/form/components/fields/number.js:168
"Choose how do you want to format the value of this field." => array( null, __("Choose how do you want to format the value of this field.", "forminator"), ), // src/form/components/fields/number.js:171
"Separators" => array( null, __("Separators", "forminator"), ), // src/form/components/fields/number.js:184
"1234567.89" => array( null, __("1234567.89", "forminator"), ), // src/form/components/fields/number.js:188
"1,234,567.89" => array( null, __("1,234,567.89", "forminator"), ), // src/form/components/fields/number.js:191
"1.234.567,89" => array( null, __("1.234.567,89", "forminator"), ), // src/form/components/fields/number.js:194
"1 234 567,89" => array( null, __("1 234 567,89", "forminator"), ), // src/form/components/fields/number.js:197
"Round To" => array( null, __("Round To", "forminator"), ), // src/form/components/fields/number.js:212
"0 decimals" => array( null, __("0 decimals", "forminator"), ), // src/form/components/fields/number.js:215
"1 decimals" => array( null, __("1 decimals", "forminator"), ), // src/form/components/fields/number.js:216
"2 decimals" => array( null, __("2 decimals", "forminator"), ), // src/form/components/fields/number.js:217
"3 decimals" => array( null, __("3 decimals", "forminator"), ), // src/form/components/fields/number.js:218
"4 decimals" => array( null, __("4 decimals", "forminator"), ), // src/form/components/fields/number.js:219
"E.g. $" => array( null, __("E.g. $", "forminator"), ), // src/form/components/fields/number.js:233
"Thousand Separator" => array( null, __("Thousand Separator", "forminator"), ), // src/form/components/fields/number.js:236
"Decimal Separator" => array( null, __("Decimal Separator", "forminator"), ), // src/form/components/fields/number.js:246
"Expanded" => array( null, __("Expanded", "forminator"), ), // src/form/components/fields/name.js:88
"By default, the \"Prefix\" and \"First Name\" fields are added to the first row, and the rest of the name fields are added to the second row. Under the Custom tab, you can choose the number of columns for displaying the name fields." => array( null, __("By default, the \"Prefix\" and \"First Name\" fields are added to the first row, and the rest of the name fields are added to the second row. Under the Custom tab, you can choose the number of columns for displaying the name fields.", "forminator"), ), // src/form/components/fields/name.js:180
"Number of columns" => array( null, __("Number of columns", "forminator"), ), // src/form/components/fields/name.js:208
"Custom Value" => array( null, __("Custom Value", "forminator"), ), // src/form/components/fields/hidden.js:56
"Enter custom value" => array( null, __("Enter custom value", "forminator"), ), // src/form/components/fields/hidden.js:57
"Query parameter" => array( null, __("Query parameter", "forminator"), ), // src/form/components/fields/hidden.js:70
"The {{strong}}GDPR Field{{/strong}} has been deprecated and replaced by the new {{strong}}Consent Field{{/strong}}. Your existing fields should continue to work as expected, but please consider using the {{strong}}Consent Field{{/strong}} in the future." => array( null, __("The {{strong}}GDPR Field{{/strong}} has been deprecated and replaced by the new {{strong}}Consent Field{{/strong}}. Your existing fields should continue to work as expected, but please consider using the {{strong}}Consent Field{{/strong}} in the future.", "forminator"), ), // src/form/components/fields/gdprcheckbox.js:37
"Note, the form will not submit until the user has accepted the terms." => array( null, __("Note, the form will not submit until the user has accepted the terms.", "forminator"), ), // src/form/components/fields/gdprcheckbox.js:68
"Note: The query parameter's value passed in URL should match with the selected date format." => array( null, __("Note: The query parameter's value passed in URL should match with the selected date format.", "forminator"), ), // src/form/components/fields/date.js:33
"Calendar" => array( null, __("Calendar", "forminator"), ), // src/form/components/fields/date.js:52
"Date Format" => array( null, __("Date Format", "forminator"), ), // src/form/components/fields/date.js:79
"Y-m-d" => array( null, __("Y-m-d", "forminator"), ), // src/form/components/fields/date.js:83
"m-d-Y" => array( null, __("m-d-Y", "forminator"), ), // src/form/components/fields/date.js:84
"d-m-Y" => array( null, __("d-m-Y", "forminator"), ), // src/form/components/fields/date.js:85
"Y/m/d" => array( null, __("Y/m/d", "forminator"), ), // src/form/components/fields/date.js:86
"m/d/Y" => array( null, __("m/d/Y", "forminator"), ), // src/form/components/fields/date.js:87
"d/m/Y" => array( null, __("d/m/Y", "forminator"), ), // src/form/components/fields/date.js:88
"Y.m.d" => array( null, __("Y.m.d", "forminator"), ), // src/form/components/fields/date.js:89
"m.d.Y" => array( null, __("m.d.Y", "forminator"), ), // src/form/components/fields/date.js:90
"d.m.Y" => array( null, __("d.m.Y", "forminator"), ), // src/form/components/fields/date.js:91
"Calendar Icon" => array( null, __("Calendar Icon", "forminator"), ), // src/form/components/fields/date.js:112
"Text inputs" => array( null, __("Text inputs", "forminator"), ), // src/form/components/fields/date.js:231
"Default Date" => array( null, __("Default Date", "forminator"), ), // src/form/components/fields/date.js:371
"Use this feature to specify a default selected date." => array( null, __("Use this feature to specify a default selected date.", "forminator"), ), // src/form/components/fields/date.js:374
"Future Date" => array( null, __("Future Date", "forminator"), ), // src/form/components/fields/date.js:393
"Year Range" => array( null, __("Year Range", "forminator"), ), // src/form/components/fields/date.js:410
"By default, we select 100 years in the past, and 100 years in the future for the year dropdown field. You can set a custom year range to display in the year dropdown below." => array( null, __("By default, we select 100 years in the past, and 100 years in the future for the year dropdown field. You can set a custom year range to display in the year dropdown below.", "forminator"), ), // src/form/components/fields/date.js:413
"From" => array( null, __("From", "forminator"), ), // src/form/components/fields/date.js:425
"1920" => array( null, __("1920", "forminator"), ), // src/form/components/fields/date.js:426
"To" => array( null, __("To", "forminator"), ), // src/form/components/fields/date.js:436
"2030" => array( null, __("2030", "forminator"), ), // src/form/components/fields/date.js:437
"Currency" => array( null, __("Currency", "forminator"), ), // src/form/components/fields/currency.js:98
"Choose the currency to display on the field. If you are going to collect payments based on this field, it is recommended to keep this currency same as your charge currency to avoid any confusions." => array( null, __("Choose the currency to display on the field. If you are going to collect payments based on this field, it is recommended to keep this currency same as your charge currency to avoid any confusions.", "forminator"), ), // src/form/components/fields/currency.js:101
"Limit" => array( null, __("Limit", "forminator"), ), // src/form/components/fields/currency.js:121
"Restrict the value that your users can enter in this field within a custom range." => array( null, __("Restrict the value that your users can enter in this field within a custom range.", "forminator"), ), // src/form/components/fields/currency.js:124
"Min" => array( null, __("Min", "forminator"), ), // src/form/components/fields/currency.js:136
"Max" => array( null, __("Max", "forminator"), ), // src/form/components/fields/currency.js:151
"E.g. Consent" => array( null, __("E.g. Consent", "forminator"), ), // src/form/components/fields/consent.js:31
"Describe what your users should consent to." => array( null, __("Describe what your users should consent to.", "forminator"), ), // src/form/components/fields/consent.js:42
"hCaptcha verification failed. Please try again." => array( null, __("hCaptcha verification failed. Please try again.", "forminator"), ), // src/form/components/fields/captcha.js:27
"Cloudflare Turnstile verification failed. Please try again." => array( null, __("Cloudflare Turnstile verification failed. Please try again.", "forminator"), ), // src/form/components/fields/captcha.js:30
"Add your API keys {{link}}here{{/link}} and then come back to configure this field." => array( null, __("Add your API keys {{link}}here{{/link}} and then come back to configure this field.", "forminator"), ), // src/form/components/fields/captcha.js:41
"You haven't added hCaptcha API keys in your global settings." => array( null, __("You haven't added hCaptcha API keys in your global settings.", "forminator"), ), // src/form/components/fields/captcha.js:50
"You haven't added any Cloudflare Turnstile API keys in your global settings." => array( null, __("You haven't added any Cloudflare Turnstile API keys in your global settings.", "forminator"), ), // src/form/components/fields/captcha.js:51
"You haven't added API keys for this reCAPTCHA type in your global settings." => array( null, __("You haven't added API keys for this reCAPTCHA type in your global settings.", "forminator"), ), // src/form/components/fields/captcha.js:53
"Captcha Provider" => array( null, __("Captcha Provider", "forminator"), ), // src/form/components/fields/captcha.js:63
"Select your preferred CAPTCHA provider below." => array( null, __("Select your preferred CAPTCHA provider below.", "forminator"), ), // src/form/components/fields/captcha.js:66
"reCAPTCHA" => array( null, __("reCAPTCHA", "forminator"), ), // src/form/components/fields/captcha.js:79
"hCaptcha" => array( null, __("hCaptcha", "forminator"), ), // src/form/components/fields/captcha.js:84
"Cloudflare Turnstile" => array( null, __("Cloudflare Turnstile", "forminator"), ), // src/form/components/fields/captcha.js:114
"Alignment" => array( null, __("Alignment", "forminator"), ), // src/form/components/fields/captcha.js:147
"Select the alignment of CAPTCHA." => array( null, __("Select the alignment of CAPTCHA.", "forminator"), ), // src/form/components/fields/captcha.js:150
"reCAPTCHA type" => array( null, __("reCAPTCHA type", "forminator"), ), // src/form/components/fields/captcha.js:169
"Choose the reCAPTCHA type you want to use on your form. You can read more about the different reCAPTCHA types {{link}}here{{/link}} and then choose the one which suits you the best." => array( null, __("Choose the reCAPTCHA type you want to use on your form. You can read more about the different reCAPTCHA types {{link}}here{{/link}} and then choose the one which suits you the best.", "forminator"), ), // src/form/components/fields/captcha.js:172
"V2 Checkbox" => array( null, __("V2 Checkbox", "forminator"), ), // src/form/components/fields/captcha.js:195
"Size" => array( null, __("Size", "forminator"), ), // src/form/components/fields/captcha.js:228
"Normal" => array( null, __("Normal", "forminator"), ), // src/form/components/fields/captcha.js:232
"Theme" => array( null, __("Theme", "forminator"), ), // src/form/components/fields/captcha.js:240
"Light" => array( null, __("Light", "forminator"), ), // src/form/components/fields/captcha.js:244
"Dark" => array( null, __("Dark", "forminator"), ), // src/form/components/fields/captcha.js:245
"V2 Invisible" => array( null, __("V2 Invisible", "forminator"), ), // src/form/components/fields/captcha.js:256
"reCAPTCHA V3" => array( null, __("reCAPTCHA V3", "forminator"), ), // src/form/components/fields/captcha.js:298
"reCAPTCHA V3 returns a score (1 is very likely a good interaction, 0 is very likely a bot) based on user interaction. Choose the score below which the verification should fail." => array( null, __("reCAPTCHA V3 returns a score (1 is very likely a good interaction, 0 is very likely a bot) based on user interaction. Choose the score below which the verification should fail.", "forminator"), ), // src/form/components/fields/captcha.js:328
"Score Threshold" => array( null, __("Score Threshold", "forminator"), ), // src/form/components/fields/captcha.js:337
"0.0" => array( null, __("0.0", "forminator"), ), // src/form/components/fields/captcha.js:341
"0.1" => array( null, __("0.1", "forminator"), ), // src/form/components/fields/captcha.js:342
"0.2" => array( null, __("0.2", "forminator"), ), // src/form/components/fields/captcha.js:343
"0.3" => array( null, __("0.3", "forminator"), ), // src/form/components/fields/captcha.js:344
"0.4" => array( null, __("0.4", "forminator"), ), // src/form/components/fields/captcha.js:345
"0.5" => array( null, __("0.5", "forminator"), ), // src/form/components/fields/captcha.js:346
"0.6" => array( null, __("0.6", "forminator"), ), // src/form/components/fields/captcha.js:347
"0.7" => array( null, __("0.7", "forminator"), ), // src/form/components/fields/captcha.js:348
"0.8" => array( null, __("0.8", "forminator"), ), // src/form/components/fields/captcha.js:349
"0.9" => array( null, __("0.9", "forminator"), ), // src/form/components/fields/captcha.js:350
"1.0" => array( null, __("1.0", "forminator"), ), // src/form/components/fields/captcha.js:351
"hCaptcha type" => array( null, __("hCaptcha type", "forminator"), ), // src/form/components/fields/captcha.js:365
"hCaptcha offers two different types of CAPTCHA challenges, a Checkbox and an Invisible type. Choose the hCaptcha type you want to use in your form." => array( null, __("hCaptcha offers two different types of CAPTCHA challenges, a Checkbox and an Invisible type. Choose the hCaptcha type you want to use in your form.", "forminator"), ), // src/form/components/fields/captcha.js:368
"Invisible" => array( null, __("Invisible", "forminator"), ), // src/form/components/fields/captcha.js:419
"To comply with online privacy laws, users should be informed that this form includes an invisible CAPTCHA field." => array( null, __("To comply with online privacy laws, users should be informed that this form includes an invisible CAPTCHA field.", "forminator"), ), // src/form/components/fields/captcha.js:428
"Widget size" => array( null, __("Widget size", "forminator"), ), // src/form/components/fields/captcha.js:439
"Select the size of the CAPTCHA widget. {{link}}Learn more{{/link}}" => array( null, __("Select the size of the CAPTCHA widget. {{link}}Learn more{{/link}}", "forminator"), ), // src/form/components/fields/captcha.js:442
"Flexible" => array( null, __("Flexible", "forminator"), ), // src/form/components/fields/captcha.js:459
"Widget theme" => array( null, __("Widget theme", "forminator"), ), // src/form/components/fields/captcha.js:464
"The default is auto, which uses the visitor’s browser preference. You can also force the widget to use light or dark mode." => array( null, __("The default is auto, which uses the visitor’s browser preference. You can also force the widget to use light or dark mode.", "forminator"), ), // src/form/components/fields/captcha.js:467
"By default, the global CAPTCHA language setting will be used. However, you can manually select a different language here." => array( null, __("By default, the global CAPTCHA language setting will be used. However, you can manually select a different language here.", "forminator"), ), // src/form/components/fields/captcha.js:490
"Select the theme for the captcha." => array( null, __("Select the theme for the captcha.", "forminator"), ), // src/form/components/fields/captcha.js:527
"Badge Position" => array( null, __("Badge Position", "forminator"), ), // src/form/components/fields/captcha.js:556
"Select where the reCAPTCHA badge will be displayed on your page." => array( null, __("Select where the reCAPTCHA badge will be displayed on your page.", "forminator"), ), // src/form/components/fields/captcha.js:559
"Bottom Right" => array( null, __("Bottom Right", "forminator"), ), // src/form/components/fields/captcha.js:575
"Bottom Left" => array( null, __("Bottom Left", "forminator"), ), // src/form/components/fields/captcha.js:583
"Inline in Form" => array( null, __("Inline in Form", "forminator"), ), // src/form/components/fields/captcha.js:591
"Choose the error message you want to display on your form when reCAPTCHA verification fails." => array( null, __("Choose the error message you want to display on your form when reCAPTCHA verification fails.", "forminator"), ), // src/form/components/fields/captcha.js:607
"reCAPTCHA error message" => array( null, __("reCAPTCHA error message", "forminator"), ), // src/form/components/fields/captcha.js:616
"Choose the error message you want to display on your form when hCaptcha verification fails." => array( null, __("Choose the error message you want to display on your form when hCaptcha verification fails.", "forminator"), ), // src/form/components/fields/captcha.js:628
"hCaptcha error message" => array( null, __("hCaptcha error message", "forminator"), ), // src/form/components/fields/captcha.js:639
"Choose the error message you want to display on your form when Turnstile verification fails." => array( null, __("Choose the error message you want to display on your form when Turnstile verification fails.", "forminator"), ), // src/form/components/fields/captcha.js:650
"Cloudflare Turnstile error message" => array( null, __("Cloudflare Turnstile error message", "forminator"), ), // src/form/components/fields/captcha.js:661
"Field Type" => array( null, __("Field Type", "forminator"), ), // src/form/components/fields/calculation.js:85
"By default, the calculation field is read-only. You can also hide the field if you don't want to show the calculated result on the form." => array( null, __("By default, the calculation field is read-only. You can also hide the field if you don't want to show the calculated result on the form.", "forminator"), ), // src/form/components/fields/calculation.js:93
"Read-only" => array( null, __("Read-only", "forminator"), ), // src/form/components/fields/calculation.js:103
"Hidden" => array( null, __("Hidden", "forminator"), ), // src/form/components/fields/calculation.js:113
"Visibility rules have been added for this field. Enabling the Hidden option will remove the existing visibility rules." => array( null, __("Visibility rules have been added for this field. Enabling the Hidden option will remove the existing visibility rules.", "forminator"), ), // src/form/components/fields/calculation.js:137
"E.g., $" => array( null, __("E.g., $", "forminator"), ), // src/form/components/fields/calculation.js:176
"E.g., Kg" => array( null, __("E.g., Kg", "forminator"), ), // src/form/components/fields/calculation.js:188
"Suffix" => array( null, __("Suffix", "forminator"), ), // src/form/components/fields/calculation.js:190
"You can't set visibility conditions for a hidden field. Uncheck the Hidden option in the settings tab and come back here to define visibility rules." => array( null, __("You can't set visibility conditions for a hidden field. Uncheck the Hidden option in the settings tab and come back here to define visibility rules.", "forminator"), ), // src/form/components/fields/calculation.js:356
"Address" => array( null, __("Address", "forminator"), ), // src/form/components/fields/address.js:29
"Apartment, suite, etc." => array( null, __("Apartment, suite, etc.", "forminator"), ), // src/form/components/fields/address.js:33
"City" => array( null, __("City", "forminator"), ), // src/form/components/fields/address.js:37
"State / Province" => array( null, __("State / Province", "forminator"), ), // src/form/components/fields/address.js:41
"ZIP / Postal code" => array( null, __("ZIP / Postal code", "forminator"), ), // src/form/components/fields/address.js:45
"Country" => array( null, __("Country", "forminator"), ), // src/form/components/fields/address.js:49
"Note: The query parameter's value passed in URL should match with the {{link}}alpha-2 country code{{/link}} of the country you want to pre-populate dynamically." => array( null, __("Note: The query parameter's value passed in URL should match with the {{link}}alpha-2 country code{{/link}} of the country you want to pre-populate dynamically.", "forminator"), ), // src/form/components/fields/address.js:74
"The Autocomplete feature simplifies entering addresses by offering real-time suggestions as you type. This feature requires the Forminator Geolocation Add-on." => array( null, __("The Autocomplete feature simplifies entering addresses by offering real-time suggestions as you type. This feature requires the Forminator Geolocation Add-on.", "forminator"), ), // src/form/components/fields/address.js:267
"Collect your form submitters' location information, and provide address auto-completion using Google Maps API." => array( null, __("Collect your form submitters' location information, and provide address auto-completion using Google Maps API.", "forminator"), ), // src/form/components/fields/address.js:272
"Plan amount" => array( null, __("Plan amount", "forminator"), ), // src/form/components/fields/stripe/subscription.js:78
"Enter an amount or select a value from a form field in the Variable tab." => array( null, __("Enter an amount or select a value from a form field in the Variable tab.", "forminator"), ), // src/form/components/fields/stripe/subscription.js:80
"Amount" => array( null, __("Amount", "forminator"), ), // src/form/components/fields/stripe/subscription.js:102
"Choose form field" => array( null, __("Choose form field", "forminator"), ), // src/form/components/fields/stripe/subscription.js:122
"Quantity" => array( null, __("Quantity", "forminator"), ), // src/form/components/fields/stripe/subscription.js:143
"Enter the quantity or let your users set the quantity in a form field." => array( null, __("Enter the quantity or let your users set the quantity in a form field.", "forminator"), ), // src/form/components/fields/stripe/subscription.js:145
"E.g., 1" => array( null, __("E.g., 1", "forminator"), ), // src/form/components/fields/stripe/subscription.js:164
"Please enter a quantity or select a form field." => array( null, __("Please enter a quantity or select a form field.", "forminator"), ), // src/form/components/fields/stripe/subscription.js:169
"Bill every" => array( null, __("Bill every", "forminator"), ), // src/form/components/fields/stripe/subscription.js:205
"Duration cannot be empty." => array( null, __("Duration cannot be empty.", "forminator"), ), // src/form/components/fields/stripe/subscription.js:221
"Day(s)" => array( null, __("Day(s)", "forminator"), ), // src/form/components/fields/stripe/subscription.js:234
"Week(s)" => array( null, __("Week(s)", "forminator"), ), // src/form/components/fields/stripe/subscription.js:235
"Month(s)" => array( null, __("Month(s)", "forminator"), ), // src/form/components/fields/stripe/subscription.js:236
"Year(s)" => array( null, __("Year(s)", "forminator"), ), // src/form/components/fields/stripe/subscription.js:237
"Allow Trial Period" => array( null, __("Allow Trial Period", "forminator"), ), // src/form/components/fields/stripe/subscription.js:253
"Check this option to offer a limited-time free trial for this plan" => array( null, __("Check this option to offer a limited-time free trial for this plan", "forminator"), ), // src/form/components/fields/stripe/subscription.js:255
"Trial Duration" => array( null, __("Trial Duration", "forminator"), ), // src/form/components/fields/stripe/subscription.js:269
"Enter the number of days that users will try your product for free before they start paying." => array( null, __("Enter the number of days that users will try your product for free before they start paying.", "forminator"), ), // src/form/components/fields/stripe/subscription.js:271
"E.g., 14" => array( null, __("E.g., 14", "forminator"), ), // src/form/components/fields/stripe/subscription.js:276
"E.g., 20.00" => array( null, __("E.g., 20.00", "forminator"), ), // src/form/components/fields/stripe/single-payment.js:92
"Stripe Subscription Add-on is required to use this feature. Install it from the Add-ons page." => array( null, __("Stripe Subscription Add-on is required to use this feature. Install it from the Add-ons page.", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:34
"Collect recurring/subscription Stripe payments with Forminator Pro on your WordPress sites." => array( null, __("Collect recurring/subscription Stripe payments with Forminator Pro on your WordPress sites.", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:37
"Subscription" => array( null, __("Subscription", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:40
"Subscription {{span}}Pro{{/span}}" => array( null, __("Subscription {{span}}Pro{{/span}}", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:42
"Plan name" => array( null, __("Plan name", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:57
"Plan" => array( null, __("Plan", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:58
"This will be displayed on the submissions as well as the Stripe dashboard." => array( null, __("This will be displayed on the submissions as well as the Stripe dashboard.", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:60
"Plan Name is required." => array( null, __("Plan Name is required.", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:65
"Payment type" => array( null, __("Payment type", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:77
"One Time" => array( null, __("One Time", "forminator"), ), // src/form/components/fields/stripe/plan-setup.js:84
"Add Another Plan" => array( null, __("Add Another Plan", "forminator"), ), // src/form/components/fields/stripe/payment-plans.js:121
"Remove This Plan" => array( null, __("Remove This Plan", "forminator"), ), // src/form/components/fields/stripe/payment-plan.js:147
"Open Plan Settings" => array( null, __("Open Plan Settings", "forminator"), ), // src/form/components/fields/stripe/payment-plan.js:160
"Plan setup" => array( null, __("Plan setup", "forminator"), ), // src/form/components/fields/stripe/payment-plan.js:194
"Excellent" => array( null, __("Excellent", "forminator"), ), // src/form/components/fields/slider/settings.js:29
"Slider width" => array( null, __("Slider width", "forminator"), ), // src/form/components/fields/slider/settings.js:71
"The Slider takes the full-width of its container by default, but you can select a different size below." => array( null, __("The Slider takes the full-width of its container by default, but you can select a different size below.", "forminator"), ), // src/form/components/fields/slider/settings.js:73
"Small" => array( null, __("Small", "forminator"), ), // src/form/components/fields/slider/settings.js:77
"Full width" => array( null, __("Full width", "forminator"), ), // src/form/components/fields/slider/settings.js:80
"Slider scale" => array( null, __("Slider scale", "forminator"), ), // src/form/components/fields/slider/settings.js:93
"Adjust the slider base and the height of the draggable thumb/handle." => array( null, __("Adjust the slider base and the height of the draggable thumb/handle.", "forminator"), ), // src/form/components/fields/slider/settings.js:95
"Slider Handle icon" => array( null, __("Slider Handle icon", "forminator"), ), // src/form/components/fields/slider/settings.js:110
"Choose whether to show an icon on the slider handle." => array( null, __("Choose whether to show an icon on the slider handle.", "forminator"), ), // src/form/components/fields/slider/settings.js:112
"Display selected value" => array( null, __("Display selected value", "forminator"), ), // src/form/components/fields/slider/settings.js:131
"Selected value position" => array( null, __("Selected value position", "forminator"), ), // src/form/components/fields/slider/settings.js:140
"Above slider track" => array( null, __("Above slider track", "forminator"), ), // src/form/components/fields/slider/settings.js:145
"Below slider track" => array( null, __("Below slider track", "forminator"), ), // src/form/components/fields/slider/settings.js:146
"Display step values" => array( null, __("Display step values", "forminator"), ), // src/form/components/fields/slider/settings.js:158
"Display type" => array( null, __("Display type", "forminator"), ), // src/form/components/fields/slider/settings.js:167
"Min & Max values only" => array( null, __("Min & Max values only", "forminator"), ), // src/form/components/fields/slider/settings.js:172
"All values" => array( null, __("All values", "forminator"), ), // src/form/components/fields/slider/settings.js:173
"Use custom labels" => array( null, __("Use custom labels", "forminator"), ), // src/form/components/fields/slider/settings.js:179
"Add custom labels to the minimum and maximum values on the slider" => array( null, __("Add custom labels to the minimum and maximum values on the slider", "forminator"), ), // src/form/components/fields/slider/settings.js:180
"e.g., Poor" => array( null, __("e.g., Poor", "forminator"), ), // src/form/components/fields/slider/settings.js:205
"e.g., Great" => array( null, __("e.g., Great", "forminator"), ), // src/form/components/fields/slider/settings.js:228
"Prefix and Suffix" => array( null, __("Prefix and Suffix", "forminator"), ), // src/form/components/fields/slider/settings.js:240
"Use these fields to display texts (e.g., currency symbols or units of measure) before and after the slider values." => array( null, __("Use these fields to display texts (e.g., currency symbols or units of measure) before and after the slider values.", "forminator"), ), // src/form/components/fields/slider/settings.js:243
"E.g. \"$\"" => array( null, __("E.g. \"$\"", "forminator"), ), // src/form/components/fields/slider/settings.js:254
"E.g. \"%\"" => array( null, __("E.g. \"%\"", "forminator"), ), // src/form/components/fields/slider/settings.js:263
"Advanced settings" => array( null, __("Advanced settings", "forminator"), ), // src/form/components/fields/slider/settings.js:276
"Display and Labels" => array( null, __("Display and Labels", "forminator"), ), // src/form/components/fields/slider/settings.js:288
"Values" => array( null, __("Values", "forminator"), ), // src/form/components/fields/slider/settings.js:336
"Minimum value" => array( null, __("Minimum value", "forminator"), ), // src/form/components/fields/slider/settings.js:349
"Maximum value" => array( null, __("Maximum value", "forminator"), ), // src/form/components/fields/slider/settings.js:363
"Step (Increment between values)" => array( null, __("Step (Increment between values)", "forminator"), ), // src/form/components/fields/slider/settings.js:375
"Start value" => array( null, __("Start value", "forminator"), ), // src/form/components/fields/slider/settings.js:392
"Default selected value" => array( null, __("Default selected value", "forminator"), ), // src/form/components/fields/slider/settings.js:392
"End value" => array( null, __("End value", "forminator"), ), // src/form/components/fields/slider/settings.js:406
"Single Slider" => array( null, __("Single Slider", "forminator"), ), // src/form/components/fields/slider/labels.js:34
"Range Slider" => array( null, __("Range Slider", "forminator"), ), // src/form/components/fields/slider/labels.js:42
"Hide label" => array( null, __("Hide label", "forminator"), ), // src/form/components/fields/pdf/rich-text.js:36
"Price" => array( null, __("Price", "forminator"), ), // src/form/components/fields/pdf/payment.js:22
"Payment Type" => array( null, __("Payment Type", "forminator"), ), // src/form/components/fields/pdf/payment.js:30
"Payment Method" => array( null, __("Payment Method", "forminator"), ), // src/form/components/fields/pdf/payment.js:34
"Transaction/Payment ID" => array( null, __("Transaction/Payment ID", "forminator"), ), // src/form/components/fields/pdf/payment.js:38
"Payment Status" => array( null, __("Payment Status", "forminator"), ), // src/form/components/fields/pdf/payment.js:42
"Subtotal" => array( null, __("Subtotal", "forminator"), ), // src/form/components/fields/pdf/payment.js:46
"Tax" => array( null, __("Tax", "forminator"), ), // src/form/components/fields/pdf/payment.js:50
"Total Amount" => array( null, __("Total Amount", "forminator"), ), // src/form/components/fields/pdf/payment.js:54
"Product name" => array( null, __("Product name", "forminator"), ), // src/form/components/fields/pdf/payment.js:102
"Product Name" => array( null, __("Product Name", "forminator"), ), // src/form/components/fields/pdf/payment.js:116
"Hide or show input labels" => array( null, __("Hide or show input labels", "forminator"), ), // src/form/components/fields/pdf/all-form-data.js:65
"Enter form fields to remove from PDF." => array( null, __("Enter form fields to remove from PDF.", "forminator"), ), // src/form/components/fields/pdf/all-form-data.js:79
"Form field exclusion" => array( null, __("Form field exclusion", "forminator"), ), // src/form/components/fields/pdf/all-form-data.js:81
"Use the input option to remove specific field(s) from your PDF file." => array( null, __("Use the input option to remove specific field(s) from your PDF file.", "forminator"), ), // src/form/components/fields/pdf/all-form-data.js:82
"Group Field Styling" => array( null, __("Group Field Styling", "forminator"), ), // src/form/components/fields/group/styling.js:23
"By default, the Group Field will apply the styles you have set in the Appearance settings, but you can remove those styles with this option." => array( null, __("By default, the Group Field will apply the styles you have set in the Appearance settings, but you can remove those styles with this option.", "forminator"), ), // src/form/components/fields/group/styling.js:27
"Remove" => array( null, __("Remove", "forminator"), ), // src/form/components/fields/group/styling.js:51
"Field Repeater" => array( null, __("Field Repeater", "forminator"), ), // src/form/components/fields/group/settings.js:38
"Allow fields in this group to be repeated." => array( null, __("Allow fields in this group to be repeated.", "forminator"), ), // src/form/components/fields/group/settings.js:40
"Minimum repeater limit" => array( null, __("Minimum repeater limit", "forminator"), ), // src/form/components/fields/group/settings.js:57
"Enter the minimum number of times this group field will be repeated by default, or select a variable from your form fields. If left empty, the minimum will default to 1." => array( null, __("Enter the minimum number of times this group field will be repeated by default, or select a variable from your form fields. If left empty, the minimum will default to 1.", "forminator"), ), // src/form/components/fields/group/settings.js:60
"Enter minimum limit" => array( null, __("Enter minimum limit", "forminator"), ), // src/form/components/fields/group/settings.js:80
"Maximum repeater limit" => array( null, __("Maximum repeater limit", "forminator"), ), // src/form/components/fields/group/settings.js:117
"Enter the maximum number of times this group field can be repeated, or select a variable from your form fields. If left empty, the maximum will be unlimited." => array( null, __("Enter the maximum number of times this group field can be repeated, or select a variable from your form fields. If left empty, the maximum will be unlimited.", "forminator"), ), // src/form/components/fields/group/settings.js:120
"Enter maximum limit" => array( null, __("Enter maximum limit", "forminator"), ), // src/form/components/fields/group/settings.js:138
"Repeater Element Type" => array( null, __("Repeater Element Type", "forminator"), ), // src/form/components/fields/group/settings.js:175
"Choose the element type and label text for your repeater actions." => array( null, __("Choose the element type and label text for your repeater actions.", "forminator"), ), // src/form/components/fields/group/settings.js:177
"Buttons" => array( null, __("Buttons", "forminator"), ), // src/form/components/fields/group/settings.js:185
"Add Button Text (optional)" => array( null, __("Add Button Text (optional)", "forminator"), ), // src/form/components/fields/group/settings.js:193
"Add item" => array( null, __("Add item", "forminator"), ), // src/form/components/fields/group/settings.js:194
"Remove Button Text (optional)" => array( null, __("Remove Button Text (optional)", "forminator"), ), // src/form/components/fields/group/settings.js:203
"Remove item" => array( null, __("Remove item", "forminator"), ), // src/form/components/fields/group/settings.js:204
"Icons" => array( null, __("Icons", "forminator"), ), // src/form/components/fields/group/settings.js:216
"Text links" => array( null, __("Text links", "forminator"), ), // src/form/components/fields/group/settings.js:223
"Add Link Text (optional)" => array( null, __("Add Link Text (optional)", "forminator"), ), // src/form/components/fields/group/settings.js:231
"Use this field to group Forminator fields together and collect repeating data in your form." => array( null, __("Use this field to group Forminator fields together and collect repeating data in your form.", "forminator"), ), // src/form/components/fields/group/labels.js:20
"Learn more about grouping and repeating use cases in {{link}}this tutorial. {{icon/}}{{/link}}" => array( null, __("Learn more about grouping and repeating use cases in {{link}}this tutorial. {{icon/}}{{/link}}", "forminator"), ), // src/form/components/fields/group/labels.js:24
"Enter error message" => array( null, __("Enter error message", "forminator"), ), // src/form/components/fields/email/filter-emails.js:43
"This email is not allowed. Please use a different one." => array( null, __("This email is not allowed. Please use a different one.", "forminator"), ), // src/form/components/fields/email/filter-emails.js:44
"Enter email addresses and domains to block, separated by commas. Use * for advanced filtering. E.g., user@example.com, @example.com, *.com, *no-reply*" => array( null, __("Enter email addresses and domains to block, separated by commas. Use * for advanced filtering. E.g., user@example.com, @example.com, *.com, *no-reply*", "forminator"), ), // src/form/components/fields/email/filter-emails.js:51
"{{link}}learn more{{/link}}" => array( null, __("{{link}}learn more{{/link}}", "forminator"), ), // src/form/components/fields/email/filter-emails.js:56
"Enter email addresses and domains to allow, separated by commas. Use * for advanced filtering. E.g., user@example.com, @example.com, *.com, admin@*, hr@*.com" => array( null, __("Enter email addresses and domains to allow, separated by commas. Use * for advanced filtering. E.g., user@example.com, @example.com, *.com, admin@*, hr@*.com", "forminator"), ), // src/form/components/fields/email/filter-emails.js:68
"Filter email providers" => array( null, __("Filter email providers", "forminator"), ), // src/form/components/fields/email/filter-emails.js:85
"Use this option to allow or prevent email providers or domains from submitting this form." => array( null, __("Use this option to allow or prevent email providers or domains from submitting this form.", "forminator"), ), // src/form/components/fields/email/filter-emails.js:88
"Deny-list" => array( null, __("Deny-list", "forminator"), ), // src/form/components/fields/email/filter-emails.js:105
"Allow-list" => array( null, __("Allow-list", "forminator"), ), // src/form/components/fields/email/filter-emails.js:111
"E.g., user@example.com" => array( null, __("E.g., user@example.com", "forminator"), ), // src/form/components/fields/email/filter-emails.js:120
"Insert new field" => array( null, __("Insert new field", "forminator"), ), // src/form/components/builder/wrapper.js:96
"Swipe" => array( null, __("Swipe", "forminator"), ), // src/form/components/builder/wrapper-list.js:25
"Edit field" => array( null, __("Edit field", "forminator"), ), // src/form/components/builder/submit.js:117
"PayPal field replaces the submit button of your form with the PayPal Smart Payment Buttons. The PayPal buttons will automatically submit the form after a successful payment." => array( null, __("PayPal field replaces the submit button of your form with the PayPal Smart Payment Buttons. The PayPal buttons will automatically submit the form after a successful payment.", "forminator"), ), // src/form/components/builder/paypal.js:202
"Field options" => array( null, __("Field options", "forminator"), ), // src/form/components/builder/paypal.js:238
"Since you are using Page Break field(s) to divide your form into multiple pages, use the pagination settings to customize the page label, progress indicator, and the buttons on each page." => array( null, __("Since you are using Page Break field(s) to divide your form into multiple pages, use the pagination settings to customize the page label, progress indicator, and the buttons on each page.", "forminator"), ), // src/form/components/builder/pagination.js:46
"Page Header" => array( null, __("Page Header", "forminator"), ), // src/form/components/builder/page-header.js:33
"Page Footer" => array( null, __("Page Footer", "forminator"), ), // src/form/components/builder/page-footer.js:33
"Insert Form Fields" => array( null, __("Insert Form Fields", "forminator"), ), // src/form/components/builder/insert-fields.js:11
"Add fields to group" => array( null, __("Add fields to group", "forminator"), ), // src/form/components/builder/insert-fields.js:11
"You haven’t added any fields yet. Add form fields to get started." => array( null, __("You haven’t added any fields yet. Add form fields to get started.", "forminator"), ), // src/form/components/builder/insert-fields.js:66
"Old Stripe field is being deprecated and only available for backward compatibility. You can delete this field if your form is working properly." => array( null, __("Old Stripe field is being deprecated and only available for backward compatibility. You can delete this field if your form is working properly.", "forminator"), ), // src/form/components/builder/field.js:1097
"Legacy" => array( null, __("Legacy", "forminator"), ), // src/form/components/builder/field.js:1098
"Delete field" => array( null, __("Delete field", "forminator"), ), // src/form/components/builder/field.js:1131
"Submission Behavior" => array( null, __("Submission Behavior", "forminator"), ), // src/form/components/behaviour/submission.js:21
"Configure what should happen when a user submits this form." => array( null, __("Configure what should happen when a user submits this form.", "forminator"), ), // src/form/components/behaviour/submission.js:25
"After submission" => array( null, __("After submission", "forminator"), ), // src/form/components/behaviour/submission.js:35
"Choose what happens after successful submission of this form. Multiple submission behaviors can be added and conditionally processed based on submitted form data." => array( null, __("Choose what happens after successful submission of this form. Multiple submission behaviors can be added and conditionally processed based on submitted form data.", "forminator"), ), // src/form/components/behaviour/submission.js:42
"You’ll need to configure conditional logic for each submission behavior to ensure Forminator knows when each behavior should be processed. If no conditions have been set, the first submission behavior will be processed." => array( null, __("You’ll need to configure conditional logic for each submission behavior to ensure Forminator knows when each behavior should be processed. If no conditions have been set, the first submission behavior will be processed.", "forminator"), ), // src/form/components/behaviour/submission.js:68
"Choose whether you want to use AJAX to send this form without reloading the page, or use the more traditional method of reloading the page." => array( null, __("Choose whether you want to use AJAX to send this form without reloading the page, or use the more traditional method of reloading the page.", "forminator"), ), // src/form/components/behaviour/submission.js:94
"Note that you can only use the Ajax submission method while using the Stripe field in your form. The Ajax method will hide your form after the successful submission and only your inline success message will be shown. The form will be available again when the page is reloaded." => array( null, __("Note that you can only use the Ajax submission method while using the Stripe field in your form. The Ajax method will hide your form after the successful submission and only your inline success message will be shown. The form will be available again when the page is reloaded.", "forminator"), ), // src/form/components/behaviour/submission.js:122
"Page Reload" => array( null, __("Page Reload", "forminator"), ), // src/form/components/behaviour/submission.js:140
"For fields that you've chosen to validate, choose how you want the validation to behave. On submission will run validation checks when the user submits the form using Ajax (recommended). The Live method will check fields at the same time as the user fills them out. Server side does the validation using PHP and returns any error messages after a page reload." => array( null, __("For fields that you've chosen to validate, choose how you want the validation to behave. On submission will run validation checks when the user submits the form using Ajax (recommended). The Live method will check fields at the same time as the user fills them out. Server side does the validation using PHP and returns any error messages after a page reload.", "forminator"), ), // src/form/components/behaviour/submission.js:186
"On Submit" => array( null, __("On Submit", "forminator"), ), // src/form/components/behaviour/submission.js:195
"Server Side" => array( null, __("Server Side", "forminator"), ), // src/form/components/behaviour/submission.js:196
"Enable inline validation (as user types)" => array( null, __("Enable inline validation (as user types)", "forminator"), ), // src/form/components/behaviour/submission.js:200
"Submission Indicator" => array( null, __("Submission Indicator", "forminator"), ), // src/form/components/behaviour/submission.js:208
"Choose whether you want to show a loader on your form until it is submitted. We highly recommend using this on long forms or forms with payment field since they may take a few seconds to submit." => array( null, __("Choose whether you want to show a loader on your form until it is submitted. We highly recommend using this on long forms or forms with payment field since they may take a few seconds to submit.", "forminator"), ), // src/form/components/behaviour/submission.js:211
"E.g. Submitting…" => array( null, __("E.g. Submitting…", "forminator"), ), // src/form/components/behaviour/submission.js:225
"Text to show on the right of loading icon" => array( null, __("Text to show on the right of loading icon", "forminator"), ), // src/form/components/behaviour/submission.js:227
"Choose the text to show on the right of loading icon" => array( null, __("Choose the text to show on the right of loading icon", "forminator"), ), // src/form/components/behaviour/submission.js:229
"Your {form_name} form on {site_title} has been saved as draft" => array( null, __("Your {form_name} form on {site_title} has been saved as draft", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:42
"<p>Hi there!</p><p>You've successfully saved <b>{form_name}</b> form on <a href='{site_url}' target='_blank' rel='noopener noreferrer' style='color:#097BAA;'>{site_title}</a>.
To continue where you left off, click the link below or copy the link to your web browser.</p><p><a href='{form_link}' target='_blank' rel='noopener noreferrer' style='color:#097BAA;'>{form_link}</a></p><p>The above link will expire in {retention_period} days. Also note that anyone visiting the link will be able to view your partially completed form data.</p>" => array( null, __("<p>Hi there!</p><p>You've successfully saved <b>{form_name}</b> form on <a href='{site_url}' target='_blank' rel='noopener noreferrer' style='color:#097BAA;'>{site_title}</a>.
To continue where you left off, click the link below or copy the link to your web browser.</p><p><a href='{form_link}' target='_blank' rel='noopener noreferrer' style='color:#097BAA;'>{form_link}</a></p><p>The above link will expire in {retention_period} days. Also note that anyone visiting the link will be able to view your partially completed form data.</p>", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:44
"<p>Your form has been saved as draft and a resume link has been generated so you can return to the form anytime within {retention_period} days from today. Copy and save the link or enter your email address below to have the link sent to your mail.</p><p>These fields weren't saved to your submission draft: Paypal, Stripe, Signature, Password, Captcha, and Upload. Kindly fill them out before submitting the form.</p>" => array( null, __("<p>Your form has been saved as draft and a resume link has been generated so you can return to the form anytime within {retention_period} days from today. Copy and save the link or enter your email address below to have the link sent to your mail.</p><p>These fields weren't saved to your submission draft: Paypal, Stripe, Signature, Password, Captcha, and Upload. Kindly fill them out before submitting the form.</p>", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:76
"Enable this option if you want to allow users save their progress and return to complete the form at a later time." => array( null, __("Enable this option if you want to allow users save their progress and return to complete the form at a later time.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:99
"Enable save and continue" => array( null, __("Enable save and continue", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:110
"Configuration" => array( null, __("Configuration", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:128
"Draft retention period" => array( null, __("Draft retention period", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:134
"Enter the number of days a form's draft will be stored on your server before they are automatically deleted." => array( null, __("Enter the number of days a form's draft will be stored on your server before they are automatically deleted.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:137
"Save form link text" => array( null, __("Save form link text", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:146
"Save as Draft" => array( null, __("Save as Draft", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:147
"Edit text for the save draft link." => array( null, __("Edit text for the save draft link.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:149
"Resume message" => array( null, __("Resume message", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:158
"This message will be shown when a form is successfully saved as draft." => array( null, __("This message will be shown when a form is successfully saved as draft.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:159
"These fields will not be saved in the submission draft: Paypal, Stripe, Signature, Password, Captcha, and Upload." => array( null, __("These fields will not be saved in the submission draft: Paypal, Stripe, Signature, Password, Captcha, and Upload.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:176
"Allow send draft link to email" => array( null, __("Allow send draft link to email", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:186
"Enable to allow users send the draft form's link to their email." => array( null, __("Enable to allow users send the draft form's link to their email.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:188
"Configure the send link email form below. You can edit the email contents in the {{link}}Email Notifications{{/link}} tab." => array( null, __("Configure the send link email form below. You can edit the email contents in the {{link}}Email Notifications{{/link}} tab.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:199
"Email input label" => array( null, __("Email input label", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:214
"Send draft link to" => array( null, __("Send draft link to", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:215
"Placeholder (Optional)" => array( null, __("Placeholder (Optional)", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:221
"E.g., johndoe@gmail.com" => array( null, __("E.g., johndoe@gmail.com", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:222
"Send link button label" => array( null, __("Send link button label", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:228
"Send draft link" => array( null, __("Send draft link", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:229
"Permission" => array( null, __("Permission", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:240
"Select which users can save their forms as draft." => array( null, __("Select which users can save their forms as draft.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:246
"Public" => array( null, __("Public", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:261
"Every user can save their forms as draft." => array( null, __("Every user can save their forms as draft.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:266
"Registered Users" => array( null, __("Registered Users", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:275
"Only registered users can save their forms as draft." => array( null, __("Only registered users can save their forms as draft.", "forminator"), ), // src/form/components/behaviour/save-and-continue.js:280
"Choose how you want your form to be rendered for users." => array( null, __("Choose how you want your form to be rendered for users.", "forminator"), ), // src/form/components/behaviour/render.js:15
"Load form using AJAX" => array( null, __("Load form using AJAX", "forminator"), ), // src/form/components/behaviour/render.js:23
"Enabling this feature will load the form via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your form." => array( null, __("Enabling this feature will load the form via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your form.", "forminator"), ), // src/form/components/behaviour/render.js:25
"Prevent page caching on form pages" => array( null, __("Prevent page caching on form pages", "forminator"), ), // src/form/components/behaviour/render.js:35
"Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic forms. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this form on it from being cached." => array( null, __("Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic forms. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this form on it from being cached.", "forminator"), ), // src/form/components/behaviour/render.js:37
"Payments" => array( null, __("Payments", "forminator"), ), // src/form/components/behaviour/payments.js:14
"Choose how you want the form to behave when you are collecting payments." => array( null, __("Choose how you want the form to behave when you are collecting payments.", "forminator"), ), // src/form/components/behaviour/payments.js:17
"Require SSL certificate to submit this form" => array( null, __("Require SSL certificate to submit this form", "forminator"), ), // src/form/components/behaviour/payments.js:24
"Enabling this will allow the form submission on an HTTPS page only. It is highly recommended to embed the form with payments action on an HTTPS page to avoid any man in the middle attack." => array( null, __("Enabling this will allow the form submission on an HTTPS page only. It is highly recommended to embed the form with payments action on an HTTPS page to avoid any man in the middle attack.", "forminator"), ), // src/form/components/behaviour/payments.js:27
"By default this form will always be available for submissions. However you can lock down if need be." => array( null, __("By default this form will always be available for submissions. However you can lock down if need be.", "forminator"), ), // src/form/components/behaviour/lifespan.js:22
"Whoops! This form has expired." => array( null, __("Whoops! This form has expired.", "forminator"), ), // src/form/components/behaviour/lifespan.js:55
"Add some custom message for users to see when your form stops appearing or leave empty to show nothing (just an empty space)." => array( null, __("Add some custom message for users to see when your form stops appearing or leave empty to show nothing (just an empty space).", "forminator"), ), // src/form/components/behaviour/lifespan.js:58
"Process behavior if " => array( null, __("Process behavior if ", "forminator"), ), // src/form/components/behaviour/conditions.js:131
"of the conditions below match." => array( null, __("of the conditions below match.", "forminator"), ), // src/form/components/behaviour/conditions.js:144
"Add conditions for when this behavior will be processed." => array( null, __("Add conditions for when this behavior will be processed.", "forminator"), ), // src/form/components/behaviour/conditions.js:172
"Add Behavior" => array( null, __("Add Behavior", "forminator"), ), // src/form/components/behaviour/behaviors.js:75
"Process behavior if" => array( null, __("Process behavior if", "forminator"), ), // src/form/components/behaviour/behavior.js:105
"Open condition settings" => array( null, __("Open condition settings", "forminator"), ), // src/form/components/behaviour/behavior.js:173
"Edit Behavior" => array( null, __("Edit Behavior", "forminator"), ), // src/form/components/behaviour/behavior.js:180
"Form does not have fields that can be autofilled." => array( null, __("Form does not have fields that can be autofilled.", "forminator"), ), // src/form/components/behaviour/autofill.js:79
"Autofill" => array( null, __("Autofill", "forminator"), ), // src/form/components/behaviour/autofill.js:187
"If the user filling out the form is logged in, we can auto-fill fields with any available data." => array( null, __("If the user filling out the form is logged in, we can auto-fill fields with any available data.", "forminator"), ), // src/form/components/behaviour/autofill.js:190
"Enable Autofill" => array( null, __("Enable Autofill", "forminator"), ), // src/form/components/behaviour/autofill.js:199
"Autofill source" => array( null, __("Autofill source", "forminator"), ), // src/form/components/behaviour/autofill.js:235
"Disable Autofill" => array( null, __("Disable Autofill", "forminator"), ), // src/form/components/behaviour/autofill.js:241
"Editable" => array( null, __("Editable", "forminator"), ), // src/form/components/behaviour/autofill.js:260
"No" => array( null, __("No", "forminator"), ), // src/form/components/behaviour/autofill.js:265
"Yes" => array( null, __("Yes", "forminator"), ), // src/form/components/behaviour/autofill.js:268
"Choose a preset to apply to your form. You can edit or create new ones in {{link}}Settings > Appearance Preset{{/link}}" => array( null, __("Choose a preset to apply to your form. You can edit or create new ones in {{link}}Settings > Appearance Preset{{/link}}", "forminator"), ), // src/form/components/appearance/preset-template.js:41
"Select preset" => array( null, __("Select preset", "forminator"), ), // src/form/components/appearance/preset-template.js:56
"Choose preset" => array( null, __("Choose preset", "forminator"), ), // src/form/components/appearance/preset-template.js:58
"Apply Preset" => array( null, __("Apply Preset", "forminator"), ), // src/form/components/appearance/preset-template.js:74
"Customize the appearance of pagination of your form." => array( null, __("Customize the appearance of pagination of your form.", "forminator"), ), // src/form/components/appearance/pagination.js:29
"Note: " => array( null, __("Note: ", "forminator"), ), // src/form/components/appearance/pagination.js:35
"If you have added multiple pagination fields in your form, these settings will affect all of them." => array( null, __("If you have added multiple pagination fields in your form, these settings will affect all of them.", "forminator"), ), // src/form/components/appearance/pagination.js:37
"By default we don’t show how many pages the user has left before completing the form. You can turn on a stepped progress bar to indicate to the user how far they are through your form." => array( null, __("By default we don’t show how many pages the user has left before completing the form. You can turn on a stepped progress bar to indicate to the user how far they are through your form.", "forminator"), ), // src/form/components/appearance/pagination.js:51
"Our PDF builder is constantly improving and we’ll be adding more features over time. While the current release has limited customization options, we appreciate your patience as we work to bring you the best experience possible. Keep an eye out for updates. To manually adjust the appearance of the fields, you can enable the Custom CSS option below." => array( null, __("Our PDF builder is constantly improving and we’ll be adding more features over time. While the current release has limited customization options, we appreciate your patience as we work to bring you the best experience possible. Keep an eye out for updates. To manually adjust the appearance of the fields, you can enable the Custom CSS option below.", "forminator"), ), // src/form/components/appearance/page-settings.js:31
"Page settings" => array( null, __("Page settings", "forminator"), ), // src/form/components/appearance/page-settings.js:42
"Configure the PDF file settings" => array( null, __("Configure the PDF file settings", "forminator"), ), // src/form/components/appearance/page-settings.js:44
"Page size" => array( null, __("Page size", "forminator"), ), // src/form/components/appearance/page-settings.js:49
"Choose the standard paper size for your PDF document. The default resolution for each page is set at 96dpi." => array( null, __("Choose the standard paper size for your PDF document. The default resolution for each page is set at 96dpi.", "forminator"), ), // src/form/components/appearance/page-settings.js:53
"Enable RTL (right-to-left)" => array( null, __("Enable RTL (right-to-left)", "forminator"), ), // src/form/components/appearance/page-settings.js:69
"Hide empty form fields in generated PDF file" => array( null, __("Hide empty form fields in generated PDF file", "forminator"), ), // src/form/components/appearance/page-settings.js:77
"Layouts" => array( null, __("Layouts", "forminator"), ), // src/form/components/appearance/layout.js:16
"Field description position" => array( null, __("Field description position", "forminator"), ), // src/form/components/appearance/layout.js:21
"Select the default position for field descriptions. You can override this setting in each individual field." => array( null, __("Select the default position for field descriptions. You can override this setting in each individual field.", "forminator"), ), // src/form/components/appearance/layout.js:25
"Choose how much spacing you want between each form field." => array( null, __("Choose how much spacing you want between each form field.", "forminator"), ), // src/form/components/appearance/form-container.js:68
"Theme Fonts" => array( null, __("Theme Fonts", "forminator"), ), // src/form/components/appearance/fonts.js:214
"Response Message" => array( null, __("Response Message", "forminator"), ), // src/form/components/appearance/fonts.js:226
"Pagination Steps" => array( null, __("Pagination Steps", "forminator"), ), // src/form/components/appearance/fonts.js:241
"Pagination Progress Bar" => array( null, __("Pagination Progress Bar", "forminator"), ), // src/form/components/appearance/fonts.js:256
"Fields Label" => array( null, __("Fields Label", "forminator"), ), // src/form/components/appearance/fonts.js:271
"Fields Description" => array( null, __("Fields Description", "forminator"), ), // src/form/components/appearance/fonts.js:285
"Fields Error Message" => array( null, __("Fields Error Message", "forminator"), ), // src/form/components/appearance/fonts.js:299
"Input and Textarea" => array( null, __("Input and Textarea", "forminator"), ), // src/form/components/appearance/fonts.js:347
"Input Prefix" => array( null, __("Input Prefix", "forminator"), ), // src/form/components/appearance/fonts.js:361
"Input Suffix" => array( null, __("Input Suffix", "forminator"), ), // src/form/components/appearance/fonts.js:378
"Radio and Checkbox" => array( null, __("Radio and Checkbox", "forminator"), ), // src/form/components/appearance/fonts.js:398
"Dropdown" => array( null, __("Dropdown", "forminator"), ), // src/form/components/appearance/fonts.js:436
"Multi Select" => array( null, __("Multi Select", "forminator"), ), // src/form/components/appearance/fonts.js:470
"Multi Select Tag" => array( null, __("Multi Select Tag", "forminator"), ), // src/form/components/appearance/fonts.js:488
"Multi Select Chip" => array( null, __("Multi Select Chip", "forminator"), ), // src/form/components/appearance/fonts.js:491
"Single File Upload" => array( null, __("Single File Upload", "forminator"), ), // src/form/components/appearance/fonts.js:511
"Upload Button" => array( null, __("Upload Button", "forminator"), ), // src/form/components/appearance/fonts.js:524
"File Name" => array( null, __("File Name", "forminator"), ), // src/form/components/appearance/fonts.js:535
"Multiple Files Upload" => array( null, __("Multiple Files Upload", "forminator"), ), // src/form/components/appearance/fonts.js:551
"Upload Panel" => array( null, __("Upload Panel", "forminator"), ), // src/form/components/appearance/fonts.js:564
"File Size" => array( null, __("File Size", "forminator"), ), // src/form/components/appearance/fonts.js:586
"E-Signature Placeholder" => array( null, __("E-Signature Placeholder", "forminator"), ), // src/form/components/appearance/fonts.js:602
"Repeater Button" => array( null, __("Repeater Button", "forminator"), ), // src/form/components/appearance/fonts.js:620
"Pagination Buttons" => array( null, __("Pagination Buttons", "forminator"), ), // src/form/components/appearance/fonts.js:637
"Slider selected value" => array( null, __("Slider selected value", "forminator"), ), // src/form/components/appearance/fonts.js:654
"Slider step values" => array( null, __("Slider step values", "forminator"), ), // src/form/components/appearance/fonts.js:667
"Field Container" => array( null, __("Field Container", "forminator"), ), // src/form/components/appearance/fields-container.js:15
"Add a border style around the field." => array( null, __("Add a border style around the field.", "forminator"), ), // src/form/components/appearance/fields-container.js:25
"Forminator Styles" => array( null, __("Forminator Styles", "forminator"), ), // src/form/components/appearance/design.js:31
"Basic Styles" => array( null, __("Basic Styles", "forminator"), ), // src/form/components/appearance/design.js:36
"Use Theme Colors" => array( null, __("Use Theme Colors", "forminator"), ), // src/form/components/appearance/colors.js:271
"Use Default Colors" => array( null, __("Use Default Colors", "forminator"), ), // src/form/components/appearance/colors.js:274
"The form inherits colors from your theme. You can customize specific elements below." => array( null, __("The form inherits colors from your theme. You can customize specific elements below.", "forminator"), ), // src/form/components/appearance/colors.js:293
"The form uses Forminator’s default colors." => array( null, __("The form uses Forminator’s default colors.", "forminator"), ), // src/form/components/appearance/colors.js:296
"Customize colors" => array( null, __("Customize colors", "forminator"), ), // src/form/components/appearance/colors.js:308
"Clear Customization" => array( null, __("Clear Customization", "forminator"), ), // src/form/components/appearance/colors.js:325
"Successful response message will be displayed after form submission succeeds." => array( null, __("Successful response message will be displayed after form submission succeeds.", "forminator"), ), // src/form/components/appearance/colors.js:352
"Error response message will be displayed after form submission fails." => array( null, __("Error response message will be displayed after form submission fails.", "forminator"), ), // src/form/components/appearance/colors.js:363
"Fields Basics" => array( null, __("Fields Basics", "forminator"), ), // src/form/components/appearance/colors.js:388
"Section" => array( null, __("Section", "forminator"), ), // src/form/components/appearance/colors.js:396
"Input Extras" => array( null, __("Input Extras", "forminator"), ), // src/form/components/appearance/colors.js:417
"Select|select field" => array( null, _x("Select", "select field", "forminator"), ), // src/form/components/appearance/colors.js:447
"Dropdown List" => array( null, __("Dropdown List", "forminator"), ), // src/form/components/appearance/colors.js:453
"Dropdown Search" => array( null, __("Dropdown Search", "forminator"), ), // src/form/components/appearance/colors.js:463
"Rating" => array( null, __("Rating", "forminator"), ), // src/form/components/appearance/colors.js:484
"Slider" => array( null, __("Slider", "forminator"), ), // src/form/components/appearance/colors.js:494
"Calendar Basics" => array( null, __("Calendar Basics", "forminator"), ), // src/form/components/appearance/colors.js:505
"Calendar Table" => array( null, __("Calendar Table", "forminator"), ), // src/form/components/appearance/colors.js:512
"File Upload" => array( null, __("File Upload", "forminator"), ), // src/form/components/appearance/colors.js:524
"Field Group" => array( null, __("Field Group", "forminator"), ), // src/form/components/appearance/colors.js:551
"Button Back" => array( null, __("Button Back", "forminator"), ), // src/form/components/appearance/colors.js:581
"Button Next" => array( null, __("Button Next", "forminator"), ), // src/form/components/appearance/colors.js:588
"Consent" => array( null, __("Consent", "forminator"), ), // src/form/components/appearance/colors.js:599
"Page Margin" => array( null, __("Page Margin", "forminator"), ), // src/form/components/appearance/pdf/page-margin.js:22
"Default margin for all paper sizes is 30px. Use the custom tab to set a different value." => array( null, __("Default margin for all paper sizes is 30px. Use the custom tab to set a different value.", "forminator"), ), // src/form/components/appearance/pdf/page-margin.js:25
"Margin" => array( null, __("Margin", "forminator"), ), // src/form/components/appearance/pdf/page-margin.js:40
"Container markup" => array( null, __("Container markup", "forminator"), ), // src/form/components/appearance/pdf/page-layout.js:19
"Choose the default markup structure for your PDF. For better styling flexibility and improved page formatting, we recommend using the Div markup." => array( null, __("Choose the default markup structure for your PDF. For better styling flexibility and improved page formatting, we recommend using the Div markup.", "forminator"), ), // src/form/components/appearance/pdf/page-layout.js:22
"Div" => array( null, __("Div", "forminator"), ), // src/form/components/appearance/pdf/page-layout.js:25
"Table" => array( null, __("Table", "forminator"), ), // src/form/components/appearance/pdf/page-layout.js:26
"You have opted for no stylesheet to be enqueued. Note that we add a grid style css for spacing to your form by default. If needed, you can disable it in the option below." => array( null, __("You have opted for no stylesheet to be enqueued. Note that we add a grid style css for spacing to your form by default. If needed, you can disable it in the option below.", "forminator"), ), // src/form/components/appearance/design/none.js:30
"This option will inherit the basic styles from your WordPress theme." => array( null, __("This option will inherit the basic styles from your WordPress theme.", "forminator"), ), // src/form/components/appearance/design/basic.js:25
"Single File Uploader" => array( null, __("Single File Uploader", "forminator"), ), // src/form/components/appearance/colors/uploaded-files.js:44
"Multiple Files Uploader" => array( null, __("Multiple Files Uploader", "forminator"), ), // src/form/components/appearance/colors/uploaded-files.js:57
"Uploaded File" => array( null, __("Uploaded File", "forminator"), ), // src/form/components/appearance/colors/uploaded-files.js:64
"Uploaded File Delete Button" => array( null, __("Uploaded File Delete Button", "forminator"), ), // src/form/components/appearance/colors/uploaded-files.js:74
"Outline color" => array( null, __("Outline color", "forminator"), ), // src/form/components/appearance/colors/submit.js:76
"Slider track color" => array( null, __("Slider track color", "forminator"), ), // src/form/components/appearance/colors/slider.js:42
"Slider track border color" => array( null, __("Slider track border color", "forminator"), ), // src/form/components/appearance/colors/slider.js:50
"Slider track fill color" => array( null, __("Slider track fill color", "forminator"), ), // src/form/components/appearance/colors/slider.js:58
"Handle color" => array( null, __("Handle color", "forminator"), ), // src/form/components/appearance/colors/slider.js:65
"Selected value color" => array( null, __("Selected value color", "forminator"), ), // src/form/components/appearance/colors/slider.js:75
"Step number color" => array( null, __("Step number color", "forminator"), ), // src/form/components/appearance/colors/slider.js:82
"Custom Min/Max label color" => array( null, __("Custom Min/Max label color", "forminator"), ), // src/form/components/appearance/colors/slider.js:89
"Handle outline color" => array( null, __("Handle outline color", "forminator"), ), // src/form/components/appearance/colors/slider.js:140
"Pressed" => array( null, __("Pressed", "forminator"), ), // src/form/components/appearance/colors/slider.js:148
"Signature Color" => array( null, __("Signature Color", "forminator"), ), // src/form/components/appearance/colors/signature.js:53
"Reset icon color" => array( null, __("Reset icon color", "forminator"), ), // src/form/components/appearance/colors/signature.js:60
"Subtitle color" => array( null, __("Subtitle color", "forminator"), ), // src/form/components/appearance/colors/section.js:20
"Icon" => array( null, __("Icon", "forminator"), ), // src/form/components/appearance/colors/repeater.js:117
"Link" => array( null, __("Link", "forminator"), ), // src/form/components/appearance/colors/repeater.js:169
"Rating icon color" => array( null, __("Rating icon color", "forminator"), ), // src/form/components/appearance/colors/rating.js:34
"Suffix text color" => array( null, __("Suffix text color", "forminator"), ), // src/form/components/appearance/colors/rating.js:42
"Image border" => array( null, __("Image border", "forminator"), ), // src/form/components/appearance/colors/radio.js:54
"Image background" => array( null, __("Image background", "forminator"), ), // src/form/components/appearance/colors/radio.js:63
"Footer border color" => array( null, __("Footer border color", "forminator"), ), // src/form/components/appearance/colors/pagination.js:16
"Current" => array( null, __("Current", "forminator"), ), // src/form/components/appearance/colors/pagination-steps.js:39
"Dot" => array( null, __("Dot", "forminator"), ), // src/form/components/appearance/colors/pagination-steps.js:75
"Default state colors" => array( null, __("Default state colors", "forminator"), ), // src/form/components/appearance/colors/pagination-steps.js:82
"Page number color" => array( null, __("Page number color", "forminator"), ), // src/form/components/appearance/colors/pagination-steps.js:107
"Current state colors" => array( null, __("Current state colors", "forminator"), ), // src/form/components/appearance/colors/pagination-steps.js:119
"Progress bar BG" => array( null, __("Progress bar BG", "forminator"), ), // src/form/components/appearance/colors/pagination-progress.js:25
"Progress status BG" => array( null, __("Progress status BG", "forminator"), ), // src/form/components/appearance/colors/pagination-progress.js:33
"Option border" => array( null, __("Option border", "forminator"), ), // src/form/components/appearance/colors/multi-select.js:60
"Container BG" => array( null, __("Container BG", "forminator"), ), // src/form/components/appearance/colors/multi-select.js:70
"Option color" => array( null, __("Option color", "forminator"), ), // src/form/components/appearance/colors/multi-select.js:78
"Tag background color" => array( null, __("Tag background color", "forminator"), ), // src/form/components/appearance/colors/multi-select.js:93
"Tag text color" => array( null, __("Tag text color", "forminator"), ), // src/form/components/appearance/colors/multi-select.js:105
"Remove tag color" => array( null, __("Remove tag color", "forminator"), ), // src/form/components/appearance/colors/multi-select.js:117
"Option background" => array( null, __("Option background", "forminator"), ), // src/form/components/appearance/colors/multi-select.js:141
"Prefix color" => array( null, __("Prefix color", "forminator"), ), // src/form/components/appearance/colors/inputs-extra.js:57
"Suffix color" => array( null, __("Suffix color", "forminator"), ), // src/form/components/appearance/colors/inputs-extra.js:67
"Divider color" => array( null, __("Divider color", "forminator"), ), // src/form/components/appearance/colors/group.js:33
"Required asterisk" => array( null, __("Required asterisk", "forminator"), ), // src/form/components/appearance/colors/fields-basics.js:25
"Error message BG" => array( null, __("Error message BG", "forminator"), ), // src/form/components/appearance/colors/fields-basics.js:38
"Error message color" => array( null, __("Error message color", "forminator"), ), // src/form/components/appearance/colors/fields-basics.js:49
"Global error color" => array( null, __("Global error color", "forminator"), ), // src/form/components/appearance/colors/fields-basics.js:50
"This color will be used when fields throw an error as text color, border color, etc." => array( null, __("This color will be used when fields throw an error as text color, border color, etc.", "forminator"), ), // src/form/components/appearance/colors/fields-basics.js:54
"Table head color" => array( null, __("Table head color", "forminator"), ), // src/form/components/appearance/colors/calendar-table.js:28
"Table cell border" => array( null, __("Table cell border", "forminator"), ), // src/form/components/appearance/colors/calendar-table.js:36
"Table cell BG" => array( null, __("Table cell BG", "forminator"), ), // src/form/components/appearance/colors/calendar-table.js:44
"Table cell color" => array( null, __("Table cell color", "forminator"), ), // src/form/components/appearance/colors/calendar-table.js:51
"Container" => array( null, __("Container", "forminator"), ), // src/form/components/appearance/colors/calendar-basics.js:27
"Header background" => array( null, __("Header background", "forminator"), ), // src/form/components/appearance/colors/calendar-basics.js:34
"Main background" => array( null, __("Main background", "forminator"), ), // src/form/components/appearance/colors/calendar-basics.js:44
"Navigation" => array( null, __("Navigation", "forminator"), ), // src/form/components/appearance/colors/calendar-basics.js:53
"Arrows background" => array( null, __("Arrows background", "forminator"), ), // src/form/components/appearance/colors/calendar-basics.js:58
"Arrows color" => array( null, __("Arrows color", "forminator"), ), // src/form/components/appearance/colors/calendar-basics.js:65
"Cloud icon color" => array( null, __("Cloud icon color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:49
"Message text color" => array( null, __("Message text color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:57
"Message link color" => array( null, __("Message link color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:64
"Message link outline color" => array( null, __("Message link outline color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:119
"Drop" => array( null, __("Drop", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:127
"Left border color" => array( null, __("Left border color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:178
"File preview border color" => array( null, __("File preview border color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:30
"Default state border will not appear when file uploaded is an image." => array( null, __("Default state border will not appear when file uploaded is an image.", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:32
"File preview background color" => array( null, __("File preview background color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:43
"File preview icon color" => array( null, __("File preview icon color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:54
"File name color" => array( null, __("File name color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:61
"File size color" => array( null, __("File size color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:68
"Loading icon color" => array( null, __("Loading icon color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:75
"File size icon color" => array( null, __("File size icon color", "forminator"), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:115
"Select field(s)" => array( null, __("Select field(s)", "forminator"), ), // src/form/components/abandonment/settings.js:32
"Enable Form Abandonment" => array( null, __("Enable Form Abandonment", "forminator"), ), // src/form/components/abandonment/settings.js:40
"Capture and manage partially completed form entries when users leave without submitting." => array( null, __("Capture and manage partially completed form entries when users leave without submitting.", "forminator"), ), // src/form/components/abandonment/settings.js:43
"Enable tracking for abandoned form entries" => array( null, __("Enable tracking for abandoned form entries", "forminator"), ), // src/form/components/abandonment/settings.js:48
"Store users’ partially completed forms if they leave before submitting." => array( null, __("Store users’ partially completed forms if they leave before submitting.", "forminator"), ), // src/form/components/abandonment/settings.js:51
"Fields required to start saving form data" => array( null, __("Fields required to start saving form data", "forminator"), ), // src/form/components/abandonment/settings.js:56
"These fields must be filled out by visitors before form data can be captured. If no field is selected, form data will always be saved." => array( null, __("These fields must be filled out by visitors before form data can be captured. If no field is selected, form data will always be saved.", "forminator"), ), // src/form/components/abandonment/settings.js:65
"Abandoned entries are stored according to your data retention settings under {{link}}Settings -> Privacy tab{{/link}}." => array( null, __("Abandoned entries are stored according to your data retention settings under {{link}}Settings -> Privacy tab{{/link}}.", "forminator"), ), // src/form/components/abandonment/settings.js:71
"Get Free Extension Pack Add-on" => array( null, __("Get Free Extension Pack Add-on", "forminator"), ), // src/form/components/abandonment/disconnected.js:16
"Get Extension Pack Add-on" => array( null, __("Get Extension Pack Add-on", "forminator"), ), // src/form/components/abandonment/disconnected.js:16
"The {{strong}}Forminator Free Extension Pack Add-on{{/strong}} is required to enable this feature. Click the Install button below to install it." => array( null, __("The {{strong}}Forminator Free Extension Pack Add-on{{/strong}} is required to enable this feature. Click the Install button below to install it.", "forminator"), ), // src/form/components/abandonment/disconnected.js:17
"Connect your site to The Hub to install and activate the Forminator Extension Pack Add-on." => array( null, __("Connect your site to The Hub to install and activate the Forminator Extension Pack Add-on.", "forminator"), ), // src/form/components/abandonment/disconnected.js:23
"Install the {{strong}}Forminator Extension Pack add-on{{/strong}} to enable this feature." => array( null, __("Install the {{strong}}Forminator Extension Pack add-on{{/strong}} to enable this feature.", "forminator"), ), // src/form/components/abandonment/disconnected.js:27
"Unlock abandoned form insights to refine your strategy and recover missed leads." => array( null, __("Unlock abandoned form insights to refine your strategy and recover missed leads.", "forminator"), ), // src/form/components/abandonment/disconnected.js:48
);
return $forminator_admin_locale;
/* THIS IS THE END OF THE GENERATED FILE */
