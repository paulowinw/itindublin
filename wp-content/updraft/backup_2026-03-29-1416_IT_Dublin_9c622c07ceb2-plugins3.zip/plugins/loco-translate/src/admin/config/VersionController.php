<?php
/**
 *  Plugin version / upgrade screen
 */
class Loco_admin_config_VersionController extends Loco_admin_config_BaseController {


    /**
     * {@inheritdoc}
     */
    public function init(){
        parent::init();
        $this->set( 'title', __('Version','loco-translate') );
    }


    /**
     * {@inheritdoc}
     */
    public function render(){
        
        $title = __('Plugin settings','loco-translate');
        $breadcrumb = new Loco_admin_Navigation;
        $breadcrumb->add( $title );
        $this->setLocoUpdate('0');
        
        // current plugin version
        $version = loco_plugin_version();
        if( $updates = get_site_transient('update_plugins') ){
            $key = loco_plugin_self();
            if( isset($updates->response[$key]) ){
                $latest = $updates->response[$key]->new_version;
                // if current version is lower than latest, prompt update
                if( version_compare($version,$latest,'<') ){
                    $this->setLocoUpdate($latest);
                }
            }
        }
        // notify if running a development snapshot, but only if ahead of latest stable
        if( '-dev' === substr($version,-4) ){
            $this->set( 'devel', true );
        }
        
        // check PHP version is at least 7.4
        $phpversion = PHP_VERSION;
        if( version_compare($phpversion,'7.4.0','<') ){
            $this->set('phpupdate','7.4');
        }
        
        // check WordPress version, No plans to increase this until WP bumps their min PHP requirement.
        $wpversion = $GLOBALS['wp_version'];
        return $this->view('admin/config/version', compact('breadcrumb','version','phpversion','wpversion') ); 
    }



    private function setLocoUpdate( string $version ){
        if( $version ){
            $action = 'upgrade-plugin_'.loco_plugin_self();
            $link = admin_url( 'update.php?action=upgrade-plugin&plugin='.rawurlencode(loco_plugin_self()) );
            $this->set('update', $version );
            $this->set('update_href', wp_nonce_url( $link, $action ) );
        }
        else {
            $this->set('update','');
            $this->set('update_href','');
        }
    }

    
}